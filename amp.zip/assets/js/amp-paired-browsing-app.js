/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./assets/src/admin/paired-browsing/app.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./assets/src/admin/paired-browsing/app.css":
/*!**************************************************!*\
  !*** ./assets/src/admin/paired-browsing/app.css ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./assets/src/admin/paired-browsing/app.js":
/*!*************************************************!*\
  !*** ./assets/src/admin/paired-browsing/app.js ***!
  \*************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_url__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/url */ "@wordpress/url");
/* harmony import */ var _wordpress_url__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_url__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _app_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.css */ "./assets/src/admin/paired-browsing/app.css");
/* harmony import */ var _app_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_app_css__WEBPACK_IMPORTED_MODULE_4__);




/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */


var _window = window,
    app = _window.app,
    history = _window.history;
var ampSlug = app.ampSlug,
    noampQueryVar = app.noampQueryVar,
    noampMobile = app.noampMobile,
    ampPairedBrowsingQueryVar = app.ampPairedBrowsingQueryVar,
    documentTitlePrefix = app.documentTitlePrefix;

var PairedBrowsingApp = /*#__PURE__*/function () {
  /**
   * Disconnected client.
   *
   * @type {HTMLIFrameElement}
   */

  /**
   * AMP IFrame
   *
   * @type {HTMLIFrameElement}
   */

  /**
   * Non-AMP IFrame
   *
   * @type {HTMLIFrameElement}
   */

  /**
   * Non-AMP Link
   *
   * @type {HTMLAnchorElement}
   */

  /**
   * AMP Link
   *
   * @type {HTMLAnchorElement}
   */

  /**
   * Constructor.
   */
  function PairedBrowsingApp() {
    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, PairedBrowsingApp);

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2___default()(this, "disconnectedClient", void 0);

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2___default()(this, "ampIframe", void 0);

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2___default()(this, "nonAmpIframe", void 0);

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2___default()(this, "nonAmpLink", void 0);

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2___default()(this, "ampLink", void 0);

    this.nonAmpIframe = document.querySelector('#non-amp iframe');
    this.ampIframe = document.querySelector('#amp iframe');
    this.ampPageHasErrors = false; // Link to exit paired browsing.

    this.nonAmpLink =
    /** @type {HTMLAnchorElement} */
    document.getElementById('non-amp-link');
    this.ampLink =
    /** @type {HTMLAnchorElement} */
    document.getElementById('amp-link'); // Overlay that is displayed on the client that becomes disconnected.

    this.disconnectOverlay = document.querySelector('.disconnect-overlay');
    this.disconnectText = {
      general: document.querySelector('.disconnect-overlay .dialog-text span.general'),
      invalidAmp: document.querySelector('.disconnect-overlay .dialog-text span.invalid-amp')
    };
    this.disconnectButtons = {
      exit: document.querySelector('.disconnect-overlay .button.exit'),
      goBack: document.querySelector('.disconnect-overlay .button.go-back')
    };
    this.addDisconnectButtonListeners(); // Load clients.

    Promise.all(this.getIframeLoadedPromises());
  }
  /**
   * Add event listeners for buttons on disconnect overlay.
   */


  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(PairedBrowsingApp, [{
    key: "addDisconnectButtonListeners",
    value: function addDisconnectButtonListeners() {
      var _this = this;

      // The 'Exit' button navigates the parent window to the URL of the disconnected client.
      this.disconnectButtons.exit.addEventListener('click', function () {
        window.location.assign(_this.disconnectedClient.contentWindow.location.href);
      }); // The 'Go back' button goes back to the previous page of the parent window.

      this.disconnectButtons.goBack.addEventListener('click', function () {
        window.history.back();
      });
    }
    /**
     * Return promises to load iframes asynchronously.
     *
     * @return {Promise<void>[]} Promises that determine if the iframes are loaded.
     */

  }, {
    key: "getIframeLoadedPromises",
    value: function getIframeLoadedPromises() {
      var _this2 = this;

      return [new Promise(function (resolve) {
        _this2.nonAmpIframe.addEventListener('load', function () {
          _this2.toggleDisconnectOverlay(_this2.nonAmpIframe);

          resolve();
        });
      }), new Promise(function (resolve) {
        _this2.ampIframe.addEventListener('load', function () {
          _this2.toggleDisconnectOverlay(_this2.ampIframe);

          resolve();
        });
      })];
    }
    /**
     * Validates whether or not the window document is AMP compatible.
     *
     * @param {Document} doc Window document.
     * @return {boolean} True if AMP compatible, false if not.
     */

  }, {
    key: "documentIsAmp",
    value: function documentIsAmp(doc) {
      return doc.querySelector('head > script[src="https://cdn.ampproject.org/v0.js"]');
    }
    /**
     * Toggles the 'disconnected' overlay for the supplied iframe.
     *
     * @param {HTMLIFrameElement} iframe The iframe that hosts the paired browsing client.
     */

  }, {
    key: "toggleDisconnectOverlay",
    value: function toggleDisconnectOverlay(iframe) {
      var isClientConnected = this.isClientConnected(iframe);

      if (!isClientConnected) {
        if (this.ampIframe === iframe && this.ampPageHasErrors) {
          this.disconnectText.general.classList.toggle('hidden', true);
          this.disconnectText.invalidAmp.classList.toggle('hidden', false);
        } else {
          this.disconnectText.general.classList.toggle('hidden', false);
          this.disconnectText.invalidAmp.classList.toggle('hidden', true);
        } // Show the 'Go Back' button if the parent window has history.


        this.disconnectButtons.goBack.classList.toggle('hidden', 0 >= window.history.length); // If the document is not available, the window URL cannot be accessed.

        this.disconnectButtons.exit.classList.toggle('hidden', null === iframe.contentDocument);
        this.disconnectedClient = iframe;
      } // Applying the 'amp' class will overlay it on the AMP iframe.


      this.disconnectOverlay.classList.toggle('amp', !isClientConnected && this.ampIframe === iframe);
      this.disconnectOverlay.classList.toggle('disconnected', !isClientConnected);
    }
    /**
     * Determines the status of the paired browsing client in an iframe.
     *
     * @param {HTMLIFrameElement} iframe The iframe.
     */

  }, {
    key: "isClientConnected",
    value: function isClientConnected(iframe) {
      if (this.ampIframe === iframe && this.ampPageHasErrors) {
        return false;
      }

      return null !== iframe.contentWindow && null !== iframe.contentDocument && true === iframe.contentWindow.ampPairedBrowsingClient;
    }
    /**
     * Removes AMP related query variables from the supplied URL.
     *
     * @param {string} url URL string.
     * @return {string} Modified URL without any AMP related query variables.
     */

  }, {
    key: "removeAmpQueryVars",
    value: function removeAmpQueryVars(url) {
      return Object(_wordpress_url__WEBPACK_IMPORTED_MODULE_3__["removeQueryArgs"])(url, ampSlug, noampQueryVar, ampPairedBrowsingQueryVar);
    }
    /**
     * Adds the AMP query variable to the supplied URL.
     *
     * @param {string} url URL string.
     * @return {string} Modified URL with the AMP query variable.
     */

  }, {
    key: "addAmpQueryVar",
    value: function addAmpQueryVar(url) {
      return Object(_wordpress_url__WEBPACK_IMPORTED_MODULE_3__["addQueryArgs"])(url, _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2___default()({}, ampSlug, '1'));
    }
    /**
     * Adds the AMP paired browsing query variable to the supplied URL.
     *
     * @param {string} url URL string.
     * @return {string} Modified URL with the AMP paired browsing query variable.
     */

  }, {
    key: "addPairedBrowsingQueryVar",
    value: function addPairedBrowsingQueryVar(url) {
      return Object(_wordpress_url__WEBPACK_IMPORTED_MODULE_3__["addQueryArgs"])(url, _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2___default()({}, ampPairedBrowsingQueryVar, '1'));
    }
    /**
     * Removes the URL hash from the supplied URL.
     *
     * @param {string} url URL string.
     * @return {string} Modified URL without the hash.
     */

  }, {
    key: "removeUrlHash",
    value: function removeUrlHash(url) {
      var parsedUrl = new URL(url);
      parsedUrl.hash = '';
      return parsedUrl.href;
    }
    /**
     * Checks if a URL has the 'amp_validation_errors' query variable.
     *
     * @param {string} url URL string.
     * @return {boolean} True if such query var exists, false if not.
     */

  }, {
    key: "urlHasValidationErrorQueryVar",
    value: function urlHasValidationErrorQueryVar(url) {
      return Object(_wordpress_url__WEBPACK_IMPORTED_MODULE_3__["hasQueryArg"])(url, 'amp_validation_errors');
    }
    /**
     * Registers the provided client window with its parent, so that it can be managed by it.
     *
     * @param {Window} win Document window.
     */

  }, {
    key: "registerClientWindow",
    value: function registerClientWindow(win) {
      var oppositeWindow;

      if (win === this.ampIframe.contentWindow) {
        if (!this.documentIsAmp(win.document)) {
          if (this.urlHasValidationErrorQueryVar(win.location.href)) {
            /*
             * If the AMP page has validation errors, mark the page as invalid so that the
             * 'disconnected' overlay can be shown.
             */
            this.ampPageHasErrors = true;
            this.toggleDisconnectOverlay(this.ampIframe);
            return;
          } else if (win.document.querySelector('head > link[rel=amphtml]')) {
            // Force the AMP iframe to always have an AMP URL, if an AMP version is available.
            win.location.replace(this.addAmpQueryVar(win.location.href));
            return;
          }
          /*
           * If the AMP iframe has loaded a non-AMP page and none of the conditions above are
           * true, then explicitly mark it as having errors and display the 'disconnected
           * overlay.
           */


          this.ampPageHasErrors = true;
          this.toggleDisconnectOverlay(this.ampIframe);
          return;
        } // Update the AMP link above the iframe used for exiting paired browsing.


        this.ampLink.href = Object(_wordpress_url__WEBPACK_IMPORTED_MODULE_3__["removeQueryArgs"])(this.ampIframe.contentWindow.location.href, noampQueryVar);
        this.ampPageHasErrors = false;
        oppositeWindow = this.nonAmpIframe.contentWindow;
      } else {
        // Force the non-AMP iframe to always have a non-AMP URL.
        if (this.documentIsAmp(win.document)) {
          win.location.replace(this.removeAmpQueryVars(win.location.href));
          return;
        } // Update the non-AMP link above the iframe used for exiting paired browsing.


        this.nonAmpLink.href = Object(_wordpress_url__WEBPACK_IMPORTED_MODULE_3__["addQueryArgs"])(this.nonAmpIframe.contentWindow.location.href, _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_2___default()({}, noampQueryVar, noampMobile));
        oppositeWindow = this.ampIframe.contentWindow;
      } // Synchronize scrolling from current window to its opposite.


      win.addEventListener('scroll', function () {
        if (oppositeWindow && oppositeWindow.ampPairedBrowsingClient && oppositeWindow.scrollTo) {
          oppositeWindow.scrollTo(win.scrollX, win.scrollY);
        }
      }, {
        passive: true
      }); // Scrolling is not synchronized if `scroll-behavior` is set to `smooth`.

      win.document.documentElement.style.setProperty('scroll-behavior', 'auto', 'important'); // Make sure the opposite iframe is set to match.

      if (oppositeWindow && oppositeWindow.location && this.removeAmpQueryVars(this.removeUrlHash(oppositeWindow.location.href)) !== this.removeAmpQueryVars(this.removeUrlHash(win.location.href))) {
        var url = oppositeWindow === this.ampIframe.contentWindow ? this.addAmpQueryVar(win.location.href) : this.removeAmpQueryVars(win.location.href);
        oppositeWindow.location.replace(url);
        return;
      }

      document.title = documentTitlePrefix + ' ' + win.document.title;
      history.replaceState({}, '', this.addPairedBrowsingQueryVar(this.removeAmpQueryVars(win.location.href)));
    }
  }]);

  return PairedBrowsingApp;
}();

window.pairedBrowsingApp = new PairedBrowsingApp();

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/classCallCheck.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/classCallCheck.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/createClass.js":
/*!************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/createClass.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/defineProperty.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/defineProperty.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty;

/***/ }),

/***/ "@wordpress/url":
/*!**************************************!*\
  !*** external {"this":["wp","url"]} ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["url"]; }());

/***/ })

/******/ });
//# sourceMappingURL=amp-paired-browsing-app.js.map