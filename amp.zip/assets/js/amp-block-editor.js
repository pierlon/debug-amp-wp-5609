/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./assets/src/block-editor/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./assets/src/block-editor/blocks sync recursive (?<!test\\/)index\\.js$":
/*!*******************************************************************!*\
  !*** ./assets/src/block-editor/blocks sync (?<!test\/)index\.js$ ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./amp-brid-player/index.js": "./assets/src/block-editor/blocks/amp-brid-player/index.js",
	"./amp-ima-video/index.js": "./assets/src/block-editor/blocks/amp-ima-video/index.js",
	"./amp-jwplayer/index.js": "./assets/src/block-editor/blocks/amp-jwplayer/index.js",
	"./amp-mathml/index.js": "./assets/src/block-editor/blocks/amp-mathml/index.js",
	"./amp-o2-player/index.js": "./assets/src/block-editor/blocks/amp-o2-player/index.js",
	"./amp-ooyala-player/index.js": "./assets/src/block-editor/blocks/amp-ooyala-player/index.js",
	"./amp-reach-player/index.js": "./assets/src/block-editor/blocks/amp-reach-player/index.js",
	"./amp-springboard-player/index.js": "./assets/src/block-editor/blocks/amp-springboard-player/index.js",
	"./amp-timeago/index.js": "./assets/src/block-editor/blocks/amp-timeago/index.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./assets/src/block-editor/blocks sync recursive (?<!test\\/)index\\.js$";

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-brid-player/edit.js":
/*!****************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-brid-player/edit.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js");
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components */ "./assets/src/block-editor/components/index.js");



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



var BlockEdit = function BlockEdit(props) {
  var attributes = props.attributes,
      setAttributes = props.setAttributes;
  var autoPlay = attributes.autoPlay,
      dataPartner = attributes.dataPartner,
      dataPlayer = attributes.dataPlayer,
      dataVideo = attributes.dataVideo,
      dataPlaylist = attributes.dataPlaylist,
      dataOutstream = attributes.dataOutstream;
  var ampLayoutOptions = [{
    value: 'responsive',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Responsive', 'amp')
  }, {
    value: 'fixed-height',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed Height', 'amp')
  }, {
    value: 'fixed',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed', 'amp')
  }, {
    value: 'fill',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Flex-item', 'amp')
  }, {
    value: 'nodisplay',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('No Display', 'amp')
  }];
  var url = false;

  if (dataPartner && dataPlayer && (dataVideo || dataPlaylist || dataOutstream)) {
    url = "http://cdn.brid.tv/live/partners/".concat(dataPartner);
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Brid Player Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Partner ID (required)', 'amp'),
    value: dataPartner,
    onChange: function onChange(value) {
      return setAttributes({
        dataPartner: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Player ID (required)', 'amp'),
    value: dataPlayer,
    onChange: function onChange(value) {
      return setAttributes({
        dataPlayer: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Video ID (one of video / playlist / outstream ID is required)', 'amp'),
    value: dataVideo,
    onChange: function onChange(value) {
      return setAttributes({
        dataVideo: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Outstream unit ID (one of video / playlist / outstream ID is required)', 'amp'),
    value: dataOutstream,
    onChange: function onChange(value) {
      return setAttributes({
        dataOutstream: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Playlist ID (one of video / playlist / outstream ID is required)', 'amp'),
    value: dataPlaylist,
    onChange: function onChange(value) {
      return setAttributes({
        dataPlaylist: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["ToggleControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Autoplay', 'amp'),
    checked: autoPlay,
    onChange: function onChange() {
      return setAttributes({
        autoPlay: !autoPlay
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["LayoutControls"], _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["MediaPlaceholder"], {
    name: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Brid Player', 'amp'),
    url: url
  }), !url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["Placeholder"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Brid Player', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("p", null, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Add required data to use the block.', 'amp'))));
};

BlockEdit.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.shape({
    autoPlay: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,
    dataPartner: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataPlayer: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataVideo: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataPlaylist: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataOutstream: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired
};
/* harmony default export */ __webpack_exports__["default"] = (BlockEdit);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-brid-player/index.js":
/*!*****************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-brid-player/index.js ***!
  \*****************************************************************/
/*! exports provided: name, settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return settings; });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit */ "./assets/src/block-editor/blocks/amp-brid-player/edit.js");
/* harmony import */ var _save__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./save */ "./assets/src/block-editor/blocks/amp-brid-player/save.js");
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



var name = 'amp/amp-brid-player';
var settings = {
  title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('AMP Brid Player', 'amp'),
  description: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Displays the Brid Player used in Brid.tv Video Platform.', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Embed', 'amp')],
  attributes: {
    autoPlay: {
      type: 'boolean'
    },
    dataPartner: {
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'data-partner'
    },
    dataPlayer: {
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'data-player'
    },
    dataVideo: {
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'data-video'
    },
    dataPlaylist: {
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'data-playlist'
    },
    dataOutstream: {
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'data-outstream'
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'layout'
    },
    width: {
      type: 'number',
      default: 600
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-brid-player',
      attribute: 'height'
    }
  },
  edit: _edit__WEBPACK_IMPORTED_MODULE_1__["default"],
  save: _save__WEBPACK_IMPORTED_MODULE_2__["default"]
};

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-brid-player/save.js":
/*!****************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-brid-player/save.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);


/**
 * External dependencies
 */


var BlockSave = function BlockSave(_ref) {
  var attributes = _ref.attributes;
  var dataPlayer = attributes.dataPlayer,
      dataOutstream = attributes.dataOutstream,
      dataPartner = attributes.dataPartner,
      ampLayout = attributes.ampLayout,
      width = attributes.width,
      height = attributes.height,
      dataVideo = attributes.dataVideo,
      autoPlay = attributes.autoPlay,
      dataPlaylist = attributes.dataPlaylist;
  var bridProps = {
    layout: ampLayout,
    height: height,
    'data-player': dataPlayer,
    'data-partner': dataPartner
  };

  if ('fixed-height' !== ampLayout && width) {
    bridProps.width = width;
  }

  if (dataPlaylist) {
    bridProps['data-playlist'] = dataPlaylist;
  }

  if (dataVideo) {
    bridProps['data-video'] = dataVideo;
  }

  if (dataOutstream) {
    bridProps['data-outstream'] = dataOutstream;
  }

  if (autoPlay) {
    bridProps.autoplay = autoPlay;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("amp-brid-player", bridProps);
};

BlockSave.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    autoPlay: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
    dataPartner: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataPlayer: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataVideo: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataPlaylist: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataOutstream: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
  })
};
/* harmony default export */ __webpack_exports__["default"] = (BlockSave);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-ima-video/edit.js":
/*!**************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-ima-video/edit.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js");
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components */ "./assets/src/block-editor/components/index.js");



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



var BlockEdit = function BlockEdit(props) {
  var attributes = props.attributes,
      setAttributes = props.setAttributes;
  var dataDelayAdRequest = attributes.dataDelayAdRequest,
      dataTag = attributes.dataTag,
      dataSrc = attributes.dataSrc,
      dataPoster = attributes.dataPoster;
  var ampLayoutOptions = [{
    value: 'responsive',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Responsive', 'amp')
  }, {
    value: 'fixed',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed', 'amp')
  }];
  var dataSet = false;

  if (dataTag && dataSrc) {
    dataSet = true;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('IMA Video Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('HTTPS URL for your VAST ad document (required)', 'amp'),
    value: dataTag,
    onChange: function onChange(value) {
      return setAttributes({
        dataTag: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('HTTPS URL of your video content (required)', 'amp'),
    value: dataSrc,
    onChange: function onChange(value) {
      return setAttributes({
        dataSrc: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('HTTPS URL to preview image', 'amp'),
    value: dataPoster,
    onChange: function onChange(value) {
      return setAttributes({
        dataPoster: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["ToggleControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Delay Ad Request', 'amp'),
    checked: dataDelayAdRequest,
    onChange: function onChange() {
      return setAttributes({
        dataDelayAdRequest: !dataDelayAdRequest
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["LayoutControls"], _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), dataSet && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["MediaPlaceholder"], {
    name: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('IMA Video', 'amp'),
    url: dataSrc
  }), !dataSet && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["Placeholder"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('IMA Video', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("p", null, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Add required data to use the block.', 'amp'))));
};

BlockEdit.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.shape({
    dataSrc: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataTag: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataDelayAdRequest: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataPoster: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired
};
/* harmony default export */ __webpack_exports__["default"] = (BlockEdit);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-ima-video/index.js":
/*!***************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-ima-video/index.js ***!
  \***************************************************************/
/*! exports provided: name, settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return settings; });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit */ "./assets/src/block-editor/blocks/amp-ima-video/edit.js");
/* harmony import */ var _save__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./save */ "./assets/src/block-editor/blocks/amp-ima-video/save.js");
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



var name = 'amp/amp-ima-video';
var settings = {
  title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('AMP IMA Video', 'amp'),
  description: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Embeds a video player for instream video ads that are integrated with the IMA SDK', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Embed', 'amp')],
  // @todo Perhaps later add subtitles option and additional source options?
  attributes: {
    dataDelayAdRequest: {
      default: false,
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'data-delay-ad-request'
    },
    dataTag: {
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'data-tag'
    },
    dataSrc: {
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'data-src'
    },
    dataPoster: {
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'data-poster'
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-ima-video',
      attribute: 'height'
    }
  },
  edit: _edit__WEBPACK_IMPORTED_MODULE_1__["default"],
  save: _save__WEBPACK_IMPORTED_MODULE_2__["default"]
};

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-ima-video/save.js":
/*!**************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-ima-video/save.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);


/**
 * External dependencies
 */


var BlockSave = function BlockSave(_ref) {
  var attributes = _ref.attributes;
  var width = attributes.width,
      dataSrc = attributes.dataSrc,
      ampLayout = attributes.ampLayout,
      dataTag = attributes.dataTag,
      dataDelayAdRequest = attributes.dataDelayAdRequest,
      height = attributes.height,
      dataPoster = attributes.dataPoster;
  var imaProps = {
    layout: ampLayout,
    height: height,
    width: width,
    'data-tag': dataTag,
    'data-src': dataSrc
  };

  if (dataPoster) {
    imaProps['data-poster'] = dataPoster;
  }

  if (dataDelayAdRequest) {
    imaProps['data-delay-ad-request'] = dataDelayAdRequest;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("amp-ima-video", imaProps);
};

BlockSave.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataSrc: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataTag: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataDelayAdRequest: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataPoster: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
  })
};
/* harmony default export */ __webpack_exports__["default"] = (BlockSave);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-jwplayer/edit.js":
/*!*************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-jwplayer/edit.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js");
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components */ "./assets/src/block-editor/components/index.js");



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



var BlockEdit = function BlockEdit(props) {
  var attributes = props.attributes,
      setAttributes = props.setAttributes;
  var dataPlayerId = attributes.dataPlayerId,
      dataMediaId = attributes.dataMediaId,
      dataPlaylistId = attributes.dataPlaylistId;
  var ampLayoutOptions = [{
    value: 'responsive',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Responsive', 'amp')
  }, {
    value: 'fixed-height',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed Height', 'amp')
  }, {
    value: 'fixed',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed', 'amp')
  }, {
    value: 'fill',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Flex-item', 'amp')
  }, {
    value: 'nodisplay',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('No Display', 'amp')
  }];
  var url = false;

  if (dataPlayerId && (dataMediaId || dataPlaylistId)) {
    if (dataPlaylistId) {
      url = "https://content.jwplatform.com/players/".concat(dataPlaylistId, "-").concat(dataPlayerId);
    } else {
      url = "https://content.jwplatform.com/players/".concat(dataMediaId, "-").concat(dataPlayerId);
    }
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('JW Player Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Player ID (required)', 'amp'),
    value: dataPlayerId,
    onChange: function onChange(value) {
      return setAttributes({
        dataPlayerId: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Media ID (required if playlist ID not set)', 'amp'),
    value: dataMediaId,
    onChange: function onChange(value) {
      return setAttributes({
        dataMediaId: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Playlist ID (required if media ID not set)', 'amp'),
    value: dataPlaylistId,
    onChange: function onChange(value) {
      return setAttributes({
        dataPlaylistId: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["LayoutControls"], _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["MediaPlaceholder"], {
    name: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('JW Player', 'amp'),
    url: url
  }), !url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["Placeholder"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('JW Player', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("p", null, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Add required data to use the block.', 'amp'))));
};

BlockEdit.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.shape({
    dataPlayerId: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataMediaId: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataPlaylistId: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired
};
/* harmony default export */ __webpack_exports__["default"] = (BlockEdit);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-jwplayer/index.js":
/*!**************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-jwplayer/index.js ***!
  \**************************************************************/
/*! exports provided: name, settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return settings; });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit */ "./assets/src/block-editor/blocks/amp-jwplayer/edit.js");
/* harmony import */ var _save__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./save */ "./assets/src/block-editor/blocks/amp-jwplayer/save.js");
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



var name = 'amp/amp-jwplayer';
var settings = {
  title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('AMP JW Player', 'amp'),
  description: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Displays a cloud-hosted JW Player.', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Embed', 'amp')],
  attributes: {
    dataPlayerId: {
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'data-player-id'
    },
    dataMediaId: {
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'data-media-id'
    },
    dataPlaylistId: {
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'data-playlist-id'
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-jwplayer',
      attribute: 'height'
    }
  },
  edit: _edit__WEBPACK_IMPORTED_MODULE_1__["default"],
  save: _save__WEBPACK_IMPORTED_MODULE_2__["default"]
};

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-jwplayer/save.js":
/*!*************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-jwplayer/save.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);


/**
 * External dependencies
 */


var BlockSave = function BlockSave(_ref) {
  var attributes = _ref.attributes;
  var width = attributes.width,
      height = attributes.height,
      ampLayout = attributes.ampLayout,
      dataPlaylistId = attributes.dataPlaylistId,
      dataPlayerId = attributes.dataPlayerId,
      dataMediaId = attributes.dataMediaId;
  var jwProps = {
    layout: ampLayout,
    height: height,
    'data-player-id': dataPlayerId
  };

  if ('fixed-height' !== ampLayout && width) {
    jwProps.width = width;
  }

  if (dataPlaylistId) {
    jwProps['data-playlist-id'] = dataPlaylistId;
  }

  if (dataMediaId) {
    jwProps['data-media-id'] = dataMediaId;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("amp-jwplayer", jwProps);
};

BlockSave.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    dataPlayerId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataMediaId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataPlaylistId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
  })
};
/* harmony default export */ __webpack_exports__["default"] = (BlockSave);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-mathml/edit.js":
/*!***********************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-mathml/edit.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_3__);


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




var BlockEdit = function BlockEdit(_ref) {
  var attributes = _ref.attributes,
      setAttributes = _ref.setAttributes;
  var dataFormula = attributes.dataFormula;
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_3__["PlainText"], {
    value: dataFormula,
    placeholder: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('Insert formula', 'amp'),
    onChange: function onChange(value) {
      return setAttributes({
        dataFormula: value
      });
    }
  });
};

BlockEdit.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    dataFormula: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired
};
/* harmony default export */ __webpack_exports__["default"] = (BlockEdit);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-mathml/index.js":
/*!************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-mathml/index.js ***!
  \************************************************************/
/*! exports provided: name, settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return settings; });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit */ "./assets/src/block-editor/blocks/amp-mathml/edit.js");
/* harmony import */ var _save__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./save */ "./assets/src/block-editor/blocks/amp-mathml/save.js");
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



var name = 'amp/amp-mathml';
var settings = {
  title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('AMP MathML', 'amp'),
  category: 'common',
  icon: 'welcome-learn-more',
  keywords: [Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Mathematical formula', 'amp'), Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Scientific content ', 'amp')],
  attributes: {
    dataFormula: {
      source: 'attribute',
      selector: 'amp-mathml',
      attribute: 'data-formula'
    }
  },
  edit: _edit__WEBPACK_IMPORTED_MODULE_1__["default"],
  save: _save__WEBPACK_IMPORTED_MODULE_2__["default"]
};

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-mathml/save.js":
/*!***********************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-mathml/save.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);


/**
 * External dependencies
 */


var BlockSave = function BlockSave(_ref) {
  var attributes = _ref.attributes;
  var dataFormula = attributes.dataFormula;
  var mathmlProps = {
    'data-formula': dataFormula,
    layout: 'container'
  };
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("amp-mathml", mathmlProps);
};

BlockSave.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    dataFormula: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
  })
};
/* harmony default export */ __webpack_exports__["default"] = (BlockSave);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-o2-player/edit.js":
/*!**************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-o2-player/edit.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js");
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components */ "./assets/src/block-editor/components/index.js");



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



var BlockEdit = function BlockEdit(props) {
  var attributes = props.attributes,
      setAttributes = props.setAttributes;
  var autoPlay = attributes.autoPlay,
      dataPid = attributes.dataPid,
      dataVid = attributes.dataVid,
      dataBcid = attributes.dataBcid,
      dataBid = attributes.dataBid;
  var ampLayoutOptions = [{
    value: 'responsive',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Responsive', 'amp')
  }, {
    value: 'fixed-height',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed Height', 'amp')
  }, {
    value: 'fixed',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed', 'amp')
  }, {
    value: 'fill',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Flex-item', 'amp')
  }, {
    value: 'nodisplay',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('No Display', 'amp')
  }];
  var url = false;

  if (dataPid && (dataBcid || dataVid)) {
    url = "https://delivery.vidible.tv/htmlembed/pid=".concat(dataPid, "/");
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('O2 Player Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Player ID (required)', 'amp'),
    value: dataPid,
    onChange: function onChange(value) {
      return setAttributes({
        dataPid: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Buyer Company ID (either buyer or video ID is required)', 'amp'),
    value: dataBcid,
    onChange: function onChange(value) {
      return setAttributes({
        dataBcid: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Video ID (either buyer or video ID is required)', 'amp'),
    value: dataVid,
    onChange: function onChange(value) {
      return setAttributes({
        dataVid: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Playlist ID', 'amp'),
    value: dataBid,
    onChange: function onChange(value) {
      return setAttributes({
        dataBid: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["ToggleControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Autoplay', 'amp'),
    checked: autoPlay,
    onChange: function onChange() {
      return setAttributes({
        autoPlay: !autoPlay
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["LayoutControls"], _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["MediaPlaceholder"], {
    name: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('O2 Player', 'amp'),
    url: url
  }), !url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["Placeholder"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('O2 Player', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("p", null, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Add required data to use the block.', 'amp'))));
};

BlockEdit.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.shape({
    autoPlay: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,
    dataPid: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataVid: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataBcid: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataBid: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired
};
/* harmony default export */ __webpack_exports__["default"] = (BlockEdit);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-o2-player/index.js":
/*!***************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-o2-player/index.js ***!
  \***************************************************************/
/*! exports provided: name, settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return settings; });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit */ "./assets/src/block-editor/blocks/amp-o2-player/edit.js");
/* harmony import */ var _save__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./save */ "./assets/src/block-editor/blocks/amp-o2-player/save.js");
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



var name = 'amp/amp-o2-player';
var settings = {
  title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('AMP O2 Player', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Embed', 'amp'), Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('AOL O2Player', 'amp')],
  // @todo Add other useful macro toggles, e.g. showing relevant content.
  attributes: {
    dataPid: {
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'data-pid'
    },
    dataVid: {
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'data-vid'
    },
    dataBcid: {
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'data-bcid'
    },
    dataBid: {
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'data-bid'
    },
    autoPlay: {
      default: false
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-o2-player',
      attribute: 'height'
    }
  },
  edit: _edit__WEBPACK_IMPORTED_MODULE_1__["default"],
  save: _save__WEBPACK_IMPORTED_MODULE_2__["default"]
};

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-o2-player/save.js":
/*!**************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-o2-player/save.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);


/**
 * External dependencies
 */


var BlockSave = function BlockSave(_ref) {
  var attributes = _ref.attributes;
  var dataPid = attributes.dataPid,
      width = attributes.width,
      height = attributes.height,
      ampLayout = attributes.ampLayout,
      dataBid = attributes.dataBid,
      autoPlay = attributes.autoPlay,
      dataBcid = attributes.dataBcid,
      dataVid = attributes.dataVid;
  var o2Props = {
    layout: ampLayout,
    height: height,
    'data-pid': dataPid
  };

  if ('fixed-height' !== ampLayout && width) {
    o2Props.width = width;
  }

  if (!autoPlay) {
    o2Props['data-macros'] = 'm.playback=click';
  }

  if (dataVid) {
    o2Props['data-vid'] = dataVid;
  } else if (dataBcid) {
    o2Props['data-bcid'] = dataBcid;
  }

  if (dataBid) {
    o2Props['data-bid'] = dataBid;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("amp-o2-player", o2Props);
};

BlockSave.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    autoPlay: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
    dataPid: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataPidL: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataVid: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataBcid: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataBid: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
  })
};
/* harmony default export */ __webpack_exports__["default"] = (BlockSave);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-ooyala-player/edit.js":
/*!******************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-ooyala-player/edit.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js");
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components */ "./assets/src/block-editor/components/index.js");



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



var BlockEdit = function BlockEdit(props) {
  var attributes = props.attributes,
      setAttributes = props.setAttributes;
  var dataEmbedCode = attributes.dataEmbedCode,
      dataPlayerId = attributes.dataPlayerId,
      dataPcode = attributes.dataPcode,
      dataPlayerVersion = attributes.dataPlayerVersion;
  var ampLayoutOptions = [{
    value: 'responsive',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Responsive', 'amp')
  }, {
    value: 'fixed',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed', 'amp')
  }, {
    value: 'fill',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Flex-item', 'amp')
  }];
  var url = false;

  if (dataEmbedCode && dataPlayerId && dataPcode) {
    url = "http://cf.c.ooyala.com/".concat(dataEmbedCode);
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Ooyala Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Video embed code (required)', 'amp'),
    value: dataEmbedCode,
    onChange: function onChange(value) {
      return setAttributes({
        dataEmbedCode: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Player ID (required)', 'amp'),
    value: dataPlayerId,
    onChange: function onChange(value) {
      return setAttributes({
        dataPlayerId: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Provider code for the account (required)', 'amp'),
    value: dataPcode,
    onChange: function onChange(value) {
      return setAttributes({
        dataPcode: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["SelectControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Player version', 'amp'),
    value: dataPlayerVersion,
    options: [{
      value: 'v3',
      label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('V3', 'amp')
    }, {
      value: 'v4',
      label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('V4', 'amp')
    }],
    onChange: function onChange(value) {
      return setAttributes({
        dataPlayerVersion: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["LayoutControls"], _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["MediaPlaceholder"], {
    name: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Ooyala Player', 'amp'),
    url: url
  }), !url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["Placeholder"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Ooyala Player', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("p", null, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Add required data to use the block.', 'amp'))));
};

BlockEdit.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.shape({
    dataEmbedCode: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataPlayerId: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataPcode: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataPlayerVersion: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired
};
/* harmony default export */ __webpack_exports__["default"] = (BlockEdit);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-ooyala-player/index.js":
/*!*******************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-ooyala-player/index.js ***!
  \*******************************************************************/
/*! exports provided: name, settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return settings; });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit */ "./assets/src/block-editor/blocks/amp-ooyala-player/edit.js");
/* harmony import */ var _save__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./save */ "./assets/src/block-editor/blocks/amp-ooyala-player/save.js");
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



var name = 'amp/amp-ooyala-player';
var settings = {
  title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('AMP Ooyala Player', 'amp'),
  description: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Displays an Ooyala video.', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Embed', 'amp'), Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Ooyala video', 'amp')],
  // @todo Add data-config attribute?
  attributes: {
    dataEmbedCode: {
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'data-embedcode'
    },
    dataPlayerId: {
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'data-playerid'
    },
    dataPcode: {
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'data-pcode'
    },
    dataPlayerVersion: {
      default: 'v3',
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'data-playerversion'
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-ooyala-player',
      attribute: 'height'
    }
  },
  edit: _edit__WEBPACK_IMPORTED_MODULE_1__["default"],
  save: _save__WEBPACK_IMPORTED_MODULE_2__["default"]
};

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-ooyala-player/save.js":
/*!******************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-ooyala-player/save.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);


/**
 * External dependencies
 */


var BlockSave = function BlockSave(_ref) {
  var attributes = _ref.attributes;
  var dataEmbedCode = attributes.dataEmbedCode,
      dataPlayerId = attributes.dataPlayerId,
      dataPcode = attributes.dataPcode,
      dataPlayerVersion = attributes.dataPlayerVersion,
      ampLayout = attributes.ampLayout,
      height = attributes.height,
      width = attributes.width;
  var ooyalaProps = {
    layout: ampLayout,
    height: height,
    'data-embedcode': dataEmbedCode,
    'data-playerid': dataPlayerId,
    'data-pcode': dataPcode,
    'data-playerversion': dataPlayerVersion
  };

  if ('fixed-height' !== ampLayout && width) {
    ooyalaProps.width = width;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("amp-ooyala-player", ooyalaProps);
};

BlockSave.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    dataEmbedCode: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataPlayerId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataPcode: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataPlayerVersion: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
  })
};
/* harmony default export */ __webpack_exports__["default"] = (BlockSave);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-reach-player/edit.js":
/*!*****************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-reach-player/edit.js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js");
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components */ "./assets/src/block-editor/components/index.js");



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



var BlockEdit = function BlockEdit(props) {
  var attributes = props.attributes,
      setAttributes = props.setAttributes;
  var dataEmbedId = attributes.dataEmbedId;
  var ampLayoutOptions = [{
    value: 'responsive',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Responsive', 'amp')
  }, {
    value: 'fixed-height',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed Height', 'amp')
  }, {
    value: 'fixed',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed', 'amp')
  }, {
    value: 'fill',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Flex-item', 'amp')
  }];
  var url = false;

  if (dataEmbedId) {
    url = 'https://media-cdn.beachfrontreach.com/acct_1/video/';
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Reach Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Embed ID (required)', 'amp'),
    value: dataEmbedId,
    onChange: function onChange(value) {
      return setAttributes({
        dataEmbedId: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["LayoutControls"], _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["MediaPlaceholder"], {
    name: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Reach Player', 'amp'),
    url: url
  }), !url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["Placeholder"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Reach Player', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("p", null, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Add Reach player embed ID to use the block.', 'amp'))));
};

BlockEdit.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.shape({
    dataEmbedId: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired
};
/* harmony default export */ __webpack_exports__["default"] = (BlockEdit);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-reach-player/index.js":
/*!******************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-reach-player/index.js ***!
  \******************************************************************/
/*! exports provided: name, settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return settings; });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit */ "./assets/src/block-editor/blocks/amp-reach-player/edit.js");
/* harmony import */ var _save__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./save */ "./assets/src/block-editor/blocks/amp-reach-player/save.js");
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



var name = 'amp/amp-reach-player';
var settings = {
  title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('AMP Reach Player', 'amp'),
  description: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Displays the Reach Player configured in the Beachfront Reach platform.', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Embed', 'amp'), Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Beachfront Reach video', 'amp')],
  attributes: {
    dataEmbedId: {
      source: 'attribute',
      selector: 'amp-reach-player',
      attribute: 'data-embed-id'
    },
    ampLayout: {
      default: 'fixed-height',
      source: 'attribute',
      selector: 'amp-reach-player',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-reach-player',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-reach-player',
      attribute: 'height'
    }
  },
  edit: _edit__WEBPACK_IMPORTED_MODULE_1__["default"],
  save: _save__WEBPACK_IMPORTED_MODULE_2__["default"]
};

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-reach-player/save.js":
/*!*****************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-reach-player/save.js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);


/**
 * External dependencies
 */


var BlockSave = function BlockSave(_ref) {
  var attributes = _ref.attributes;
  var dataEmbedId = attributes.dataEmbedId,
      ampLayout = attributes.ampLayout,
      height = attributes.height,
      width = attributes.width;
  var reachProps = {
    layout: ampLayout,
    height: height,
    'data-embed-id': dataEmbedId
  };

  if ('fixed-height' !== ampLayout && width) {
    reachProps.width = width;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("amp-reach-player", reachProps);
};

BlockSave.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    dataEmbedId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
  })
};
/* harmony default export */ __webpack_exports__["default"] = (BlockSave);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-springboard-player/edit.js":
/*!***********************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-springboard-player/edit.js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js");
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../components */ "./assets/src/block-editor/components/index.js");



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



var BlockEdit = function BlockEdit(props) {
  var attributes = props.attributes,
      setAttributes = props.setAttributes;
  var dataSiteId = attributes.dataSiteId,
      dataPlayerId = attributes.dataPlayerId,
      dataContentId = attributes.dataContentId,
      dataDomain = attributes.dataDomain,
      dataMode = attributes.dataMode,
      dataItems = attributes.dataItems;
  var ampLayoutOptions = [{
    value: 'responsive',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Responsive', 'amp')
  }, {
    value: 'fixed',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed', 'amp')
  }, {
    value: 'fill',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fill', 'amp')
  }, {
    value: 'flex-item',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Flex-item', 'amp')
  }];
  var url = false;

  if (dataSiteId && dataContentId && dataDomain && dataMode && dataItems) {
    url = 'https://cms.springboardplatform.com/embed_iframe/';
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_4__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Springboard Player Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Site ID (required)', 'amp'),
    value: dataSiteId,
    onChange: function onChange(value) {
      return setAttributes({
        dataSiteId: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Content ID (required)', 'amp'),
    value: dataContentId,
    onChange: function onChange(value) {
      return setAttributes({
        dataContentId: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Player ID', 'amp'),
    value: dataPlayerId,
    onChange: function onChange(value) {
      return setAttributes({
        dataPlayerId: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Springboard partner domain', 'amp'),
    value: dataDomain,
    onChange: function onChange(value) {
      return setAttributes({
        dataDomain: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["SelectControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Mode (required)', 'amp'),
    value: dataMode,
    options: [{
      value: 'video',
      label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Video', 'amp')
    }, {
      value: 'playlist',
      label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Playlist', 'amp')
    }],
    onChange: function onChange(value) {
      return setAttributes({
        dataMode: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["TextControl"], {
    type: "number",
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Number of video is playlist (required)', 'amp'),
    value: dataItems,
    onChange: function onChange(value) {
      return setAttributes({
        dataItems: value
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["LayoutControls"], _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })))), url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_6__["MediaPlaceholder"], {
    name: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Springboard Player', 'amp'),
    url: url
  }), !url && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_5__["Placeholder"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Springboard Player', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("p", null, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Add required data to use the block.', 'amp'))));
};

BlockEdit.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.shape({
    dataSiteId: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataPlayerId: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataContentId: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataDomain: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    dataMode: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.oneOf(['video', 'playlist']),
    dataItems: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.number
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired
};
/* harmony default export */ __webpack_exports__["default"] = (BlockEdit);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-springboard-player/index.js":
/*!************************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-springboard-player/index.js ***!
  \************************************************************************/
/*! exports provided: name, settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return settings; });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit */ "./assets/src/block-editor/blocks/amp-springboard-player/edit.js");
/* harmony import */ var _save__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./save */ "./assets/src/block-editor/blocks/amp-springboard-player/save.js");
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



var name = 'amp/amp-springboard-player';
var settings = {
  title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('AMP Springboard Player', 'amp'),
  description: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Displays the Springboard Player used in the Springboard Video Platform', 'amp'),
  category: 'embed',
  icon: 'embed-generic',
  keywords: [Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Embed', 'amp')],
  attributes: {
    dataSiteId: {
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-site-id'
    },
    dataContentId: {
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-content-id'
    },
    dataPlayerId: {
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-player-id'
    },
    dataDomain: {
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-domain'
    },
    dataMode: {
      default: 'video',
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-mode'
    },
    dataItems: {
      default: 1,
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'data-items'
    },
    ampLayout: {
      default: 'responsive',
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'layout'
    },
    width: {
      default: 600,
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'width'
    },
    height: {
      default: 400,
      source: 'attribute',
      selector: 'amp-springboard-player',
      attribute: 'height'
    }
  },
  edit: _edit__WEBPACK_IMPORTED_MODULE_1__["default"],
  save: _save__WEBPACK_IMPORTED_MODULE_2__["default"]
};

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-springboard-player/save.js":
/*!***********************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-springboard-player/save.js ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);


/**
 * External dependencies
 */


var BlockSave = function BlockSave(_ref) {
  var attributes = _ref.attributes;
  var dataSiteId = attributes.dataSiteId,
      dataPlayerId = attributes.dataPlayerId,
      dataContentId = attributes.dataContentId,
      dataDomain = attributes.dataDomain,
      dataMode = attributes.dataMode,
      dataItems = attributes.dataItems,
      ampLayout = attributes.ampLayout,
      height = attributes.height,
      width = attributes.width;
  var springboardProps = {
    layout: ampLayout,
    height: height,
    'data-site-id': dataSiteId,
    'data-mode': dataMode,
    'data-content-id': dataContentId,
    'data-player-id': dataPlayerId,
    'data-domain': dataDomain,
    'data-items': dataItems
  };

  if ('fixed-height' !== ampLayout && width) {
    springboardProps.width = attributes.width;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("amp-springboard-player", springboardProps);
};

BlockSave.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    dataSiteId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataPlayerId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataContentId: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataDomain: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    dataMode: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.oneOf(['video', 'playlist']),
    dataItems: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
  })
};
/* harmony default export */ __webpack_exports__["default"] = (BlockSave);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-timeago/edit.js":
/*!************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-timeago/edit.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js");
/* harmony import */ var _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! moment */ "moment");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components */ "./assets/src/block-editor/components/index.js");



/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



var BlockEdit = function BlockEdit(props) {
  var attributes = props.attributes,
      setAttributes = props.setAttributes;
  var align = attributes.align,
      cutoff = attributes.cutoff,
      dateTime = attributes.dateTime;
  var timeAgo;

  if (dateTime) {
    if (cutoff && parseInt(cutoff) < Math.abs(moment__WEBPACK_IMPORTED_MODULE_2___default()(dateTime).diff(moment__WEBPACK_IMPORTED_MODULE_2___default()(), 'seconds'))) {
      timeAgo = moment__WEBPACK_IMPORTED_MODULE_2___default()(dateTime).format('dddd D MMMM HH:mm');
    } else {
      timeAgo = moment__WEBPACK_IMPORTED_MODULE_2___default()(dateTime).fromNow();
    }
  } else {
    timeAgo = moment__WEBPACK_IMPORTED_MODULE_2___default()(Date.now()).fromNow();
    setAttributes({
      dateTime: moment__WEBPACK_IMPORTED_MODULE_2___default()(moment__WEBPACK_IMPORTED_MODULE_2___default()(), moment__WEBPACK_IMPORTED_MODULE_2___default.a.ISO_8601, true).format()
    });
  }

  var ampLayoutOptions = [{
    value: '',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["__"])('Responsive', 'amp')
  }, {
    value: 'fixed',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["__"])('Fixed', 'amp')
  }, {
    value: 'fixed-height',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["__"])('Fixed Height', 'amp')
  }];
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_6__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["__"])('AMP Timeago Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_6__["DateTimePicker"], {
    locale: "en",
    currentDate: dateTime || moment__WEBPACK_IMPORTED_MODULE_2___default()(),
    onChange: function onChange(value) {
      return setAttributes({
        dateTime: moment__WEBPACK_IMPORTED_MODULE_2___default()(value, moment__WEBPACK_IMPORTED_MODULE_2___default.a.ISO_8601, true).format()
      });
    }
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_components__WEBPACK_IMPORTED_MODULE_7__["LayoutControls"], _babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, props, {
    ampLayoutOptions: ampLayoutOptions
  })), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_6__["TextControl"], {
    type: "number",
    className: "blocks-amp-timeout__cutoff",
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["__"])('Cutoff (seconds)', 'amp'),
    value: cutoff !== undefined ? cutoff : '',
    onChange: function onChange(value) {
      return setAttributes({
        cutoff: value
      });
    }
  }))), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__["BlockControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__["BlockAlignmentToolbar"], {
    value: align,
    onChange: function onChange(nextAlign) {
      setAttributes({
        align: nextAlign
      });
    },
    controls: ['left', 'center', 'right']
  })), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_1__["createElement"])("time", {
    dateTime: dateTime
  }, timeAgo));
};

BlockEdit.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.shape({
    align: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string,
    cutoff: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.number,
    dateTime: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func.isRequired
};
/* harmony default export */ __webpack_exports__["default"] = (BlockEdit);

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-timeago/index.js":
/*!*************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-timeago/index.js ***!
  \*************************************************************/
/*! exports provided: name, settings */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "settings", function() { return settings; });
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _edit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./edit */ "./assets/src/block-editor/blocks/amp-timeago/edit.js");
/* harmony import */ var _save__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./save */ "./assets/src/block-editor/blocks/amp-timeago/save.js");
/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



var name = 'amp/amp-timeago';
var settings = {
  title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('AMP Timeago', 'amp'),
  category: 'common',
  icon: 'backup',
  keywords: [Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Time difference', 'amp'), Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Time ago', 'amp'), Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_0__["__"])('Date', 'amp')],
  attributes: {
    align: {
      type: 'string'
    },
    cutoff: {
      source: 'attribute',
      selector: 'amp-timeago',
      attribute: 'cutoff'
    },
    dateTime: {
      source: 'attribute',
      selector: 'amp-timeago',
      attribute: 'datetime'
    },
    ampLayout: {
      default: 'fixed-height',
      source: 'attribute',
      selector: 'amp-timeago',
      attribute: 'layout'
    },
    width: {
      source: 'attribute',
      selector: 'amp-timeago',
      attribute: 'width'
    },
    height: {
      default: 20,
      source: 'attribute',
      selector: 'amp-timeago',
      attribute: 'height'
    }
  },
  getEditWrapperProps: function getEditWrapperProps(attributes) {
    var align = attributes.align;

    if ('left' === align || 'right' === align || 'center' === align) {
      return {
        'data-align': align
      };
    }

    return undefined;
  },
  edit: _edit__WEBPACK_IMPORTED_MODULE_1__["default"],
  save: _save__WEBPACK_IMPORTED_MODULE_2__["default"]
};

/***/ }),

/***/ "./assets/src/block-editor/blocks/amp-timeago/save.js":
/*!************************************************************!*\
  !*** ./assets/src/block-editor/blocks/amp-timeago/save.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! moment */ "moment");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);


/**
 * External dependencies
 */



var BlockSave = function BlockSave(_ref) {
  var attributes = _ref.attributes;
  var ampLayout = attributes.ampLayout,
      width = attributes.width,
      height = attributes.height,
      align = attributes.align,
      cutoff = attributes.cutoff,
      dateTime = attributes.dateTime;
  var timeagoProps = {
    layout: 'responsive',
    className: 'align' + (align || 'none'),
    datetime: dateTime,
    locale: 'en'
  };

  if (cutoff) {
    timeagoProps.cutoff = cutoff;
  }

  if (ampLayout) {
    switch (ampLayout) {
      case 'fixed-height':
        if (height) {
          timeagoProps.height = height;
          timeagoProps.layout = ampLayout;
        }

        break;

      case 'fixed':
        if (height && width) {
          timeagoProps.height = height;
          timeagoProps.width = width;
          timeagoProps.layout = ampLayout;
        }

        break;

      default:
        break;
    }
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("amp-timeago", timeagoProps, moment__WEBPACK_IMPORTED_MODULE_1___default()(attributes.dateTime).format('dddd D MMMM HH:mm'));
};

BlockSave.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.shape({
    width: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.number,
    height: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.number,
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    align: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
    cutoff: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.number,
    dateTime: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string
  })
};
/* harmony default export */ __webpack_exports__["default"] = (BlockSave);

/***/ }),

/***/ "./assets/src/block-editor/components/amp-preview-button.js":
/*!******************************************************************!*\
  !*** ./assets/src/block-editor/components/amp-preview-button.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/inherits */ "./node_modules/@babel/runtime/helpers/inherits.js");
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @wordpress/compose */ "@wordpress/compose");
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_wordpress_compose__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _wordpress_url__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @wordpress/url */ "@wordpress/url");
/* harmony import */ var _wordpress_url__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_wordpress_url__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../helpers */ "./assets/src/block-editor/helpers/index.js");








function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default()(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default()(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4___default()(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }



/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */







/**
 * Internal dependencies
 */



var ampFilledIcon = function ampFilledIcon(props) {
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["createElement"])("svg", props, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["createElement"])("path", {
    d: "M41.629 28.161L28.624 49.804h-2.356l2.33-14.102-7.214.009-.1.002c-.65 0-1.176-.526-1.176-1.176 0-.279.259-.751.259-.751L33.329 12.17l2.395.01-2.388 14.123 7.251-.009h.115c.65 0 1.176.525 1.176 1.175 0 .264-.103.495-.25.691v.001zM31 0C13.879 0 0 13.88 0 31c0 17.121 13.879 31 31 31 17.12 0 31-13.879 31-31C62 13.88 48.12 0 31 0z",
    fill: "#82878c"
  }));
};

ampFilledIcon.defaultProps = {
  width: "62",
  height: "62",
  viewBox: "0 0 62 62",
  xmlns: "http://www.w3.org/2000/svg"
};

var ampBlackIcon = function ampBlackIcon(props) {
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["createElement"])("svg", props, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["createElement"])("path", {
    className: "outer",
    d: "M48 12c19.9 0 36 16.1 36 36S67.9 84 48 84 12 67.9 12 48s16.1-36 36-36",
    fill: "none"
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["createElement"])("path", {
    className: "inner",
    d: "M48 33c8.285 0 15 6.716 15 15 0 8.284-6.715 15-15 15-8.284 0-15-6.716-15-15 0-8.284 6.716-15 15-15zm-1.15 24.098l6.293-10.472a.555.555 0 0 0 .12-.335.569.569 0 0 0-.624-.568l-3.508.004 1.155-6.834-1.159-.005-6.272 10.46s-.125.228-.125.363c0 .314.255.57.569.57l.048-.001 3.49-.005-1.126 6.823h1.14z",
    fill: "none"
  }));
};

ampBlackIcon.defaultProps = {
  xmlns: "http://www.w3.org/2000/svg"
};
/**
 * Writes the message and graphic in the new preview window that was opened.
 *
 * Forked from the Core component <PostPreviewButton>.
 *
 * @see https://github.com/WordPress/gutenberg/blob/95e769df1f82f6b0ef587d81af65dd2f48cd1c38/packages/editor/src/components/post-preview-button/index.js#L17-L93
 * @param {Document} targetDocument The target document.
 */

function writeInterstitialMessage(targetDocument) {
  var markup = Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["renderToString"])(Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["createElement"])("div", {
    className: "editor-post-preview-button__interstitial-message"
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_9__["Icon"], {
    icon: ampBlackIcon({
      viewBox: '0 0 98 98'
    })
  }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["createElement"])("p", null, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_12__["__"])('Generating AMP preview…', 'amp'))));
  markup += "\n\t\t<style>\n\t\t\tbody {\n\t\t\t\tmargin: 0;\n\t\t\t}\n\t\t\t.editor-post-preview-button__interstitial-message {\n\t\t\t\tdisplay: flex;\n\t\t\t\tflex-direction: column;\n\t\t\t\talign-items: center;\n\t\t\t\tjustify-content: center;\n\t\t\t\theight: 100vh;\n\t\t\t\twidth: 100vw;\n\t\t\t}\n\t\t\t@-webkit-keyframes paint {\n\t\t\t\t0% {\n\t\t\t\t\tstroke-dashoffset: 0;\n\t\t\t\t}\n\t\t\t}\n\t\t\t@-moz-keyframes paint {\n\t\t\t\t0% {\n\t\t\t\t\tstroke-dashoffset: 0;\n\t\t\t\t}\n\t\t\t}\n\t\t\t@-o-keyframes paint {\n\t\t\t\t0% {\n\t\t\t\t\tstroke-dashoffset: 0;\n\t\t\t\t}\n\t\t\t}\n\t\t\t@keyframes paint {\n\t\t\t\t0% {\n\t\t\t\t\tstroke-dashoffset: 0;\n\t\t\t\t}\n\t\t\t}\n\t\t\t.editor-post-preview-button__interstitial-message svg {\n\t\t\t\twidth: 198px;\n\t\t\t\theight: 198px;\n\t\t\t\tstroke: #555d66;\n\t\t\t\tstroke-width: 0.75;\n\t\t\t}\n\t\t\t.editor-post-preview-button__interstitial-message svg .outer,\n\t\t\t.editor-post-preview-button__interstitial-message svg .inner {\n\t\t\t\tstroke-dasharray: 280;\n\t\t\t\tstroke-dashoffset: 280;\n\t\t\t\t-webkit-animation: paint 1.5s ease infinite alternate;\n\t\t\t\t-moz-animation: paint 1.5s ease infinite alternate;\n\t\t\t\t-o-animation: paint 1.5s ease infinite alternate;\n\t\t\t\tanimation: paint 1.5s ease infinite alternate;\n\t\t\t}\n\t\t\tp {\n\t\t\t\ttext-align: center;\n\t\t\t\tfont-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen-Sans, Ubuntu, Cantarell, \"Helvetica Neue\", sans-serif;\n\t\t\t}\n\t\t</style>\n\t";
  targetDocument.write(markup);
  targetDocument.title = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_12__["__"])('Generating AMP preview…', 'amp');
  targetDocument.close();
}
/**
 * A 'Preview AMP' button, forked from the Core 'Preview' button: <PostPreviewButton>.
 *
 * @see https://github.com/WordPress/gutenberg/blob/95e769df1f82f6b0ef587d81af65dd2f48cd1c38/packages/editor/src/components/post-preview-button/index.js#L95-L200
 */


var AmpPreviewButton = /*#__PURE__*/function (_Component) {
  _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(AmpPreviewButton, _Component);

  var _super = _createSuper(AmpPreviewButton);

  /**
   * Constructs the class.
   *
   * @param {*} args Constructor arguments.
   */
  function AmpPreviewButton() {
    var _this;

    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, AmpPreviewButton);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    _this.buttonRef = Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["createRef"])();
    _this.openPreviewWindow = _this.openPreviewWindow.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    return _this;
  }
  /**
   * Called after the component is updated.
   *
   * @param {Object} prevProps The previous props.
   */


  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(AmpPreviewButton, [{
    key: "componentDidUpdate",
    value: function componentDidUpdate(prevProps) {
      var previewLink = this.props.previewLink; // This relies on the window being responsible to unset itself when
      // navigation occurs or a new preview window is opened, to avoid
      // unintentional forceful redirects.

      if (previewLink && !prevProps.previewLink) {
        this.setPreviewWindowLink(previewLink);
      }
    }
    /**
     * Sets the preview window's location to the given URL, if a preview window
     * exists and is not closed.
     *
     * @param {string} url URL to assign as preview window location.
     */

  }, {
    key: "setPreviewWindowLink",
    value: function setPreviewWindowLink(url) {
      var previewWindow = this.previewWindow;

      if (previewWindow && !previewWindow.closed) {
        previewWindow.location = url;

        if (this.buttonRef.current) {
          this.buttonRef.current.focus();
        }
      }
    }
    /**
     * Gets the window target.
     */

  }, {
    key: "getWindowTarget",
    value: function getWindowTarget() {
      var postId = this.props.postId;
      return "amp-preview-".concat(postId);
    }
    /**
     * Opens the preview window.
     *
     * @param {Event} event The DOM event.
     */

  }, {
    key: "openPreviewWindow",
    value: function openPreviewWindow(event) {
      // Our Preview button has its 'href' and 'target' set correctly for a11y
      // purposes. Unfortunately, though, we can't rely on the default 'click'
      // handler since sometimes it incorrectly opens a new tab instead of reusing
      // the existing one.
      // https://github.com/WordPress/gutenberg/pull/8330
      event.preventDefault(); // Open up a Preview tab if needed. This is where we'll show the preview.

      if (!this.previewWindow || this.previewWindow.closed) {
        this.previewWindow = window.open('', this.getWindowTarget());
      } // Focus the Preview tab. This might not do anything, depending on the browser's
      // and user's preferences.
      // https://html.spec.whatwg.org/multipage/interaction.html#dom-window-focus


      this.previewWindow.focus(); // If we don't need to autosave the post before previewing, then we simply
      // load the Preview URL in the Preview tab.

      if (!this.props.isAutosaveable) {
        this.setPreviewWindowLink(event.target.href);
        return;
      } // Request an autosave. This happens asynchronously and causes the component
      // to update when finished.


      if (this.props.isDraft) {
        this.props.savePost({
          isPreview: true
        });
      } else {
        this.props.autosave({
          isPreview: true
        });
      } // Display a 'Generating preview' message in the Preview tab while we wait for the
      // autosave to finish.


      writeInterstitialMessage(this.previewWindow.document);
    }
    /**
     * Renders the component.
     */

  }, {
    key: "render",
    value: function render() {
      var _this$props = this.props,
          previewLink = _this$props.previewLink,
          currentPostLink = _this$props.currentPostLink,
          errorMessages = _this$props.errorMessages,
          isEnabled = _this$props.isEnabled,
          isSaveable = _this$props.isSaveable,
          isStandardMode = _this$props.isStandardMode; // Link to the `?preview=true` URL if we have it, since this lets us see
      // changes that were autosaved since the post was last published. Otherwise,
      // just link to the post's URL.

      var href = previewLink || currentPostLink;
      return isEnabled && !errorMessages.length && !isStandardMode && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_9__["Button"], {
        className: "amp-editor-post-preview",
        href: href,
        title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_12__["__"])('Preview AMP', 'amp'),
        isSecondary: true,
        disabled: !isSaveable,
        onClick: this.openPreviewWindow,
        ref: this.buttonRef
      }, ampFilledIcon({
        viewBox: '0 0 62 62',
        width: 18,
        height: 18
      }), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["createElement"])("span", {
        className: "screen-reader-text"
      },
      /* translators: accessibility text */
      Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_12__["__"])('(opens in a new tab)', 'amp')));
    }
  }]);

  return AmpPreviewButton;
}(_wordpress_element__WEBPACK_IMPORTED_MODULE_6__["Component"]);

AmpPreviewButton.propTypes = {
  autosave: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.func.isRequired,
  currentPostLink: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.string.isRequired,
  postId: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.number.isRequired,
  previewLink: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.string,
  isAutosaveable: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.bool.isRequired,
  isDraft: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.bool.isRequired,
  isEnabled: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.bool.isRequired,
  isSaveable: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.bool.isRequired,
  savePost: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.func.isRequired,
  errorMessages: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.array,
  isStandardMode: prop_types__WEBPACK_IMPORTED_MODULE_8___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (Object(_wordpress_compose__WEBPACK_IMPORTED_MODULE_10__["compose"])([Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_11__["withSelect"])(function (select, _ref) {
  var forcePreviewLink = _ref.forcePreviewLink,
      forceIsAutosaveable = _ref.forceIsAutosaveable;

  var _select = select('core/editor'),
      getCurrentPostId = _select.getCurrentPostId,
      getCurrentPostAttribute = _select.getCurrentPostAttribute,
      getEditedPostAttribute = _select.getEditedPostAttribute,
      isEditedPostSaveable = _select.isEditedPostSaveable,
      isEditedPostAutosaveable = _select.isEditedPostAutosaveable,
      getEditedPostPreviewLink = _select.getEditedPostPreviewLink;

  var _select2 = select('amp/block-editor'),
      getAmpSlug = _select2.getAmpSlug,
      getErrorMessages = _select2.getErrorMessages,
      isStandardMode = _select2.isStandardMode;

  var queryArgs = {};
  queryArgs[getAmpSlug()] = 1;
  var initialPreviewLink = getEditedPostPreviewLink();
  var previewLink = initialPreviewLink ? Object(_wordpress_url__WEBPACK_IMPORTED_MODULE_13__["addQueryArgs"])(initialPreviewLink, queryArgs) : undefined;
  return {
    postId: getCurrentPostId(),
    currentPostLink: Object(_wordpress_url__WEBPACK_IMPORTED_MODULE_13__["addQueryArgs"])(getCurrentPostAttribute('link'), queryArgs),
    previewLink: forcePreviewLink !== undefined ? forcePreviewLink : previewLink,
    isSaveable: isEditedPostSaveable(),
    isAutosaveable: forceIsAutosaveable || isEditedPostAutosaveable(),
    isDraft: ['draft', 'auto-draft'].indexOf(getEditedPostAttribute('status')) !== -1,
    isEnabled: Object(_helpers__WEBPACK_IMPORTED_MODULE_14__["isAMPEnabled"])(),
    errorMessages: getErrorMessages(),
    isStandardMode: isStandardMode()
  };
}), Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_11__["withDispatch"])(function (dispatch) {
  return {
    autosave: dispatch('core/editor').autosave,
    savePost: dispatch('core/editor').savePost
  };
})])(AmpPreviewButton));

/***/ }),

/***/ "./assets/src/block-editor/components/index.js":
/*!*****************************************************!*\
  !*** ./assets/src/block-editor/components/index.js ***!
  \*****************************************************/
/*! exports provided: MediaPlaceholder, LayoutControls, withMediaLibraryNotice */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _media_placeholder__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./media-placeholder */ "./assets/src/block-editor/components/media-placeholder.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "MediaPlaceholder", function() { return _media_placeholder__WEBPACK_IMPORTED_MODULE_0__["default"]; });

/* harmony import */ var _layout_controls__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./layout-controls */ "./assets/src/block-editor/components/layout-controls.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "LayoutControls", function() { return _layout_controls__WEBPACK_IMPORTED_MODULE_1__["default"]; });

/* harmony import */ var _with_media_library_notice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./with-media-library-notice */ "./assets/src/block-editor/components/with-media-library-notice.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "withMediaLibraryNotice", function() { return _with_media_library_notice__WEBPACK_IMPORTED_MODULE_2__["default"]; });





/***/ }),

/***/ "./assets/src/block-editor/components/layout-controls.js":
/*!***************************************************************!*\
  !*** ./assets/src/block-editor/components/layout-controls.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__);


/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */



/**
 * Layout controls for AMP blocks' attributes: layout, width, height.
 *
 * @param {Object}   props                      Component props.
 * @param {Object}   props.attributes           Block attributes.
 * @param {Function} props.setAttributes        Callback to update block attributes.
 * @param {Array}    props.ampLayoutOptions     Layout options.
 *
 * @return {ReactElement} Controls.
 */

var LayoutControls = function LayoutControls(_ref) {
  var attributes = _ref.attributes,
      setAttributes = _ref.setAttributes,
      ampLayoutOptions = _ref.ampLayoutOptions;
  var ampLayout = attributes.ampLayout,
      height = attributes.height,
      width = attributes.width;
  var showHeightNotice = !height && ('fixed' === ampLayout || 'fixed-height' === ampLayout);
  var showWidthNotice = !width && 'fixed' === ampLayout;
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["SelectControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["__"])('Layout', 'amp'),
    value: ampLayout,
    options: ampLayoutOptions,
    onChange: function onChange(value) {
      return setAttributes({
        ampLayout: value
      });
    }
  }), showWidthNotice && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["Notice"], {
    status: "error",
    isDismissible: false
  }, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["sprintf"])(
  /* translators: %s is the layout name */
  Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["__"])('Width is required for %s layout', 'amp'), ampLayout)), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["TextControl"], {
    type: "number",
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["__"])('Width (px)', 'amp'),
    value: width !== undefined ? width : '',
    onChange: function onChange(value) {
      return setAttributes({
        width: value
      });
    }
  }), showHeightNotice && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["Notice"], {
    status: "error",
    isDismissible: false
  }, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["sprintf"])(
  /* translators: %s is the layout name */
  Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["__"])('Height is required for %s layout', 'amp'), ampLayout)), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["TextControl"], {
    type: "number",
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["__"])('Height (px)', 'amp'),
    value: height,
    onChange: function onChange(value) {
      return setAttributes({
        height: value
      });
    }
  }));
};

LayoutControls.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
  }).isRequired,
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired,
  ampLayoutOptions: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.arrayOf(prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    value: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
    label: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired
  })).isRequired
};
/* harmony default export */ __webpack_exports__["default"] = (LayoutControls);

/***/ }),

/***/ "./assets/src/block-editor/components/media-placeholder.js":
/*!*****************************************************************!*\
  !*** ./assets/src/block-editor/components/media-placeholder.js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__);


/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */



/**
 * Display media placeholder.
 *
 * @param {Object} props Component props.
 * @param {string} props.name Block's name.
 * @param {string} props.url URL.
 *
 * @return {ReactElement} Placeholder.
 */

var MediaPlaceholder = function MediaPlaceholder(_ref) {
  var name = _ref.name,
      url = _ref.url;
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["Placeholder"], {
    label: name
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
    className: "components-placeholder__error"
  }, url), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
    className: "components-placeholder__error"
  }, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_4__["__"])('Previews for this are unavailable in the editor, sorry!', 'amp')));
};

MediaPlaceholder.propTypes = {
  name: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string.isRequired,
  url: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (MediaPlaceholder);

/***/ }),

/***/ "./assets/src/block-editor/components/with-media-library-notice.js":
/*!*************************************************************************!*\
  !*** ./assets/src/block-editor/components/with-media-library-notice.js ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/inherits */ "./node_modules/@babel/runtime/helpers/inherits.js");
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _babel_runtime_helpers_get__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/helpers/get */ "./node_modules/@babel/runtime/helpers/get.js");
/* harmony import */ var _babel_runtime_helpers_get__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_get__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _common_components_select_media_frame__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../common/components/select-media-frame */ "./assets/src/common/components/select-media-frame.js");
/* harmony import */ var _common_helpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../common/helpers */ "./assets/src/common/helpers/index.js");









function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7___default()(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7___default()(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_5___default()(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */



var _window = window,
    wp = _window.wp;
/**
 * Gets a wrapped version of MediaUpload to display a notice for small images.
 *
 * Only applies to the MediaUpload in the Featured Image component, PostFeaturedImage.
 *
 * @param {Function} InitialMediaUpload The MediaUpload component, passed from the filter.
 * @param {Object}   minImageDimensions Minimum required image dimensions.
 * @return {Function} The wrapped component.
 */

/* harmony default export */ __webpack_exports__["default"] = (function (InitialMediaUpload, minImageDimensions) {
  var EXPECTED_WIDTH = minImageDimensions.width,
      EXPECTED_HEIGHT = minImageDimensions.height;
  /**
   * Mostly copied from customize-controls.js, with slight changes.
   *
   * @see https://github.com/WordPress/wordpress-develop/blob/c80325658f85d24ff82295dd2d55bfdf789f4163/src/js/_enqueues/wp/customize/controls.js#L4695
   * @see wp.media.HeaderControl
   */

  return /*#__PURE__*/function (_InitialMediaUpload) {
    _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_4___default()(FeaturedImageMediaUpload, _InitialMediaUpload);

    var _super = _createSuper(FeaturedImageMediaUpload);

    /**
     * Constructs the class.
     *
     * @param {*} args Constructor arguments.
     */
    function FeaturedImageMediaUpload() {
      var _thisSuper, _this;

      _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, FeaturedImageMediaUpload);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args)); // @todo This should be a different event.
      // This class should only be present in the MediaUpload for the Featured Image.

      if ('editor-post-featured-image__media-modal' === _this.props.modalClass) {
        _this.initFeaturedImage = _this.initFeaturedImage.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3___default()(_this));

        _this.initFeaturedImage();
      } else {
        // Restore the original`onOpen` callback as it will be overridden by the parent class.
        _this.frame.off('open', _this.onOpen);

        _this.frame.on('open', _babel_runtime_helpers_get__WEBPACK_IMPORTED_MODULE_6___default()((_thisSuper = _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3___default()(_this), _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_7___default()(FeaturedImageMediaUpload.prototype)), "onOpen", _thisSuper).bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_3___default()(_this)));
      }

      return _this;
    }
    /**
     * Initialize.
     *
     * Mainly copied from customize-controls.js, like most of this class.
     *
     * Overwrites the Media Library frame, this.frame.
     * Adds a suggested width and height.
     */


    _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default()(FeaturedImageMediaUpload, [{
      key: "initFeaturedImage",
      value: function initFeaturedImage() {
        var FeaturedImageSelectMediaFrame = Object(_common_components_select_media_frame__WEBPACK_IMPORTED_MODULE_9__["getSelectMediaFrame"])(_common_components_select_media_frame__WEBPACK_IMPORTED_MODULE_9__["FeaturedImageToolbarSelect"]);
        var FeaturedImageLibrary = wp.media.controller.FeaturedImage.extend({
          defaults: _objectSpread(_objectSpread({}, wp.media.controller.FeaturedImage.prototype.defaults), {}, {
            date: false,
            filterable: false,
            // Note: These suggestions are shown in the media library image browser.
            suggestedWidth: EXPECTED_WIDTH,
            suggestedHeight: EXPECTED_HEIGHT
          })
        });
        this.frame = new FeaturedImageSelectMediaFrame({
          allowedTypes: this.props.allowedTypes,
          state: 'featured-image',
          states: [new FeaturedImageLibrary(), new wp.media.controller.EditImage()]
        });
        this.frame.on('toolbar:create:featured-image', function (toolbar) {
          /**
           * @this wp.media.view.MediaFrame.Select
           */
          this.createSelectToolbar(toolbar, {
            text: wp.media.view.l10n.setFeaturedImage,
            state: this.options.state
          });
        }, this.frame);
        this.frame.on('open', this.onOpen);
        this.frame.state('featured-image').on('select', this.onSelectImage, this); // See wp.media() for this.

        wp.media.frame = this.frame;
      }
      /**
       * Ensure the selected image is the first item in the collection.
       *
       * @see https://github.com/WordPress/gutenberg/blob/c58b32266f8c950c5b9927d286608343078aee02/packages/media-utils/src/components/media-upload/index.js#L401-L417
       */

    }, {
      key: "onOpen",
      value: function onOpen() {
        var frameContent = this.frame.content.get();

        if (frameContent && frameContent.collection) {
          var collection = frameContent.collection; // Clean all attachments we have in memory.

          collection.toArray().forEach(function (model) {
            return model.trigger('destroy', model);
          }); // Reset has more flag, if library had small amount of items all items may have been loaded before.

          collection.mirroring._hasMore = true; // Request items.

          collection.more();
        }
      }
      /**
       * Handles image selection.
       */

    }, {
      key: "onSelectImage",
      value: function onSelectImage() {
        var attachment = this.frame.state('featured-image').get('selection').first().toJSON();

        var dispatchImage = function dispatchImage(attachmentId) {
          Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_8__["dispatch"])('core/editor').editPost({
            featured_media: attachmentId
          });
        };

        var onSelect = this.props.onSelect;
        var url = attachment.url,
            id = attachment.id,
            width = attachment.width,
            height = attachment.height;
        Object(_common_helpers__WEBPACK_IMPORTED_MODULE_10__["setImageFromURL"])({
          url: url,
          id: id,
          width: width,
          height: height,
          onSelect: onSelect,
          dispatchImage: dispatchImage
        });

        if (!wp.media.view.settings.post.featuredImageId) {
          return;
        }

        wp.media.featuredImage.set(attachment ? attachment.id : -1);
      }
    }]);

    return FeaturedImageMediaUpload;
  }(InitialMediaUpload);
});

/***/ }),

/***/ "./assets/src/block-editor/constants.js":
/*!**********************************************!*\
  !*** ./assets/src/block-editor/constants.js ***!
  \**********************************************/
/*! exports provided: TEXT_BLOCKS, MEDIA_BLOCKS, DEFAULT_WIDTH, DEFAULT_HEIGHT, POST_PREVIEW_CLASS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TEXT_BLOCKS", function() { return TEXT_BLOCKS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MEDIA_BLOCKS", function() { return MEDIA_BLOCKS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_WIDTH", function() { return DEFAULT_WIDTH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_HEIGHT", function() { return DEFAULT_HEIGHT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "POST_PREVIEW_CLASS", function() { return POST_PREVIEW_CLASS; });
var TEXT_BLOCKS = ['core/paragraph', 'core/heading', 'core/code', 'core/quote', 'core/subhead'];
var MEDIA_BLOCKS = ['core/image', 'core/video'];
var DEFAULT_WIDTH = 608; // Max-width in the editor.

var DEFAULT_HEIGHT = 400;
var POST_PREVIEW_CLASS = 'editor-post-preview';

/***/ }),

/***/ "./assets/src/block-editor/helpers/index.js":
/*!**************************************************!*\
  !*** ./assets/src/block-editor/helpers/index.js ***!
  \**************************************************/
/*! exports provided: addAMPAttributes, filterBlocksSave, getAmpFitTextContent, getLayoutOptions, filterBlocksEdit, setImageBlockLayoutAttributes, setUpInspectorControls, isAMPEnabled */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addAMPAttributes", function() { return addAMPAttributes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "filterBlocksSave", function() { return filterBlocksSave; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAmpFitTextContent", function() { return getAmpFitTextContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLayoutOptions", function() { return getLayoutOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "filterBlocksEdit", function() { return filterBlocksEdit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setImageBlockLayoutAttributes", function() { return setImageBlockLayoutAttributes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setUpInspectorControls", function() { return setUpInspectorControls; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isAMPEnabled", function() { return isAMPEnabled; });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../constants */ "./assets/src/block-editor/constants.js");
/* harmony import */ var _common_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../common/constants */ "./assets/src/common/constants.js");


function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */






/**
 * Internal dependencies
 */



var ampLayoutOptions = [{
  value: 'nodisplay',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('No Display', 'amp'),
  notAvailable: ['core-embed/vimeo', 'core-embed/dailymotion', 'core-embed/reddit', 'core-embed/soundcloud']
}, {
  // Not supported by amp-audio and amp-pixel.
  value: 'fixed',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed', 'amp'),
  notAvailable: ['core-embed/soundcloud']
}, {
  // To ensure your AMP element displays, you must specify a width and height for the containing element.
  value: 'responsive',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Responsive', 'amp'),
  notAvailable: ['core-embed/soundcloud']
}, {
  value: 'fixed-height',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed Height', 'amp'),
  notAvailable: []
}, {
  value: 'fill',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fill', 'amp'),
  notAvailable: ['core-embed/soundcloud']
}, {
  value: 'flex-item',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Flex Item', 'amp'),
  notAvailable: ['core-embed/soundcloud']
}, {
  // Not supported by video.
  value: 'intrinsic',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Intrinsic', 'amp'),
  notAvailable: ['core/video', 'core-embed/youtube', 'core-embed/facebook', 'core-embed/instagram', 'core-embed/vimeo', 'core-embed/dailymotion', 'core-embed/reddit', 'core-embed/soundcloud']
}];
/**
 * Add AMP attributes to every core block.
 *
 * @param {Object} settings Block settings.
 * @param {string} name     Block name.
 *
 * @return {Object} Modified block settings.
 */

var addAMPAttributes = function addAMPAttributes(settings, name) {
  // AMP Carousel settings.
  if ('core/gallery' === name) {
    if (!settings.attributes) {
      settings.attributes = {};
    }

    settings.attributes.ampCarousel = {
      type: 'boolean',
      default: !Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_6__["select"])('amp/block-editor').hasThemeSupport() // @todo We could just default this to false now even in Reader mode since block styles are loaded.

    };
    settings.attributes.ampLightbox = {
      type: 'boolean',
      default: false
    };
  } // Add AMP Lightbox settings.


  if ('core/image' === name) {
    if (!settings.attributes) {
      settings.attributes = {};
    }

    settings.attributes.ampLightbox = {
      type: 'boolean',
      default: false
    };
  }

  var isTextBlock = _constants__WEBPACK_IMPORTED_MODULE_7__["TEXT_BLOCKS"].includes(name); // Fit-text for text blocks.

  if (isTextBlock) {
    if (!settings.attributes) {
      settings.attributes = {};
    }

    settings.attributes.ampFitText = {
      type: 'boolean',
      default: false
    };
    settings.attributes.minFont = {
      default: _common_constants__WEBPACK_IMPORTED_MODULE_8__["MIN_FONT_SIZE"],
      source: 'attribute',
      selector: 'amp-fit-text',
      attribute: 'min-font-size'
    };
    settings.attributes.maxFont = {
      default: _common_constants__WEBPACK_IMPORTED_MODULE_8__["MAX_FONT_SIZE"],
      source: 'attribute',
      selector: 'amp-fit-text',
      attribute: 'max-font-size'
    };
    settings.attributes.height = {
      // Needs to be higher than the maximum font size, which defaults to MAX_FONT_SIZE
      default: 'core/image' === name ? 200 : Math.ceil(_common_constants__WEBPACK_IMPORTED_MODULE_8__["MAX_FONT_SIZE"] / 10) * 10,
      source: 'attribute',
      selector: 'amp-fit-text',
      attribute: 'height'
    };
  } // Layout settings for embeds and media blocks.


  if (0 === name.indexOf('core-embed') || _constants__WEBPACK_IMPORTED_MODULE_7__["MEDIA_BLOCKS"].includes(name)) {
    if (!settings.attributes) {
      settings.attributes = {};
    }

    settings.attributes.ampLayout = {
      type: 'string'
    };
    settings.attributes.ampNoLoading = {
      type: 'boolean'
    };
  }

  return settings;
};
/**
 * Filters blocks' save function.
 *
 * @param {Object} element        Element to be saved.
 * @param {string} blockType      Block type.
 * @param {string} blockType.name Block type name.
 * @param {Object} attributes     Attributes.
 *
 * @return {Object} Output element.
 */

var filterBlocksSave = function filterBlocksSave(element, blockType, attributes) {
  // eslint-disable-line complexity
  var fitTextProps = {
    layout: 'fixed-height'
  };

  if ('core/paragraph' === blockType.name && !attributes.ampFitText) {
    var content = getAmpFitTextContent(attributes.content);

    if (content !== attributes.content) {
      return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["cloneElement"])(element, {
        key: 'new',
        value: content
      });
    }
  } else if (_constants__WEBPACK_IMPORTED_MODULE_7__["TEXT_BLOCKS"].includes(blockType.name) && attributes.ampFitText) {
    if (attributes.minFont) {
      fitTextProps['min-font-size'] = attributes.minFont;
    }

    if (attributes.maxFont) {
      fitTextProps['max-font-size'] = attributes.maxFont;
    }

    if (attributes.height) {
      fitTextProps.height = attributes.height;
    }

    fitTextProps.children = element;
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("amp-fit-text", fitTextProps);
  }

  return element;
};
/**
 * Returns the inner content of an AMP Fit Text tag.
 *
 * @param {string} content Original content.
 *
 * @return {string} Modified content.
 */

var getAmpFitTextContent = function getAmpFitTextContent(content) {
  var contentRegex = /<amp-fit-text\b[^>]*>(.*?)<\/amp-fit-text>/;
  var match = contentRegex.exec(content);
  var newContent = content;

  if (match && match[1]) {
    newContent = match[1];
  }

  return newContent;
};
/**
 * Get layout options depending on the block.
 *
 * @param {string} block Block name.
 *
 * @return {Object[]} Options.
 */

var getLayoutOptions = function getLayoutOptions(block) {
  var layoutOptions = [{
    value: '',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Default', 'amp')
  }];

  var _iterator = _createForOfIteratorHelper(ampLayoutOptions),
      _step;

  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var option = _step.value;
      var isLayoutAvailable = !option.notAvailable.includes(block);

      if (isLayoutAvailable) {
        layoutOptions.push({
          value: option.value,
          label: option.label
        });
      }
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }

  return layoutOptions;
};
/**
 * Filters blocks edit function of all blocks.
 *
 * @param {Function} BlockEdit function.
 *
 * @return {Function} Edit function.
 */

var filterBlocksEdit = function filterBlocksEdit(BlockEdit) {
  var EnhancedBlockEdit = function EnhancedBlockEdit(props) {
    var ampLayout = props.attributes.ampLayout,
        name = props.name;
    var inspectorControls;

    if ('core/gallery' === name) {
      inspectorControls = setUpGalleryInspectorControls(props);
    } else if ('core/image' === name) {
      inspectorControls = setUpImageInspectorControls(props);
    } else if (_constants__WEBPACK_IMPORTED_MODULE_7__["MEDIA_BLOCKS"].includes(name) || 0 === name.indexOf('core-embed/')) {
      inspectorControls = setUpInspectorControls(props);
    } else if (_constants__WEBPACK_IMPORTED_MODULE_7__["TEXT_BLOCKS"].includes(name)) {
      inspectorControls = setUpTextBlocksInspectorControls(props);
    } // Return just inspector controls in case of 'nodisplay'.


    if (ampLayout && 'nodisplay' === ampLayout) {
      return [inspectorControls];
    }

    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(BlockEdit, props), inspectorControls);
  };

  EnhancedBlockEdit.propTypes = {
    attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
      text: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
      ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
    }),
    setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired,
    name: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
  };
  return EnhancedBlockEdit;
};
/**
 * Set width and height in case of image block.
 *
 * @param {Object} props Props.
 * @param {Function} props.setAttributes Callback to set attributes.
 * @param {Object} props.attributes Attributes.
 * @param {string} layout Layout.
 */

var setImageBlockLayoutAttributes = function setImageBlockLayoutAttributes(props, layout) {
  var attributes = props.attributes,
      setAttributes = props.setAttributes;

  switch (layout) {
    case 'fixed-height':
      if (!attributes.height) {
        setAttributes({
          height: _constants__WEBPACK_IMPORTED_MODULE_7__["DEFAULT_HEIGHT"]
        });
      } // Lightbox doesn't work with fixed height, so unset it.


      if (attributes.ampLightbox) {
        setAttributes({
          ampLightbox: false
        });
      }

      break;

    case 'fixed':
      if (!attributes.height) {
        setAttributes({
          height: _constants__WEBPACK_IMPORTED_MODULE_7__["DEFAULT_HEIGHT"]
        });
      }

      if (!attributes.width) {
        setAttributes({
          width: _constants__WEBPACK_IMPORTED_MODULE_7__["DEFAULT_WIDTH"]
        });
      }

      break;

    default:
      break;
  }
};
/**
 * Default setup for inspector controls.
 *
 * @param {Object} props Props.
 *
 * @return {ReactElement} Inspector Controls.
 */

var setUpInspectorControls = function setUpInspectorControls(props) {
  var isSelected = props.isSelected;

  if (!isSelected) {
    return null;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpLayoutControl, props), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpNoloadingToggle, props)));
};
setUpInspectorControls.propTypes = {
  isSelected: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
};
/**
 * Get AMP Layout select control.
 *
 * @param {Object} props Props.
 *
 * @return {ReactElement} Element.
 */

var AmpLayoutControl = function AmpLayoutControl(props) {
  var name = props.name,
      ampLayout = props.attributes.ampLayout,
      setAttributes = props.setAttributes;

  var label = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Layout', 'amp');

  if ('core/image' === name) {
    label = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Layout (modifies width/height)', 'amp');
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["SelectControl"], {
    label: label,
    value: ampLayout,
    options: getLayoutOptions(name),
    onChange: function onChange(value) {
      setAttributes({
        ampLayout: value
      });

      if ('core/image' === props.name) {
        setImageBlockLayoutAttributes(props, value);
      }
    }
  });
};

AmpLayoutControl.propTypes = {
  name: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired
};
/**
 * Get AMP Noloading toggle control.
 *
 * @param {Object} props Props.
 *
 * @return {ReactElement} Element.
 */

var AmpNoloadingToggle = function AmpNoloadingToggle(props) {
  var ampNoLoading = props.attributes.ampNoLoading,
      setAttributes = props.setAttributes;

  var label = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Noloading', 'amp');

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["ToggleControl"], {
    label: label,
    checked: ampNoLoading,
    onChange: function onChange() {
      return setAttributes({
        ampNoLoading: !ampNoLoading
      });
    }
  });
};

AmpNoloadingToggle.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampNoLoading: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired
};
/**
 * Setup inspector controls for text blocks.
 *
 * @todo Consider wrapping the render function to delete the original font size in text settings when ampFitText.
 *
 * @param {Object} props Props.
 * @param {Function} props.setAttributes Callback to set attributes.
 * @param {Object} props.attributes Attributes.
 * @param {boolean} props.isSelected Is selected.
 *
 * @return {ReactElement} Inspector Controls.
 */

var setUpTextBlocksInspectorControls = function setUpTextBlocksInspectorControls(props) {
  var isSelected = props.isSelected,
      attributes = props.attributes,
      setAttributes = props.setAttributes;
  var ampFitText = attributes.ampFitText;
  var minFont = attributes.minFont,
      maxFont = attributes.maxFont,
      height = attributes.height;
  var FONT_SIZES = [{
    name: 'small',
    shortName: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["_x"])('S', 'font size', 'amp'),
    size: 14
  }, {
    name: 'regular',
    shortName: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["_x"])('M', 'font size', 'amp'),
    size: 16
  }, {
    name: 'large',
    shortName: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["_x"])('L', 'font size', 'amp'),
    size: 36
  }, {
    name: 'larger',
    shortName: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["_x"])('XL', 'font size', 'amp'),
    size: 48
  }];

  if (!isSelected) {
    return null;
  }

  var label = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Automatically fit text to container', 'amp');

  if (ampFitText) {
    maxFont = parseInt(maxFont);
    height = parseInt(height);
    minFont = parseInt(minFont);
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Settings', 'amp'),
    className: ampFitText ? 'is-amp-fit-text' : ''
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["ToggleControl"], {
    label: label,
    checked: ampFitText,
    onChange: function onChange() {
      return setAttributes({
        ampFitText: !ampFitText
      });
    }
  })), ampFitText && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Height', 'amp'),
    value: height,
    min: 1,
    onChange: function onChange(nextHeight) {
      setAttributes({
        height: nextHeight
      });
    }
  }), maxFont > height && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["Notice"], {
    status: "error",
    isDismissible: false
  }, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('The height must be greater than the max font size.', 'amp')), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Minimum font size', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["FontSizePicker"], {
    fallbackFontSize: 14,
    value: minFont,
    fontSizes: FONT_SIZES,
    onChange: function onChange(nextMinFont) {
      if (!nextMinFont) {
        nextMinFont = _common_constants__WEBPACK_IMPORTED_MODULE_8__["MIN_FONT_SIZE"]; // @todo Supplying fallbackFontSize should be done automatically by the component?
      }

      if (parseInt(nextMinFont) <= maxFont) {
        setAttributes({
          minFont: nextMinFont
        });
      }
    }
  })), minFont > maxFont && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["Notice"], {
    status: "error",
    isDismissible: false
  }, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('The min font size must less than the max font size.', 'amp')), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Maximum font size', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["FontSizePicker"], {
    fallbackFontSize: 48,
    value: maxFont,
    fontSizes: FONT_SIZES,
    onChange: function onChange(nextMaxFont) {
      if (!nextMaxFont) {
        nextMaxFont = _common_constants__WEBPACK_IMPORTED_MODULE_8__["MAX_FONT_SIZE"]; // @todo Supplying fallbackFontSize should be done automatically by the component?
      }

      setAttributes({
        maxFont: nextMaxFont,
        height: Math.max(nextMaxFont, height)
      });
    }
  }))));
};

setUpTextBlocksInspectorControls.propTypes = {
  isSelected: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampFitText: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
    minFont: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    maxFont: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired
};
/**
 * Get AMP Lightbox toggle control.
 *
 * @param {Object} props Props.
 *
 * @return {ReactElement} Element.
 */

var AmpLightboxToggle = function AmpLightboxToggle(props) {
  var _props$attributes = props.attributes,
      ampLightbox = _props$attributes.ampLightbox,
      linkTo = _props$attributes.linkTo,
      ampLayout = _props$attributes.ampLayout,
      setAttributes = props.setAttributes;
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["ToggleControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Add lightbox effect', 'amp'),
    checked: ampLightbox,
    onChange: function onChange(nextValue) {
      setAttributes({
        ampLightbox: !ampLightbox
      });

      if (nextValue) {
        // Lightbox doesn't work with fixed height, so change.
        if ('fixed-height' === ampLayout) {
          setAttributes({
            ampLayout: 'fixed'
          });
        } // In case of lightbox set linking images to 'none'.


        if (linkTo && 'none' !== linkTo) {
          setAttributes({
            linkTo: 'none'
          });
        }
      }
    }
  });
};

AmpLightboxToggle.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampLightbox: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    linkTo: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired
};
/**
 * Get AMP Carousel toggle control.
 *
 * @param {Object}   props                        Props.
 * @param {Object}   props.attributes             Block attributes.
 * @param {Object}   props.attributes.ampCarousel AMP Carousel toggle value.
 * @param {Function} props.setAttributes          Callback to update attributes.
 *
 * @return {Object} Element.
 */

var AmpCarouselToggle = function AmpCarouselToggle(props) {
  var ampCarousel = props.attributes.ampCarousel,
      setAttributes = props.setAttributes;
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["ToggleControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Display as carousel', 'amp'),
    checked: ampCarousel,
    onChange: function onChange() {
      return setAttributes({
        ampCarousel: !ampCarousel
      });
    }
  });
};

AmpCarouselToggle.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampCarousel: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired
};
/**
 * Set up inspector controls for Image block.
 *
 * @param {Object}  props            Props.
 * @param {boolean} props.isSelected Whether the current block has been selected or not.
 *
 * @return {Object} Inspector Controls.
 */

var setUpImageInspectorControls = function setUpImageInspectorControls(props) {
  var isSelected = props.isSelected;

  if (!isSelected) {
    return null;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpLayoutControl, props), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpNoloadingToggle, props), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpLightboxToggle, props)));
};

setUpImageInspectorControls.propTypes = {
  isSelected: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
};
/**
 * Set up inspector controls for Gallery block.
 * Adds ampCarousel attribute for displaying the output as amp-carousel.
 *
 * @param {Object}  props            Props.
 * @param {boolean} props.isSelected Whether the current block has been selected or not.
 *
 * @return {Object} Inspector controls.
 */

var setUpGalleryInspectorControls = function setUpGalleryInspectorControls(props) {
  var isSelected = props.isSelected;

  if (!isSelected) {
    return null;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpCarouselToggle, props), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpLightboxToggle, props)));
};

setUpGalleryInspectorControls.propTypes = {
  isSelected: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
};
/**
 * Determines whether AMP is enabled for the current post or not.
 *
 * For regular posts, this is based on the AMP toggle control and also
 * the default status based on the template mode.
 *
 * @return {boolean} Whether AMP is enabled.
 */

var isAMPEnabled = function isAMPEnabled() {
  var _select = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_6__["select"])('core/editor'),
      getEditedPostAttribute = _select.getEditedPostAttribute;

  return getEditedPostAttribute('amp_enabled') || false;
};

/***/ }),

/***/ "./assets/src/block-editor/index.js":
/*!******************************************!*\
  !*** ./assets/src/block-editor/index.js ***!
  \******************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/hooks */ "@wordpress/hooks");
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_plugins__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/plugins */ "@wordpress/plugins");
/* harmony import */ var _wordpress_plugins__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_plugins__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_blocks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/blocks */ "@wordpress/blocks");
/* harmony import */ var _wordpress_blocks__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_blocks__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _common_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../common/components */ "./assets/src/common/components/index.js");
/* harmony import */ var _common_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/helpers */ "./assets/src/common/helpers/index.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components */ "./assets/src/block-editor/components/index.js");
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./helpers */ "./assets/src/block-editor/helpers/index.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./store */ "./assets/src/block-editor/store/index.js");
/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */







var _select = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_3__["select"])('amp/block-editor'),
    isStandardMode = _select.isStandardMode;

var plugins = __webpack_require__("./assets/src/block-editor/plugins sync recursive .*\\.js$");

plugins.keys().forEach(function (modulePath) {
  var _plugins = plugins(modulePath),
      name = _plugins.name,
      render = _plugins.render,
      icon = _plugins.icon;

  Object(_wordpress_plugins__WEBPACK_IMPORTED_MODULE_1__["registerPlugin"])(name, {
    icon: icon,
    render: render
  });
});
Object(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__["addFilter"])('blocks.registerBlockType', 'ampEditorBlocks/addAttributes', _helpers__WEBPACK_IMPORTED_MODULE_7__["addAMPAttributes"]);
Object(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__["addFilter"])('blocks.getSaveElement', 'ampEditorBlocks/filterSave', _helpers__WEBPACK_IMPORTED_MODULE_7__["filterBlocksSave"]);
Object(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__["addFilter"])('editor.BlockEdit', 'ampEditorBlocks/filterEdit', _helpers__WEBPACK_IMPORTED_MODULE_7__["filterBlocksEdit"], 20);
Object(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__["addFilter"])('editor.PostFeaturedImage', 'ampEditorBlocks/withFeaturedImageNotice', _common_components__WEBPACK_IMPORTED_MODULE_4__["withFeaturedImageNotice"]);
Object(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__["addFilter"])('editor.MediaUpload', 'ampEditorBlocks/withMediaLibraryNotice', function (InitialMediaUpload) {
  return Object(_components__WEBPACK_IMPORTED_MODULE_6__["withMediaLibraryNotice"])(InitialMediaUpload, Object(_common_helpers__WEBPACK_IMPORTED_MODULE_5__["getMinimumFeaturedImageDimensions"])());
});
/*
 * If there's no theme support, unregister blocks that are only meant for AMP.
 */

var AMP_DEPENDENT_BLOCKS = ['amp/amp-brid-player', 'amp/amp-ima-video', 'amp/amp-jwplayer', 'amp/amp-mathml', 'amp/amp-o2-player', 'amp/amp-ooyala-player', 'amp/amp-reach-player', 'amp/amp-springboard-player', 'amp/amp-timeago'];

var blocks = __webpack_require__("./assets/src/block-editor/blocks sync recursive (?<!test\\/)index\\.js$");

blocks.keys().forEach(function (modulePath) {
  var _blocks = blocks(modulePath),
      name = _blocks.name,
      settings = _blocks.settings;

  var shouldRegister = isStandardMode() && AMP_DEPENDENT_BLOCKS.includes(name);

  if (shouldRegister) {
    Object(_wordpress_blocks__WEBPACK_IMPORTED_MODULE_2__["registerBlockType"])(name, settings);
  }
});

/***/ }),

/***/ "./assets/src/block-editor/plugins sync recursive .*\\.js$":
/*!******************************************************!*\
  !*** ./assets/src/block-editor/plugins sync .*\.js$ ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./amp-toggle.js": "./assets/src/block-editor/plugins/amp-toggle.js",
	"./pre-publish-panel.js": "./assets/src/block-editor/plugins/pre-publish-panel.js",
	"./wrapped-amp-preview-button.js": "./assets/src/block-editor/plugins/wrapped-amp-preview-button.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./assets/src/block-editor/plugins sync recursive .*\\.js$";

/***/ }),

/***/ "./assets/src/block-editor/plugins/amp-toggle.js":
/*!*******************************************************!*\
  !*** ./assets/src/block-editor/plugins/amp-toggle.js ***!
  \*******************************************************/
/*! exports provided: name, icon, render */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "icon", function() { return icon; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var amp_block_editor_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! amp-block-editor-data */ "amp-block-editor-data");
/* harmony import */ var amp_block_editor_data__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(amp_block_editor_data__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _wordpress_edit_post__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @wordpress/edit-post */ "@wordpress/edit-post");
/* harmony import */ var _wordpress_edit_post__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_wordpress_edit_post__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @wordpress/compose */ "@wordpress/compose");
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_wordpress_compose__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../helpers */ "./assets/src/block-editor/helpers/index.js");


/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */







/**
 * Internal dependencies
 */


/**
 * Adds an 'Enable AMP' toggle to the block editor 'Status & Visibility' section.
 *
 * If there are error(s) that block AMP from being enabled or disabled,
 * this only displays a Notice with the error(s), not a toggle.
 * Error(s) are imported as errorMessages via wp_localize_script().
 *
 * @param {Object} props Component props.
 * @param {boolean} props.isEnabled Whether toggle is enabled.
 * @param {Function} props.onChange Callback function for when the toggle is changed.
 * @return {Object} AMPToggle component.
 */

function AMPToggle(_ref) {
  var isEnabled = _ref.isEnabled,
      _onChange = _ref.onChange;
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_edit_post__WEBPACK_IMPORTED_MODULE_6__["PluginPostStatusInfo"], null, !amp_block_editor_data__WEBPACK_IMPORTED_MODULE_1__["errorMessages"].length && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("label", {
    htmlFor: "amp-enabled"
  }, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Enable AMP', 'amp')), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["FormToggle"], {
    checked: isEnabled,
    onChange: function onChange() {
      return _onChange(!isEnabled);
    },
    id: "amp-enabled"
  })), Boolean(amp_block_editor_data__WEBPACK_IMPORTED_MODULE_1__["errorMessages"].length) && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["Notice"], {
    status: "info",
    isDismissible: false,
    className: "amp-unavailable-notice"
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("details", null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("summary", null, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Unavailable', 'amp')), amp_block_editor_data__WEBPACK_IMPORTED_MODULE_1__["errorMessages"].map(function (message, index) {
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["RawHTML"], {
      key: index
    }, message);
  }))));
}

AMPToggle.propTypes = {
  isEnabled: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool.isRequired,
  onChange: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.func.isRequired
};
var name = 'amp';
var icon = 'hidden';
var render = Object(_wordpress_compose__WEBPACK_IMPORTED_MODULE_7__["compose"])(Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_5__["withSelect"])(function () {
  return {
    isEnabled: Object(_helpers__WEBPACK_IMPORTED_MODULE_8__["isAMPEnabled"])()
  };
}), Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_5__["withDispatch"])(function (dispatch) {
  return {
    onChange: function onChange(isEnabled) {
      dispatch('core/editor').editPost({
        amp_enabled: isEnabled
      });
    }
  };
}), _wordpress_compose__WEBPACK_IMPORTED_MODULE_7__["withInstanceId"])(AMPToggle);

/***/ }),

/***/ "./assets/src/block-editor/plugins/pre-publish-panel.js":
/*!**************************************************************!*\
  !*** ./assets/src/block-editor/plugins/pre-publish-panel.js ***!
  \**************************************************************/
/*! exports provided: name, render */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _common_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../common/components */ "./assets/src/common/components/index.js");
/* harmony import */ var _common_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../common/helpers */ "./assets/src/common/helpers/index.js");


/**
 * Internal dependencies
 */


var name = 'amp-post-featured-image-pre-publish-panel'; // On clicking 'Publish,' display a notice if no featured image exists or its width is too small.

var render = function render() {
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_common_components__WEBPACK_IMPORTED_MODULE_1__["PrePublishPanel"], {
    dimensions: Object(_common_helpers__WEBPACK_IMPORTED_MODULE_2__["getMinimumFeaturedImageDimensions"])(),
    required: false
  });
};

/***/ }),

/***/ "./assets/src/block-editor/plugins/wrapped-amp-preview-button.js":
/*!***********************************************************************!*\
  !*** ./assets/src/block-editor/plugins/wrapped-amp-preview-button.js ***!
  \***********************************************************************/
/*! exports provided: name, render */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "name", function() { return name; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/inherits */ "./node_modules/@babel/runtime/helpers/inherits.js");
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @wordpress/compose */ "@wordpress/compose");
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_wordpress_compose__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../constants */ "./assets/src/block-editor/constants.js");
/* harmony import */ var _components_amp_preview_button__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../components/amp-preview-button */ "./assets/src/block-editor/components/amp-preview-button.js");







function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default()(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default()(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default()(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



/**
 * A wrapper for the AMP preview button that renders it immediately after the 'Post' preview button, when present.
 */

var WrappedAmpPreviewButton = /*#__PURE__*/function (_Component) {
  _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default()(WrappedAmpPreviewButton, _Component);

  var _super = _createSuper(WrappedAmpPreviewButton);

  /**
   * Constructs the class.
   *
   * @param {*} args Constructor arguments.
   */
  function WrappedAmpPreviewButton() {
    var _this;

    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, WrappedAmpPreviewButton);

    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    _this = _super.call.apply(_super, [this].concat(args));
    _this.root = document.createElement('div');
    _this.root.className = 'amp-wrapper-post-preview';
    _this.postPreviewButton = document.querySelector(".".concat(_constants__WEBPACK_IMPORTED_MODULE_9__["POST_PREVIEW_CLASS"]));
    return _this;
  }
  /**
   * Invoked immediately after a component is mounted (inserted into the tree).
   */


  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(WrappedAmpPreviewButton, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      if (!this.postPreviewButton) {
        return;
      } // Insert the AMP preview button immediately after the post preview button.


      this.postPreviewButton.parentNode.insertBefore(this.root, this.postPreviewButton.nextSibling);
    }
    /**
     * Invoked immediately before a component is unmounted and destroyed.
     */

  }, {
    key: "componentWillUnmount",
    value: function componentWillUnmount() {
      if (!this.postPreviewButton) {
        return;
      }

      this.postPreviewButton.parentNode.removeChild(this.root);
    }
    /**
     * Renders the component.
     */

  }, {
    key: "render",
    value: function render() {
      if (!this.postPreviewButton) {
        return null;
      }

      return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_5__["createPortal"])(Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_5__["createElement"])(_components_amp_preview_button__WEBPACK_IMPORTED_MODULE_10__["default"], null), this.root);
    }
  }]);

  return WrappedAmpPreviewButton;
}(_wordpress_element__WEBPACK_IMPORTED_MODULE_5__["Component"]);

var name = 'amp-preview-button-wrapper';
var render = Object(_wordpress_compose__WEBPACK_IMPORTED_MODULE_8__["pure"])(Object(_wordpress_compose__WEBPACK_IMPORTED_MODULE_8__["compose"])([Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_7__["withSelect"])(function (select) {
  var _select = select('core'),
      getPostType = _select.getPostType;

  var _select2 = select('core/editor'),
      getEditedPostAttribute = _select2.getEditedPostAttribute;

  var postType = getPostType(getEditedPostAttribute('type'));
  return {
    isViewable: Object(lodash__WEBPACK_IMPORTED_MODULE_6__["get"])(postType, ['viewable'], false)
  };
}), // This HOC creator renders the component only when the condition is true. At that point the 'Post' preview
// button should have already been rendered (since it also relies on the same condition for rendering).
Object(_wordpress_compose__WEBPACK_IMPORTED_MODULE_8__["ifCondition"])(function (_ref) {
  var isViewable = _ref.isViewable;
  return isViewable;
})])(WrappedAmpPreviewButton));

/***/ }),

/***/ "./assets/src/block-editor/store/index.js":
/*!************************************************!*\
  !*** ./assets/src/block-editor/store/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _selectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./selectors */ "./assets/src/block-editor/store/selectors.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */


/**
 * Module Constants
 */

var MODULE_KEY = 'amp/block-editor';
/* harmony default export */ __webpack_exports__["default"] = (Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__["registerStore"])(MODULE_KEY, {
  reducer: function reducer(state) {
    return state;
  },
  selectors: _selectors__WEBPACK_IMPORTED_MODULE_2__,
  initialState: _objectSpread({}, window.ampBlockEditor)
}));

/***/ }),

/***/ "./assets/src/block-editor/store/selectors.js":
/*!****************************************************!*\
  !*** ./assets/src/block-editor/store/selectors.js ***!
  \****************************************************/
/*! exports provided: hasThemeSupport, isStandardMode, getErrorMessages, getAmpSlug */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hasThemeSupport", function() { return hasThemeSupport; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isStandardMode", function() { return isStandardMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getErrorMessages", function() { return getErrorMessages; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAmpSlug", function() { return getAmpSlug; });
/**
 * Returns whether the current theme has AMP support.
 *
 * @param {Object} state Editor state.
 *
 * @return {boolean} Whether the current theme has AMP support.
 */
function hasThemeSupport(state) {
  return Boolean(state.hasThemeSupport);
}
/**
 * Returns whether the current site is in Standard mode (AMP-first) as opposed to Transitional (paired).
 *
 * @param {Object} state Editor state.
 *
 * @return {boolean} Whether the current site is AMP-first.
 */

function isStandardMode(state) {
  return Boolean(state.isStandardMode);
}
/**
 * Returns the AMP validation error messages.
 *
 * @param {Object} state The editor state.
 *
 * @return {string[]} The validation error messages.
 */

function getErrorMessages(state) {
  return state.errorMessages;
}
/**
 * Returns the AMP slug used in the query var, like 'amp'.
 *
 * @param {Object} state The editor state.
 *
 * @return {string} The slug for AMP, like 'amp'.
 */

function getAmpSlug(state) {
  return state.ampSlug;
}

/***/ }),

/***/ "./assets/src/common/components/higher-order/with-featured-image-notice.js":
/*!*********************************************************************************!*\
  !*** ./assets/src/common/components/higher-order/with-featured-image-notice.js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/compose */ "@wordpress/compose");
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_compose__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../helpers */ "./assets/src/common/helpers/index.js");


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */


/**
 * Higher-order component that is used for filtering the PostFeaturedImage component.
 *
 * Used to display notices in case the image does not meet minimum requirements.
 *
 * @return {Function} Higher-order component.
 */

/* harmony default export */ __webpack_exports__["default"] = (Object(_wordpress_compose__WEBPACK_IMPORTED_MODULE_2__["createHigherOrderComponent"])(function (PostFeaturedImage) {
  var withFeaturedImageNotice = function withFeaturedImageNotice(props) {
    var media = props.media;
    var errors = Object(_helpers__WEBPACK_IMPORTED_MODULE_4__["validateFeaturedImage"])(media, Object(_helpers__WEBPACK_IMPORTED_MODULE_4__["getMinimumFeaturedImageDimensions"])(), false);

    if (!errors) {
      return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(PostFeaturedImage, props);
    }

    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_3__["Notice"], {
      status: "notice",
      isDismissible: false
    }, errors.map(function (errorMessage, index) {
      return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
        key: "error-".concat(index)
      }, errorMessage);
    })), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(PostFeaturedImage, props));
  };

  withFeaturedImageNotice.propTypes = {
    media: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object
  };
  return withFeaturedImageNotice;
}, 'withFeaturedImageNotice'));

/***/ }),

/***/ "./assets/src/common/components/index.js":
/*!***********************************************!*\
  !*** ./assets/src/common/components/index.js ***!
  \***********************************************/
/*! exports provided: PrePublishPanel, withFeaturedImageNotice, withEnforcedFileType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _pre_publish_panel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pre-publish-panel */ "./assets/src/common/components/pre-publish-panel.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PrePublishPanel", function() { return _pre_publish_panel__WEBPACK_IMPORTED_MODULE_0__["default"]; });

/* harmony import */ var _higher_order_with_featured_image_notice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./higher-order/with-featured-image-notice */ "./assets/src/common/components/higher-order/with-featured-image-notice.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "withFeaturedImageNotice", function() { return _higher_order_with_featured_image_notice__WEBPACK_IMPORTED_MODULE_1__["default"]; });

/* harmony import */ var _with_enforced_file_type__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./with-enforced-file-type */ "./assets/src/common/components/with-enforced-file-type.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "withEnforcedFileType", function() { return _with_enforced_file_type__WEBPACK_IMPORTED_MODULE_2__["default"]; });





/***/ }),

/***/ "./assets/src/common/components/pre-publish-panel.js":
/*!***********************************************************!*\
  !*** ./assets/src/common/components/pre-publish-panel.js ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_edit_post__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/edit-post */ "@wordpress/edit-post");
/* harmony import */ var _wordpress_edit_post__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_edit_post__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../helpers */ "./assets/src/common/helpers/index.js");


/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */





/**
 * Internal dependencies
 */


/**
 * Conditionally adds a notice to the pre-publish panel for the featured image.
 *
 * @param {Object} props Component props.
 * @param {Object} props.featuredMedia Media object.
 * @param {Array} props.dimensions Required image dimensions.
 * @param {boolean} props.required Whether selecting a featured image is required.
 *
 * @return {Function} Either a plain pre-publish panel, or the panel with a featured image notice.
 */

var PrePublishPanel = function PrePublishPanel(_ref) {
  var featuredMedia = _ref.featuredMedia,
      dimensions = _ref.dimensions,
      required = _ref.required;
  var errors = Object(_helpers__WEBPACK_IMPORTED_MODULE_6__["validateFeaturedImage"])(featuredMedia, dimensions, required);

  if (!errors) {
    return null;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_edit_post__WEBPACK_IMPORTED_MODULE_3__["PluginPrePublishPanel"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_5__["__"])('Featured Image', 'amp'),
    initialOpen: "true"
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_2__["Notice"], {
    status: required ? 'warning' : 'notice',
    isDismissible: false
  }, errors.map(function (errorMessage, index) {
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("p", {
      key: "error-".concat(index)
    }, errorMessage);
  })));
};

PrePublishPanel.propTypes = {
  featuredMedia: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.object,
  dimensions: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    width: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number.isRequired,
    height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number.isRequired
  }),
  required: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_4__["withSelect"])(function (select) {
  var currentPost = select('core/editor').getCurrentPost();
  var editedFeaturedMedia = select('core/editor').getEditedPostAttribute('featured_media');
  var featuredMedia = currentPost.featured_media || editedFeaturedMedia;
  return {
    featuredMedia: featuredMedia ? select('core').getMedia(featuredMedia) : null
  };
})(PrePublishPanel));

/***/ }),

/***/ "./assets/src/common/components/select-media-frame.js":
/*!************************************************************!*\
  !*** ./assets/src/common/components/select-media-frame.js ***!
  \************************************************************/
/*! exports provided: SelectionFileTypeError, SelectionFileSizeError, FeaturedImageToolbarSelect, EnforcedFileToolbarSelect, getSelectMediaFrame */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectionFileTypeError", function() { return SelectionFileTypeError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectionFileSizeError", function() { return SelectionFileSizeError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FeaturedImageToolbarSelect", function() { return FeaturedImageToolbarSelect; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EnforcedFileToolbarSelect", function() { return EnforcedFileToolbarSelect; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSelectMediaFrame", function() { return getSelectMediaFrame; });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../helpers */ "./assets/src/common/helpers/index.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


var _window = window,
    wp = _window.wp;
var NOTICE_CLASSNAME = 'notice notice-warning notice-alt inline';
/**
 * FeaturedImageSelectionError
 *
 * @augments wp.media.View
 * @augments wp.Backbone.View
 * @augments Backbone.View
 */

var FeaturedImageSelectionError = wp.media.View.extend({
  className: NOTICE_CLASSNAME,
  template: function () {
    var message = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["sprintf"])(
    /* translators: 1: image width in pixels. 2: image height in pixels. 3: required minimum width in pixels. 4: required minimum height in pixels. */
    Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('The selected image is too small (%1$s by %2$s pixels). It should have a size of at least %3$s by %4$s pixels.', 'amp'), '{{width}}', '{{height}}', '{{minWidth}}', '{{minHeight}}');
    return Object(_helpers__WEBPACK_IMPORTED_MODULE_3__["getNoticeTemplate"])(message);
  }()
});
/**
 * SelectionFileTypeError
 *
 * Applies if the featured image has the wrong file type, like .mov or .txt.
 * Very similar to the FeaturedImageSelectionError class.
 *
 * @augments wp.media.View
 * @augments wp.Backbone.View
 * @augments Backbone.View
 */

var SelectionFileTypeError = wp.media.View.extend({
  className: 'notice notice-warning notice-alt inline',
  template: function () {
    var message = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["sprintf"])(
    /* translators: 1: the selected file type. */
    Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('The selected file mime type, %1$s, is not allowed.', 'amp'), '{{mimeType}}');
    return Object(_helpers__WEBPACK_IMPORTED_MODULE_3__["getNoticeTemplate"])(message);
  }()
});
/**
 * SelectionFileSizeError
 *
 * Applies when the video size is more than a certain amount of MB per second.
 * Very similar to the FeaturedImageSelectionError class.
 *
 * @augments wp.media.View
 * @augments wp.Backbone.View
 * @augments Backbone.View
 */

var SelectionFileSizeError = wp.media.View.extend({
  className: NOTICE_CLASSNAME,
  template: function () {
    var message = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["sprintf"])(
    /* translators: 1: the recommended max MB per second for videos. 2: the actual MB per second of the video. */
    Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('A video size of less than %1$s MB per second is recommended. The selected video is %2$s MB per second.', 'amp'), '{{maxVideoMegabytesPerSecond}}', '{{actualVideoMegabytesPerSecond}}');
    return Object(_helpers__WEBPACK_IMPORTED_MODULE_3__["getNoticeTemplate"])(message);
  }()
});
/**
 * FeaturedImageToolbarSelect
 *
 * Prevent selection of an image that does not meet the minimum requirements.
 * Also enforces the file type, ensuring that it was in the allowedTypes prop.
 *
 * @augments wp.media.view.Toolbar.Select
 * @augments wp.media.view.Toolbar
 * @augments wp.media.View
 * @augments wp.Backbone.View
 * @augments Backbone.View
 */

var FeaturedImageToolbarSelect = wp.media.view.Toolbar.Select.extend({
  /**
   * Refresh the view.
   */
  refresh: function refresh() {
    wp.media.view.Toolbar.Select.prototype.refresh.call(this);
    var state = this.controller.state();
    var selection = state.get('selection');
    var attachment = selection.models[0];
    var minWidth = state.collection.get('featured-image').get('suggestedWidth');
    var minHeight = state.collection.get('featured-image').get('suggestedHeight');

    if (!attachment || 'image' !== attachment.get('type') || !attachment.get('width') || attachment.get('width') >= minWidth && attachment.get('height') >= minHeight) {
      this.secondary.unset('select-error');
    } else {
      this.secondary.set('select-error', new FeaturedImageSelectionError({
        minWidth: minWidth,
        minHeight: minHeight,
        width: attachment.get('width'),
        height: attachment.get('height')
      }));
    }

    _helpers__WEBPACK_IMPORTED_MODULE_3__["enforceFileType"].call(this, attachment, SelectionFileTypeError);
  }
});
/**
 * EnforcedFileToolbarSelect
 *
 * Prevents selecting an attachment that has the wrong file type, like .mov or .txt.
 *
 * @augments wp.media.view.Toolbar.Select
 * @augments wp.media.view.Toolbar
 * @augments wp.media.View
 * @augments wp.Backbone.View
 * @augments Backbone.View
 */

var EnforcedFileToolbarSelect = wp.media.view.Toolbar.Select.extend({
  /**
   * Refresh the view.
   */
  refresh: function refresh() {
    wp.media.view.Toolbar.Select.prototype.refresh.call(this);
    var state = this.controller.state();
    var selection = state.get('selection');
    var attachment = selection.models[0];
    _helpers__WEBPACK_IMPORTED_MODULE_3__["enforceFileType"].call(this, attachment, SelectionFileTypeError);
  }
});
/**
 * Gets the select media frame, which displays in the bottom of the Media Library.
 *
 * @param {Object} ToolbarSelect The select toolbar that display at the bottom of the Media Library.
 * @return {Object} ToolbarSelect A wp.media Class that creates a Media Library toolbar.
 */

var getSelectMediaFrame = function getSelectMediaFrame(ToolbarSelect) {
  /**
   * Selects a featured image from the media library.
   *
   * @augments wp.media.view.MediaFrame.Select
   * @augments wp.media.view.MediaFrame
   * @augments wp.media.view.Frame
   * @augments wp.media.View
   * @augments wp.Backbone.View
   * @augments Backbone.View
   * @mixes wp.media.controller.StateMachine
   */
  return wp.media.view.MediaFrame.Select.extend({
    /**
     * Create select toolbar.
     *
     * The only reason for this method is to override the select toolbar view class.
     *
     * @param {Object} toolbar
     * @param {Object} [options={}]
     * @this wp.media.controller.Region
     */
    createSelectToolbar: function createSelectToolbar(toolbar, options) {
      options = options || this.options.button || {};
      options.controller = this;
      options = _objectSpread(_objectSpread({}, options), {}, {
        allowedTypes: Object(lodash__WEBPACK_IMPORTED_MODULE_1__["get"])(this, ['options', 'allowedTypes'], null)
      });
      toolbar.view = new ToolbarSelect(options);
    }
  });
};

/***/ }),

/***/ "./assets/src/common/components/with-enforced-file-type.js":
/*!*****************************************************************!*\
  !*** ./assets/src/common/components/with-enforced-file-type.js ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/inherits */ "./node_modules/@babel/runtime/helpers/inherits.js");
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _select_media_frame__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./select-media-frame */ "./assets/src/common/components/select-media-frame.js");







function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default()(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default()(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default()(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }

/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


var _window = window,
    wp = _window.wp;
/**
 * Gets a wrapped version of MediaUpload, to enforce that it has the correct file type.
 *
 * Only intended for the MediaUpload in the Core Video block.
 * Though this will also apply to any other MediaUpload with allowedTypes of [ 'video' ].
 * Partly copied from customize-controls.js.
 *
 * @param {Function} InitialMediaUpload The MediaUpload component, passed from the filter.
 * @return {Function} The wrapped component.
 */

/* harmony default export */ __webpack_exports__["default"] = (function (InitialMediaUpload) {
  var _temp;

  /**
   * Partly copied from customize-controls.js.
   *
   * @see wp.media.HeaderControl
   */
  return _temp = /*#__PURE__*/function (_InitialMediaUpload) {
    _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default()(EnforcedFileTypeMediaUpload, _InitialMediaUpload);

    var _super = _createSuper(EnforcedFileTypeMediaUpload);

    /**
     * Constructs the class.
     *
     * @param {*} args Constructor arguments.
     */
    function EnforcedFileTypeMediaUpload() {
      var _this;

      _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, EnforcedFileTypeMediaUpload);

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      _this = _super.call.apply(_super, [this].concat(args)); // This class should only be present when only 'video' types are allowed, like in the Core Video block.

      _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_5___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_1___default()(_this), "initFileTypeMedia", function () {
        var SelectMediaFrame = Object(_select_media_frame__WEBPACK_IMPORTED_MODULE_8__["getSelectMediaFrame"])(_select_media_frame__WEBPACK_IMPORTED_MODULE_8__["EnforcedFileToolbarSelect"]);
        var previousOnSelect = _this.onSelect;
        var isVideo = Object(lodash__WEBPACK_IMPORTED_MODULE_6__["isEqual"])(['video'], _this.props.allowedTypes);
        var queryType = isVideo ? 'video/mp4' : _this.props.allowedTypes; // For the Video block, only display .mp4 files.

        _this.frame = new SelectMediaFrame({
          allowedTypes: _this.props.allowedTypes,
          button: {
            text: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_7__["__"])('Select', 'amp'),
            close: false
          },
          states: [new wp.media.controller.Library({
            title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_7__["__"])('Select or Upload Media', 'amp'),
            library: wp.media.query({
              type: queryType
            }),
            multiple: false,
            date: false,
            priority: 20
          })]
        });
        wp.media.frame = _this.frame;

        _this.frame.on('close', function () {
          _this.initFileTypeMedia();
        }, _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_1___default()(_this));

        _this.frame.on('select', function () {
          if (previousOnSelect) {
            previousOnSelect();
          }

          _this.frame.close();
        }, _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_1___default()(_this));
      });

      if (Object(lodash__WEBPACK_IMPORTED_MODULE_6__["isEqual"])(['video/mp4'], _this.props.allowedTypes)) {
        _this.initFileTypeMedia();
      }

      return _this;
    }
    /**
     * Initialize.
     *
     * Mainly copied from customize-controls.js.
     * Overwrites the Media Library frame, this.frame.
     * And checks that the file type is correct.
     *
     * @see wp.media.CroppedImageControl.initFrame
     */


    return EnforcedFileTypeMediaUpload;
  }(InitialMediaUpload), _temp;
});

/***/ }),

/***/ "./assets/src/common/constants.js":
/*!****************************************!*\
  !*** ./assets/src/common/constants.js ***!
  \****************************************/
/*! exports provided: MIN_FONT_SIZE, MAX_FONT_SIZE, MINIMUM_FEATURED_IMAGE_WIDTH, FILE_TYPE_ERROR_VIEW, READER, STANDARD, TRANSITIONAL, DEFAULT_MOBILE_BREAKPOINT */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MIN_FONT_SIZE", function() { return MIN_FONT_SIZE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MAX_FONT_SIZE", function() { return MAX_FONT_SIZE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MINIMUM_FEATURED_IMAGE_WIDTH", function() { return MINIMUM_FEATURED_IMAGE_WIDTH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FILE_TYPE_ERROR_VIEW", function() { return FILE_TYPE_ERROR_VIEW; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "READER", function() { return READER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STANDARD", function() { return STANDARD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TRANSITIONAL", function() { return TRANSITIONAL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_MOBILE_BREAKPOINT", function() { return DEFAULT_MOBILE_BREAKPOINT; });
// See https://github.com/ampproject/amphtml/blob/e7a1b3ff97645ec0ec482192205134bd0735943c/extensions/amp-fit-text/0.1/amp-fit-text.js#L81-L85
var MIN_FONT_SIZE = 6;
var MAX_FONT_SIZE = 72;
var MINIMUM_FEATURED_IMAGE_WIDTH = 1200;
var FILE_TYPE_ERROR_VIEW = 'select-file-type-error';
var READER = 'reader';
var STANDARD = 'standard';
var TRANSITIONAL = 'transitional';
var DEFAULT_MOBILE_BREAKPOINT = 783;

/***/ }),

/***/ "./assets/src/common/helpers/index.js":
/*!********************************************!*\
  !*** ./assets/src/common/helpers/index.js ***!
  \********************************************/
/*! exports provided: hasMinimumDimensions, getMinimumFeaturedImageDimensions, validateFeaturedImage, getNoticeTemplate, isFileTypeAllowed, enforceFileType, setImageFromURL */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hasMinimumDimensions", function() { return hasMinimumDimensions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMinimumFeaturedImageDimensions", function() { return getMinimumFeaturedImageDimensions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "validateFeaturedImage", function() { return validateFeaturedImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getNoticeTemplate", function() { return getNoticeTemplate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isFileTypeAllowed", function() { return isFileTypeAllowed; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "enforceFileType", function() { return enforceFileType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setImageFromURL", function() { return setImageFromURL; });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants */ "./assets/src/common/constants.js");
/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


/**
 * Determines whether whether the image has the minimum required dimensions.
 *
 * The image should have a width of at least 1200 pixels to satisfy the requirements of Google Search for Schema.org metadata.
 *
 * @param {Object} media             A media object with width and height values.
 * @param {number} media.width       Media width in pixels.
 * @param {number} media.height      Media height in pixels.
 * @param {Object} dimensions        An object with minimum required width and height values.
 * @param {number} dimensions.width  Required media width in pixels.
 * @param {number} dimensions.height Required media height in pixels.
 *
 * @return {boolean} Whether the media has the minimum dimensions.
 */

var hasMinimumDimensions = function hasMinimumDimensions(media, dimensions) {
  if (!media || !media.width || !media.height) {
    return false;
  }

  var width = dimensions.width,
      height = dimensions.height;
  return media.width >= width && media.height >= height;
};
/**
 * Get minimum dimensions for a featured image.
 *
 * @see https://developers.google.com/search/docs/data-types/article#article_types
 *
 * "Images should be at least 1200 pixels wide.
 * For best results, provide multiple high-resolution images (minimum of 800,000 pixels when multiplying width and height)
 * with the following aspect ratios: 16x9, 4x3, and 1x1."
 *
 * Given this requirement, this function ensures the right aspect ratio.
 * The 16/9 aspect ratio is chosen because it has the smallest height for the given width.
 *
 * @return {Object} Minimum dimensions including width and height.
 */

var getMinimumFeaturedImageDimensions = function getMinimumFeaturedImageDimensions() {
  var width = _constants__WEBPACK_IMPORTED_MODULE_2__["MINIMUM_FEATURED_IMAGE_WIDTH"];
  var height = width * (9 / 16);
  return {
    width: width,
    height: height
  };
};
/**
 * Validates the an image based on requirements.
 *
 * @param {Object}  media                      A media object.
 * @param {string}  media.mime_type            The media item's mime type.
 * @param {Object}  media.media_details        A media details object with width and height values.
 * @param {number}  media.media_details.width  Media width in pixels.
 * @param {number}  media.media_details.height Media height in pixels.
 * @param {Object}  dimensions                 An object with minimum required width and height values.
 * @param {boolean} required                   Whether the image is required or not.
 *
 * @return {string[]|null} Validation errors, or null if there were no errors.
 */

var validateFeaturedImage = function validateFeaturedImage(media, dimensions, required) {
  if (!media) {
    if (required) {
      return [Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__["__"])('Selecting a featured image is required.', 'amp')];
    }

    return [Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__["__"])('Selecting a featured image is recommended for an optimal user experience.', 'amp')];
  }

  var errors = [];

  if (!['image/png', 'image/gif', 'image/jpeg'].includes(media.mime_type)) {
    errors.push(
    /* translators: 1: .jpg, 2: .png. 3: .gif */
    Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__["sprintf"])(Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__["__"])('The featured image must be in %1$s, %2$s, or %3$s format.', 'amp'), '.jpg', '.png', '.gif'));
  }

  if (!hasMinimumDimensions(media.media_details, dimensions)) {
    var width = dimensions.width,
        height = dimensions.height;
    errors.push(
    /* translators: 1: minimum width, 2: minimum height. */
    Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__["sprintf"])(Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_1__["__"])('The featured image should have a size of at least %1$s by %2$s pixels.', 'amp'), Math.ceil(width), Math.ceil(height)));
  }

  return 0 === errors.length ? null : errors;
};
/**
 * Gets the compiled template for a given notice message.
 *
 * @param {string} message The message to display in the template.
 * @return {Function} compiledTemplate A function accepting the data, which creates a compiled template.
 */

var getNoticeTemplate = function getNoticeTemplate(message) {
  var errorTemplate = Object(lodash__WEBPACK_IMPORTED_MODULE_0__["template"])("<p>".concat(message, "</p>"), {
    evaluate: /<#([\s\S]+?)#>/g,
    interpolate: /\{\{\{([\s\S]+?)\}\}\}/g,
    escape: /\{\{([^\}]+?)\}\}(?!\})/g
  });
  return function (data) {
    return errorTemplate(data);
  };
};
/**
 * Gets whether the file type is allowed.
 *
 * For videos, only supported mime types as defined by the editor settings should be allowed.
 * But the allowedTypes property only has 'video', and it can accidentally allow mime types that are not supported.
 * So this returns false for videos with mime types other than the ones in the editor settings.
 *
 * @param {Object} attachment   The file to evaluate.
 * @param {Array}  allowedTypes The allowed file types.
 * @return {boolean} Whether the file type is allowed.
 */

var isFileTypeAllowed = function isFileTypeAllowed(attachment, allowedTypes) {
  var fileType = attachment.get('type');
  var mimeType = attachment.get('mime');

  if (!allowedTypes.includes(fileType) && !allowedTypes.includes(mimeType)) {
    return false;
  }

  return 'video' !== fileType;
};
/**
 * If the attachment has the wrong file type, this displays a notice in the Media Library and disables the 'Select' button.
 *
 * This is not an arrow function so that it can be called with enforceFileType.call( this, foo, bar ).
 *
 * @param {Object} attachment The selected attachment.
 * @param {Object} SelectionError The error to display.
 */

var enforceFileType = function enforceFileType(attachment, SelectionError) {
  if (!attachment) {
    return;
  }

  var allowedTypes = Object(lodash__WEBPACK_IMPORTED_MODULE_0__["get"])(this, ['options', 'allowedTypes'], null);
  var selectButton = this.get('select'); // If the file type isn't allowed, display a notice and disable the 'Select' button.

  if (allowedTypes && attachment.get('type') && !isFileTypeAllowed(attachment, allowedTypes)) {
    this.secondary.set(_constants__WEBPACK_IMPORTED_MODULE_2__["FILE_TYPE_ERROR_VIEW"], new SelectionError({
      mimeType: attachment.get('mime')
    }));

    if (selectButton && selectButton.model) {
      selectButton.model.set('disabled', true); // Disable the button to select the file.
    }
  } else {
    this.secondary.unset(_constants__WEBPACK_IMPORTED_MODULE_2__["FILE_TYPE_ERROR_VIEW"]);

    if (selectButton && selectButton.model) {
      selectButton.model.set('disabled', false); // Enable the button to select the file.
    }
  }
};
/**
 * Sets the featured image, on selecting it in the Media Library.
 *
 * @param {Object} args Arguments.
 * @param {string} args.url Image URL.
 * @param {number} args.id Attachment ID.
 * @param {number} args.width Image width.
 * @param {number} args.height Image height.
 * @param {Function} args.onSelect A function in the MediaUpload component called on selecting the image.
 * @param {Function} args.dispatchImage A function to dispatch the change in image to the store.
 */

var setImageFromURL = function setImageFromURL(_ref) {
  var url = _ref.url,
      id = _ref.id,
      width = _ref.width,
      height = _ref.height,
      onSelect = _ref.onSelect,
      dispatchImage = _ref.dispatchImage;
  var data = {};
  data.url = url;
  data.thumbnail_url = url;
  data.timestamp = Object(lodash__WEBPACK_IMPORTED_MODULE_0__["now"])();

  if (id) {
    data.attachment_id = id;
  }

  if (width) {
    data.width = width;
  }

  if (height) {
    data.height = height;
  }

  onSelect(data); // @todo Does this do anything?

  dispatchImage(id);
};

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/assertThisInitialized.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/assertThisInitialized.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _assertThisInitialized(self) {
  if (self === void 0) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return self;
}

module.exports = _assertThisInitialized;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/classCallCheck.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/classCallCheck.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/createClass.js":
/*!************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/createClass.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/defineProperty.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/defineProperty.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/extends.js":
/*!********************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/extends.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/get.js":
/*!****************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/get.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var superPropBase = __webpack_require__(/*! ./superPropBase */ "./node_modules/@babel/runtime/helpers/superPropBase.js");

function _get(target, property, receiver) {
  if (typeof Reflect !== "undefined" && Reflect.get) {
    module.exports = _get = Reflect.get;
  } else {
    module.exports = _get = function _get(target, property, receiver) {
      var base = superPropBase(target, property);
      if (!base) return;
      var desc = Object.getOwnPropertyDescriptor(base, property);

      if (desc.get) {
        return desc.get.call(receiver);
      }

      return desc.value;
    };
  }

  return _get(target, property, receiver || target);
}

module.exports = _get;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/getPrototypeOf.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _getPrototypeOf(o) {
  module.exports = _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

module.exports = _getPrototypeOf;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/inherits.js":
/*!*********************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/inherits.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var setPrototypeOf = __webpack_require__(/*! ./setPrototypeOf */ "./node_modules/@babel/runtime/helpers/setPrototypeOf.js");

function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      writable: true,
      configurable: true
    }
  });
  if (superClass) setPrototypeOf(subClass, superClass);
}

module.exports = _inherits;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js":
/*!**************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var _typeof = __webpack_require__(/*! ../helpers/typeof */ "./node_modules/@babel/runtime/helpers/typeof.js");

var assertThisInitialized = __webpack_require__(/*! ./assertThisInitialized */ "./node_modules/@babel/runtime/helpers/assertThisInitialized.js");

function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return assertThisInitialized(self);
}

module.exports = _possibleConstructorReturn;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/setPrototypeOf.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/setPrototypeOf.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _setPrototypeOf(o, p) {
  module.exports = _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

module.exports = _setPrototypeOf;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/superPropBase.js":
/*!**************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/superPropBase.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var getPrototypeOf = __webpack_require__(/*! ./getPrototypeOf */ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js");

function _superPropBase(object, property) {
  while (!Object.prototype.hasOwnProperty.call(object, property)) {
    object = getPrototypeOf(object);
    if (object === null) break;
  }

  return object;
}

module.exports = _superPropBase;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/typeof.js":
/*!*******************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/typeof.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };
  }

  return _typeof(obj);
}

module.exports = _typeof;

/***/ }),

/***/ "./node_modules/object-assign/index.js":
/*!*********************************************!*\
  !*** ./node_modules/object-assign/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),

/***/ "./node_modules/prop-types/checkPropTypes.js":
/*!***************************************************!*\
  !*** ./node_modules/prop-types/checkPropTypes.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var printWarning = function() {};

if (true) {
  var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "./node_modules/prop-types/lib/ReactPropTypesSecret.js");
  var loggedTypeFailures = {};
  var has = Function.call.bind(Object.prototype.hasOwnProperty);

  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  };
}

/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */
function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
  if (true) {
    for (var typeSpecName in typeSpecs) {
      if (has(typeSpecs, typeSpecName)) {
        var error;
        // Prop type validation may throw. In case they do, we don't want to
        // fail the render phase where it didn't fail before. So we log it.
        // After these have been cleaned up, we'll let them throw.
        try {
          // This is intentionally an invariant that gets caught. It's the same
          // behavior as without this statement except with a better message.
          if (typeof typeSpecs[typeSpecName] !== 'function') {
            var err = Error(
              (componentName || 'React class') + ': ' + location + ' type `' + typeSpecName + '` is invalid; ' +
              'it must be a function, usually from the `prop-types` package, but received `' + typeof typeSpecs[typeSpecName] + '`.'
            );
            err.name = 'Invariant Violation';
            throw err;
          }
          error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
        } catch (ex) {
          error = ex;
        }
        if (error && !(error instanceof Error)) {
          printWarning(
            (componentName || 'React class') + ': type specification of ' +
            location + ' `' + typeSpecName + '` is invalid; the type checker ' +
            'function must return `null` or an `Error` but returned a ' + typeof error + '. ' +
            'You may have forgotten to pass an argument to the type checker ' +
            'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' +
            'shape all require an argument).'
          );
        }
        if (error instanceof Error && !(error.message in loggedTypeFailures)) {
          // Only monitor this failure once because there tends to be a lot of the
          // same error.
          loggedTypeFailures[error.message] = true;

          var stack = getStack ? getStack() : '';

          printWarning(
            'Failed ' + location + ' type: ' + error.message + (stack != null ? stack : '')
          );
        }
      }
    }
  }
}

/**
 * Resets warning cache when testing.
 *
 * @private
 */
checkPropTypes.resetWarningCache = function() {
  if (true) {
    loggedTypeFailures = {};
  }
}

module.exports = checkPropTypes;


/***/ }),

/***/ "./node_modules/prop-types/factoryWithTypeCheckers.js":
/*!************************************************************!*\
  !*** ./node_modules/prop-types/factoryWithTypeCheckers.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactIs = __webpack_require__(/*! react-is */ "./node_modules/react-is/index.js");
var assign = __webpack_require__(/*! object-assign */ "./node_modules/object-assign/index.js");

var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "./node_modules/prop-types/lib/ReactPropTypesSecret.js");
var checkPropTypes = __webpack_require__(/*! ./checkPropTypes */ "./node_modules/prop-types/checkPropTypes.js");

var has = Function.call.bind(Object.prototype.hasOwnProperty);
var printWarning = function() {};

if (true) {
  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  };
}

function emptyFunctionThatReturnsNull() {
  return null;
}

module.exports = function(isValidElement, throwOnDirectAccess) {
  /* global Symbol */
  var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
  var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.

  /**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */
  function getIteratorFn(maybeIterable) {
    var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
    if (typeof iteratorFn === 'function') {
      return iteratorFn;
    }
  }

  /**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */

  var ANONYMOUS = '<<anonymous>>';

  // Important!
  // Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
  var ReactPropTypes = {
    array: createPrimitiveTypeChecker('array'),
    bool: createPrimitiveTypeChecker('boolean'),
    func: createPrimitiveTypeChecker('function'),
    number: createPrimitiveTypeChecker('number'),
    object: createPrimitiveTypeChecker('object'),
    string: createPrimitiveTypeChecker('string'),
    symbol: createPrimitiveTypeChecker('symbol'),

    any: createAnyTypeChecker(),
    arrayOf: createArrayOfTypeChecker,
    element: createElementTypeChecker(),
    elementType: createElementTypeTypeChecker(),
    instanceOf: createInstanceTypeChecker,
    node: createNodeChecker(),
    objectOf: createObjectOfTypeChecker,
    oneOf: createEnumTypeChecker,
    oneOfType: createUnionTypeChecker,
    shape: createShapeTypeChecker,
    exact: createStrictShapeTypeChecker,
  };

  /**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */
  /*eslint-disable no-self-compare*/
  function is(x, y) {
    // SameValue algorithm
    if (x === y) {
      // Steps 1-5, 7-10
      // Steps 6.b-6.e: +0 != -0
      return x !== 0 || 1 / x === 1 / y;
    } else {
      // Step 6.a: NaN == NaN
      return x !== x && y !== y;
    }
  }
  /*eslint-enable no-self-compare*/

  /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */
  function PropTypeError(message) {
    this.message = message;
    this.stack = '';
  }
  // Make `instanceof Error` still work for returned errors.
  PropTypeError.prototype = Error.prototype;

  function createChainableTypeChecker(validate) {
    if (true) {
      var manualPropTypeCallCache = {};
      var manualPropTypeWarningCount = 0;
    }
    function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
      componentName = componentName || ANONYMOUS;
      propFullName = propFullName || propName;

      if (secret !== ReactPropTypesSecret) {
        if (throwOnDirectAccess) {
          // New behavior only for users of `prop-types` package
          var err = new Error(
            'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
            'Use `PropTypes.checkPropTypes()` to call them. ' +
            'Read more at http://fb.me/use-check-prop-types'
          );
          err.name = 'Invariant Violation';
          throw err;
        } else if ( true && typeof console !== 'undefined') {
          // Old behavior for people using React.PropTypes
          var cacheKey = componentName + ':' + propName;
          if (
            !manualPropTypeCallCache[cacheKey] &&
            // Avoid spamming the console because they are often not actionable except for lib authors
            manualPropTypeWarningCount < 3
          ) {
            printWarning(
              'You are manually calling a React.PropTypes validation ' +
              'function for the `' + propFullName + '` prop on `' + componentName  + '`. This is deprecated ' +
              'and will throw in the standalone `prop-types` package. ' +
              'You may be seeing this warning due to a third-party PropTypes ' +
              'library. See https://fb.me/react-warning-dont-call-proptypes ' + 'for details.'
            );
            manualPropTypeCallCache[cacheKey] = true;
            manualPropTypeWarningCount++;
          }
        }
      }
      if (props[propName] == null) {
        if (isRequired) {
          if (props[propName] === null) {
            return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required ' + ('in `' + componentName + '`, but its value is `null`.'));
          }
          return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required in ' + ('`' + componentName + '`, but its value is `undefined`.'));
        }
        return null;
      } else {
        return validate(props, propName, componentName, location, propFullName);
      }
    }

    var chainedCheckType = checkType.bind(null, false);
    chainedCheckType.isRequired = checkType.bind(null, true);

    return chainedCheckType;
  }

  function createPrimitiveTypeChecker(expectedType) {
    function validate(props, propName, componentName, location, propFullName, secret) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== expectedType) {
        // `propValue` being instance of, say, date/regexp, pass the 'object'
        // check, but we can offer a more precise error message here rather than
        // 'of type `object`'.
        var preciseType = getPreciseType(propValue);

        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + preciseType + '` supplied to `' + componentName + '`, expected ') + ('`' + expectedType + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createAnyTypeChecker() {
    return createChainableTypeChecker(emptyFunctionThatReturnsNull);
  }

  function createArrayOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside arrayOf.');
      }
      var propValue = props[propName];
      if (!Array.isArray(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an array.'));
      }
      for (var i = 0; i < propValue.length; i++) {
        var error = typeChecker(propValue, i, componentName, location, propFullName + '[' + i + ']', ReactPropTypesSecret);
        if (error instanceof Error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!isValidElement(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!ReactIs.isValidElementType(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement type.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createInstanceTypeChecker(expectedClass) {
    function validate(props, propName, componentName, location, propFullName) {
      if (!(props[propName] instanceof expectedClass)) {
        var expectedClassName = expectedClass.name || ANONYMOUS;
        var actualClassName = getClassName(props[propName]);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + actualClassName + '` supplied to `' + componentName + '`, expected ') + ('instance of `' + expectedClassName + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createEnumTypeChecker(expectedValues) {
    if (!Array.isArray(expectedValues)) {
      if (true) {
        if (arguments.length > 1) {
          printWarning(
            'Invalid arguments supplied to oneOf, expected an array, got ' + arguments.length + ' arguments. ' +
            'A common mistake is to write oneOf(x, y, z) instead of oneOf([x, y, z]).'
          );
        } else {
          printWarning('Invalid argument supplied to oneOf, expected an array.');
        }
      }
      return emptyFunctionThatReturnsNull;
    }

    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      for (var i = 0; i < expectedValues.length; i++) {
        if (is(propValue, expectedValues[i])) {
          return null;
        }
      }

      var valuesString = JSON.stringify(expectedValues, function replacer(key, value) {
        var type = getPreciseType(value);
        if (type === 'symbol') {
          return String(value);
        }
        return value;
      });
      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of value `' + String(propValue) + '` ' + ('supplied to `' + componentName + '`, expected one of ' + valuesString + '.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createObjectOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside objectOf.');
      }
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an object.'));
      }
      for (var key in propValue) {
        if (has(propValue, key)) {
          var error = typeChecker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
          if (error instanceof Error) {
            return error;
          }
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createUnionTypeChecker(arrayOfTypeCheckers) {
    if (!Array.isArray(arrayOfTypeCheckers)) {
       true ? printWarning('Invalid argument supplied to oneOfType, expected an instance of array.') : undefined;
      return emptyFunctionThatReturnsNull;
    }

    for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
      var checker = arrayOfTypeCheckers[i];
      if (typeof checker !== 'function') {
        printWarning(
          'Invalid argument supplied to oneOfType. Expected an array of check functions, but ' +
          'received ' + getPostfixForTypeWarning(checker) + ' at index ' + i + '.'
        );
        return emptyFunctionThatReturnsNull;
      }
    }

    function validate(props, propName, componentName, location, propFullName) {
      for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
        var checker = arrayOfTypeCheckers[i];
        if (checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret) == null) {
          return null;
        }
      }

      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createNodeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      if (!isNode(props[propName])) {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`, expected a ReactNode.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      for (var key in shapeTypes) {
        var checker = shapeTypes[key];
        if (!checker) {
          continue;
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createStrictShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      // We need to check all keys in case some are required but missing from
      // props.
      var allKeys = assign({}, props[propName], shapeTypes);
      for (var key in allKeys) {
        var checker = shapeTypes[key];
        if (!checker) {
          return new PropTypeError(
            'Invalid ' + location + ' `' + propFullName + '` key `' + key + '` supplied to `' + componentName + '`.' +
            '\nBad object: ' + JSON.stringify(props[propName], null, '  ') +
            '\nValid keys: ' +  JSON.stringify(Object.keys(shapeTypes), null, '  ')
          );
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }

    return createChainableTypeChecker(validate);
  }

  function isNode(propValue) {
    switch (typeof propValue) {
      case 'number':
      case 'string':
      case 'undefined':
        return true;
      case 'boolean':
        return !propValue;
      case 'object':
        if (Array.isArray(propValue)) {
          return propValue.every(isNode);
        }
        if (propValue === null || isValidElement(propValue)) {
          return true;
        }

        var iteratorFn = getIteratorFn(propValue);
        if (iteratorFn) {
          var iterator = iteratorFn.call(propValue);
          var step;
          if (iteratorFn !== propValue.entries) {
            while (!(step = iterator.next()).done) {
              if (!isNode(step.value)) {
                return false;
              }
            }
          } else {
            // Iterator will provide entry [k,v] tuples rather than values.
            while (!(step = iterator.next()).done) {
              var entry = step.value;
              if (entry) {
                if (!isNode(entry[1])) {
                  return false;
                }
              }
            }
          }
        } else {
          return false;
        }

        return true;
      default:
        return false;
    }
  }

  function isSymbol(propType, propValue) {
    // Native Symbol.
    if (propType === 'symbol') {
      return true;
    }

    // falsy value can't be a Symbol
    if (!propValue) {
      return false;
    }

    // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
    if (propValue['@@toStringTag'] === 'Symbol') {
      return true;
    }

    // Fallback for non-spec compliant Symbols which are polyfilled.
    if (typeof Symbol === 'function' && propValue instanceof Symbol) {
      return true;
    }

    return false;
  }

  // Equivalent of `typeof` but with special handling for array and regexp.
  function getPropType(propValue) {
    var propType = typeof propValue;
    if (Array.isArray(propValue)) {
      return 'array';
    }
    if (propValue instanceof RegExp) {
      // Old webkits (at least until Android 4.0) return 'function' rather than
      // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
      // passes PropTypes.object.
      return 'object';
    }
    if (isSymbol(propType, propValue)) {
      return 'symbol';
    }
    return propType;
  }

  // This handles more types than `getPropType`. Only used for error messages.
  // See `createPrimitiveTypeChecker`.
  function getPreciseType(propValue) {
    if (typeof propValue === 'undefined' || propValue === null) {
      return '' + propValue;
    }
    var propType = getPropType(propValue);
    if (propType === 'object') {
      if (propValue instanceof Date) {
        return 'date';
      } else if (propValue instanceof RegExp) {
        return 'regexp';
      }
    }
    return propType;
  }

  // Returns a string that is postfixed to a warning about an invalid type.
  // For example, "undefined" or "of type array"
  function getPostfixForTypeWarning(value) {
    var type = getPreciseType(value);
    switch (type) {
      case 'array':
      case 'object':
        return 'an ' + type;
      case 'boolean':
      case 'date':
      case 'regexp':
        return 'a ' + type;
      default:
        return type;
    }
  }

  // Returns class name of the object, if any.
  function getClassName(propValue) {
    if (!propValue.constructor || !propValue.constructor.name) {
      return ANONYMOUS;
    }
    return propValue.constructor.name;
  }

  ReactPropTypes.checkPropTypes = checkPropTypes;
  ReactPropTypes.resetWarningCache = checkPropTypes.resetWarningCache;
  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};


/***/ }),

/***/ "./node_modules/prop-types/index.js":
/*!******************************************!*\
  !*** ./node_modules/prop-types/index.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

if (true) {
  var ReactIs = __webpack_require__(/*! react-is */ "./node_modules/react-is/index.js");

  // By explicitly using `prop-types` you are opting into new development behavior.
  // http://fb.me/prop-types-in-prod
  var throwOnDirectAccess = true;
  module.exports = __webpack_require__(/*! ./factoryWithTypeCheckers */ "./node_modules/prop-types/factoryWithTypeCheckers.js")(ReactIs.isElement, throwOnDirectAccess);
} else {}


/***/ }),

/***/ "./node_modules/prop-types/lib/ReactPropTypesSecret.js":
/*!*************************************************************!*\
  !*** ./node_modules/prop-types/lib/ReactPropTypesSecret.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

module.exports = ReactPropTypesSecret;


/***/ }),

/***/ "./node_modules/react-is/cjs/react-is.development.js":
/*!***********************************************************!*\
  !*** ./node_modules/react-is/cjs/react-is.development.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/** @license React v16.13.1
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */





if (true) {
  (function() {
'use strict';

// The Symbol used to tag the ReactElement-like types. If there is no native Symbol
// nor polyfill, then a plain number is used for performance.
var hasSymbol = typeof Symbol === 'function' && Symbol.for;
var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for('react.element') : 0xeac7;
var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for('react.portal') : 0xeaca;
var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for('react.fragment') : 0xeacb;
var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for('react.strict_mode') : 0xeacc;
var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for('react.profiler') : 0xead2;
var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for('react.provider') : 0xeacd;
var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for('react.context') : 0xeace; // TODO: We don't use AsyncMode or ConcurrentMode anymore. They were temporary
// (unstable) APIs that have been removed. Can we remove the symbols?

var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for('react.async_mode') : 0xeacf;
var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for('react.concurrent_mode') : 0xeacf;
var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for('react.forward_ref') : 0xead0;
var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for('react.suspense') : 0xead1;
var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for('react.suspense_list') : 0xead8;
var REACT_MEMO_TYPE = hasSymbol ? Symbol.for('react.memo') : 0xead3;
var REACT_LAZY_TYPE = hasSymbol ? Symbol.for('react.lazy') : 0xead4;
var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for('react.block') : 0xead9;
var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for('react.fundamental') : 0xead5;
var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for('react.responder') : 0xead6;
var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for('react.scope') : 0xead7;

function isValidElementType(type) {
  return typeof type === 'string' || typeof type === 'function' || // Note: its typeof might be other than 'symbol' or 'number' if it's a polyfill.
  type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === 'object' && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
}

function typeOf(object) {
  if (typeof object === 'object' && object !== null) {
    var $$typeof = object.$$typeof;

    switch ($$typeof) {
      case REACT_ELEMENT_TYPE:
        var type = object.type;

        switch (type) {
          case REACT_ASYNC_MODE_TYPE:
          case REACT_CONCURRENT_MODE_TYPE:
          case REACT_FRAGMENT_TYPE:
          case REACT_PROFILER_TYPE:
          case REACT_STRICT_MODE_TYPE:
          case REACT_SUSPENSE_TYPE:
            return type;

          default:
            var $$typeofType = type && type.$$typeof;

            switch ($$typeofType) {
              case REACT_CONTEXT_TYPE:
              case REACT_FORWARD_REF_TYPE:
              case REACT_LAZY_TYPE:
              case REACT_MEMO_TYPE:
              case REACT_PROVIDER_TYPE:
                return $$typeofType;

              default:
                return $$typeof;
            }

        }

      case REACT_PORTAL_TYPE:
        return $$typeof;
    }
  }

  return undefined;
} // AsyncMode is deprecated along with isAsyncMode

var AsyncMode = REACT_ASYNC_MODE_TYPE;
var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
var ContextConsumer = REACT_CONTEXT_TYPE;
var ContextProvider = REACT_PROVIDER_TYPE;
var Element = REACT_ELEMENT_TYPE;
var ForwardRef = REACT_FORWARD_REF_TYPE;
var Fragment = REACT_FRAGMENT_TYPE;
var Lazy = REACT_LAZY_TYPE;
var Memo = REACT_MEMO_TYPE;
var Portal = REACT_PORTAL_TYPE;
var Profiler = REACT_PROFILER_TYPE;
var StrictMode = REACT_STRICT_MODE_TYPE;
var Suspense = REACT_SUSPENSE_TYPE;
var hasWarnedAboutDeprecatedIsAsyncMode = false; // AsyncMode should be deprecated

function isAsyncMode(object) {
  {
    if (!hasWarnedAboutDeprecatedIsAsyncMode) {
      hasWarnedAboutDeprecatedIsAsyncMode = true; // Using console['warn'] to evade Babel and ESLint

      console['warn']('The ReactIs.isAsyncMode() alias has been deprecated, ' + 'and will be removed in React 17+. Update your code to use ' + 'ReactIs.isConcurrentMode() instead. It has the exact same API.');
    }
  }

  return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
}
function isConcurrentMode(object) {
  return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
}
function isContextConsumer(object) {
  return typeOf(object) === REACT_CONTEXT_TYPE;
}
function isContextProvider(object) {
  return typeOf(object) === REACT_PROVIDER_TYPE;
}
function isElement(object) {
  return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
}
function isForwardRef(object) {
  return typeOf(object) === REACT_FORWARD_REF_TYPE;
}
function isFragment(object) {
  return typeOf(object) === REACT_FRAGMENT_TYPE;
}
function isLazy(object) {
  return typeOf(object) === REACT_LAZY_TYPE;
}
function isMemo(object) {
  return typeOf(object) === REACT_MEMO_TYPE;
}
function isPortal(object) {
  return typeOf(object) === REACT_PORTAL_TYPE;
}
function isProfiler(object) {
  return typeOf(object) === REACT_PROFILER_TYPE;
}
function isStrictMode(object) {
  return typeOf(object) === REACT_STRICT_MODE_TYPE;
}
function isSuspense(object) {
  return typeOf(object) === REACT_SUSPENSE_TYPE;
}

exports.AsyncMode = AsyncMode;
exports.ConcurrentMode = ConcurrentMode;
exports.ContextConsumer = ContextConsumer;
exports.ContextProvider = ContextProvider;
exports.Element = Element;
exports.ForwardRef = ForwardRef;
exports.Fragment = Fragment;
exports.Lazy = Lazy;
exports.Memo = Memo;
exports.Portal = Portal;
exports.Profiler = Profiler;
exports.StrictMode = StrictMode;
exports.Suspense = Suspense;
exports.isAsyncMode = isAsyncMode;
exports.isConcurrentMode = isConcurrentMode;
exports.isContextConsumer = isContextConsumer;
exports.isContextProvider = isContextProvider;
exports.isElement = isElement;
exports.isForwardRef = isForwardRef;
exports.isFragment = isFragment;
exports.isLazy = isLazy;
exports.isMemo = isMemo;
exports.isPortal = isPortal;
exports.isProfiler = isProfiler;
exports.isStrictMode = isStrictMode;
exports.isSuspense = isSuspense;
exports.isValidElementType = isValidElementType;
exports.typeOf = typeOf;
  })();
}


/***/ }),

/***/ "./node_modules/react-is/index.js":
/*!****************************************!*\
  !*** ./node_modules/react-is/index.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


if (false) {} else {
  module.exports = __webpack_require__(/*! ./cjs/react-is.development.js */ "./node_modules/react-is/cjs/react-is.development.js");
}


/***/ }),

/***/ "@wordpress/block-editor":
/*!**********************************************!*\
  !*** external {"this":["wp","blockEditor"]} ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["blockEditor"]; }());

/***/ }),

/***/ "@wordpress/blocks":
/*!*****************************************!*\
  !*** external {"this":["wp","blocks"]} ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["blocks"]; }());

/***/ }),

/***/ "@wordpress/components":
/*!*********************************************!*\
  !*** external {"this":["wp","components"]} ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["components"]; }());

/***/ }),

/***/ "@wordpress/compose":
/*!******************************************!*\
  !*** external {"this":["wp","compose"]} ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["compose"]; }());

/***/ }),

/***/ "@wordpress/data":
/*!***************************************!*\
  !*** external {"this":["wp","data"]} ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["data"]; }());

/***/ }),

/***/ "@wordpress/edit-post":
/*!*******************************************!*\
  !*** external {"this":["wp","editPost"]} ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["editPost"]; }());

/***/ }),

/***/ "@wordpress/element":
/*!******************************************!*\
  !*** external {"this":["wp","element"]} ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["element"]; }());

/***/ }),

/***/ "@wordpress/hooks":
/*!****************************************!*\
  !*** external {"this":["wp","hooks"]} ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["hooks"]; }());

/***/ }),

/***/ "@wordpress/i18n":
/*!***************************************!*\
  !*** external {"this":["wp","i18n"]} ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["i18n"]; }());

/***/ }),

/***/ "@wordpress/plugins":
/*!******************************************!*\
  !*** external {"this":["wp","plugins"]} ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["plugins"]; }());

/***/ }),

/***/ "@wordpress/url":
/*!**************************************!*\
  !*** external {"this":["wp","url"]} ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["url"]; }());

/***/ }),

/***/ "amp-block-editor-data":
/*!*********************************!*\
  !*** external "ampBlockEditor" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ampBlockEditor;

/***/ }),

/***/ "lodash":
/*!**********************************!*\
  !*** external {"this":"lodash"} ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["lodash"]; }());

/***/ }),

/***/ "moment":
/*!**********************************!*\
  !*** external {"this":"moment"} ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["moment"]; }());

/***/ }),

/***/ "react":
/*!*********************************!*\
  !*** external {"this":"React"} ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["React"]; }());

/***/ })

/******/ });
//# sourceMappingURL=amp-block-editor.js.map