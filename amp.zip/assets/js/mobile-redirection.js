/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./assets/src/mobile-redirection.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./assets/src/mobile-redirection.js":
/*!******************************************!*\
  !*** ./assets/src/mobile-redirection.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function (_ref) {
  var ampUrl = _ref.ampUrl,
      isCustomizePreview = _ref.isCustomizePreview,
      isAmpDevMode = _ref.isAmpDevMode,
      noampQueryVarName = _ref.noampQueryVarName,
      noampQueryVarValue = _ref.noampQueryVarValue,
      disabledStorageKey = _ref.disabledStorageKey,
      mobileUserAgents = _ref.mobileUserAgents,
      regexRegex = _ref.regexRegex;

  if (typeof sessionStorage === 'undefined') {
    return;
  } // Yes, this is a regular expression to match regular expressions. So meta.


  var regExpRegExp = new RegExp(regexRegex); // A user agent may be expressed as a RegExp string serialization in the the form of `/pattern/[i]*`. If a user
  // agent string does not match this pattern, then the string will be used as a simple string needle for the haystack.

  var isMobile = mobileUserAgents.some(function (pattern) {
    var matches = pattern.match(regExpRegExp); // A regex for a regex. So meta.

    if (matches) {
      var re = new RegExp(matches[1], matches[2]);

      if (re.test(navigator.userAgent)) {
        return true;
      }
    }

    return navigator.userAgent.includes(pattern);
  }); // If not mobile, there's nothing left to do.

  if (!isMobile) {
    return;
  }

  document.addEventListener('DOMContentLoaded', function () {
    // Show the mobile version switcher link once the DOM has loaded.
    var siteVersionSwitcher = document.getElementById('amp-mobile-version-switcher');

    if (!siteVersionSwitcher) {
      return;
    } // Show the link to return to the mobile version of the site since it is hidden by default when client-side
    // redirection is enabled, since JS is used to determine whether it is a mobile browser.


    siteVersionSwitcher.hidden = false; // Re-enable mobile redirection when navigating back to the mobile version of the site.

    var link = siteVersionSwitcher.querySelector('a[href]');

    if (link) {
      link.addEventListener('click', function () {
        sessionStorage.removeItem(disabledStorageKey);
      });
    }
  }); // Short-circuit if mobile redirection is disabled. Redirection is disabled if the user opted-out by clicking the
  // link to exit the mobile version, if they are in paired browsing (since non-AMP and AMP are forced in the respective
  // iframes), and when in the customizer (since the Customizer is opened with a given URL and that should be the URL
  // which is then used for Customization).

  var isPairedBrowsing = isAmpDevMode && ['paired-browsing-non-amp', 'paired-browsing-amp'].includes(window.name);

  if (sessionStorage.getItem(disabledStorageKey) || isCustomizePreview || isPairedBrowsing) {
    return;
  }

  var url = new URL(location.href);

  if (url.searchParams.has(noampQueryVarName) && noampQueryVarValue === url.searchParams.get(noampQueryVarName)) {
    // If the noamp query param is present, remember that redirection should be disabled.
    sessionStorage.setItem(disabledStorageKey, '1');
  } else {
    // Otherwise, since JS is running then we know it's not an AMP page and we need to redirect to the AMP version.
    window.stop(); // Stop loading the page! This should cancel all loading resources.
    // Replace the current page with the AMP version.

    location.replace(ampUrl);
  }
})( // Note: The argument here is replaced with JSON in PHP by \AmpProject\AmpWP\MobileRedirection::add_mobile_redirect_script().
AMP_MOBILE_REDIRECTION);

/***/ })

/******/ });
//# sourceMappingURL=mobile-redirection.js.map