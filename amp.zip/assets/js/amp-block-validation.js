/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./assets/src/block-validation/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./assets/src/block-editor/constants.js":
/*!**********************************************!*\
  !*** ./assets/src/block-editor/constants.js ***!
  \**********************************************/
/*! exports provided: TEXT_BLOCKS, MEDIA_BLOCKS, DEFAULT_WIDTH, DEFAULT_HEIGHT, POST_PREVIEW_CLASS */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TEXT_BLOCKS", function() { return TEXT_BLOCKS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MEDIA_BLOCKS", function() { return MEDIA_BLOCKS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_WIDTH", function() { return DEFAULT_WIDTH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_HEIGHT", function() { return DEFAULT_HEIGHT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "POST_PREVIEW_CLASS", function() { return POST_PREVIEW_CLASS; });
var TEXT_BLOCKS = ['core/paragraph', 'core/heading', 'core/code', 'core/quote', 'core/subhead'];
var MEDIA_BLOCKS = ['core/image', 'core/video'];
var DEFAULT_WIDTH = 608; // Max-width in the editor.

var DEFAULT_HEIGHT = 400;
var POST_PREVIEW_CLASS = 'editor-post-preview';

/***/ }),

/***/ "./assets/src/block-editor/helpers/index.js":
/*!**************************************************!*\
  !*** ./assets/src/block-editor/helpers/index.js ***!
  \**************************************************/
/*! exports provided: addAMPAttributes, filterBlocksSave, getAmpFitTextContent, getLayoutOptions, filterBlocksEdit, setImageBlockLayoutAttributes, setUpInspectorControls, isAMPEnabled */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addAMPAttributes", function() { return addAMPAttributes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "filterBlocksSave", function() { return filterBlocksSave; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAmpFitTextContent", function() { return getAmpFitTextContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLayoutOptions", function() { return getLayoutOptions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "filterBlocksEdit", function() { return filterBlocksEdit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setImageBlockLayoutAttributes", function() { return setImageBlockLayoutAttributes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setUpInspectorControls", function() { return setUpInspectorControls; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isAMPEnabled", function() { return isAMPEnabled; });
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @wordpress/block-editor */ "@wordpress/block-editor");
/* harmony import */ var _wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../constants */ "./assets/src/block-editor/constants.js");
/* harmony import */ var _common_constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../common/constants */ "./assets/src/common/constants.js");


function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */






/**
 * Internal dependencies
 */



var ampLayoutOptions = [{
  value: 'nodisplay',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('No Display', 'amp'),
  notAvailable: ['core-embed/vimeo', 'core-embed/dailymotion', 'core-embed/reddit', 'core-embed/soundcloud']
}, {
  // Not supported by amp-audio and amp-pixel.
  value: 'fixed',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed', 'amp'),
  notAvailable: ['core-embed/soundcloud']
}, {
  // To ensure your AMP element displays, you must specify a width and height for the containing element.
  value: 'responsive',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Responsive', 'amp'),
  notAvailable: ['core-embed/soundcloud']
}, {
  value: 'fixed-height',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fixed Height', 'amp'),
  notAvailable: []
}, {
  value: 'fill',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Fill', 'amp'),
  notAvailable: ['core-embed/soundcloud']
}, {
  value: 'flex-item',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Flex Item', 'amp'),
  notAvailable: ['core-embed/soundcloud']
}, {
  // Not supported by video.
  value: 'intrinsic',
  label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Intrinsic', 'amp'),
  notAvailable: ['core/video', 'core-embed/youtube', 'core-embed/facebook', 'core-embed/instagram', 'core-embed/vimeo', 'core-embed/dailymotion', 'core-embed/reddit', 'core-embed/soundcloud']
}];
/**
 * Add AMP attributes to every core block.
 *
 * @param {Object} settings Block settings.
 * @param {string} name     Block name.
 *
 * @return {Object} Modified block settings.
 */

var addAMPAttributes = function addAMPAttributes(settings, name) {
  // AMP Carousel settings.
  if ('core/gallery' === name) {
    if (!settings.attributes) {
      settings.attributes = {};
    }

    settings.attributes.ampCarousel = {
      type: 'boolean',
      default: !Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_6__["select"])('amp/block-editor').hasThemeSupport() // @todo We could just default this to false now even in Reader mode since block styles are loaded.

    };
    settings.attributes.ampLightbox = {
      type: 'boolean',
      default: false
    };
  } // Add AMP Lightbox settings.


  if ('core/image' === name) {
    if (!settings.attributes) {
      settings.attributes = {};
    }

    settings.attributes.ampLightbox = {
      type: 'boolean',
      default: false
    };
  }

  var isTextBlock = _constants__WEBPACK_IMPORTED_MODULE_7__["TEXT_BLOCKS"].includes(name); // Fit-text for text blocks.

  if (isTextBlock) {
    if (!settings.attributes) {
      settings.attributes = {};
    }

    settings.attributes.ampFitText = {
      type: 'boolean',
      default: false
    };
    settings.attributes.minFont = {
      default: _common_constants__WEBPACK_IMPORTED_MODULE_8__["MIN_FONT_SIZE"],
      source: 'attribute',
      selector: 'amp-fit-text',
      attribute: 'min-font-size'
    };
    settings.attributes.maxFont = {
      default: _common_constants__WEBPACK_IMPORTED_MODULE_8__["MAX_FONT_SIZE"],
      source: 'attribute',
      selector: 'amp-fit-text',
      attribute: 'max-font-size'
    };
    settings.attributes.height = {
      // Needs to be higher than the maximum font size, which defaults to MAX_FONT_SIZE
      default: 'core/image' === name ? 200 : Math.ceil(_common_constants__WEBPACK_IMPORTED_MODULE_8__["MAX_FONT_SIZE"] / 10) * 10,
      source: 'attribute',
      selector: 'amp-fit-text',
      attribute: 'height'
    };
  } // Layout settings for embeds and media blocks.


  if (0 === name.indexOf('core-embed') || _constants__WEBPACK_IMPORTED_MODULE_7__["MEDIA_BLOCKS"].includes(name)) {
    if (!settings.attributes) {
      settings.attributes = {};
    }

    settings.attributes.ampLayout = {
      type: 'string'
    };
    settings.attributes.ampNoLoading = {
      type: 'boolean'
    };
  }

  return settings;
};
/**
 * Filters blocks' save function.
 *
 * @param {Object} element        Element to be saved.
 * @param {string} blockType      Block type.
 * @param {string} blockType.name Block type name.
 * @param {Object} attributes     Attributes.
 *
 * @return {Object} Output element.
 */

var filterBlocksSave = function filterBlocksSave(element, blockType, attributes) {
  // eslint-disable-line complexity
  var fitTextProps = {
    layout: 'fixed-height'
  };

  if ('core/paragraph' === blockType.name && !attributes.ampFitText) {
    var content = getAmpFitTextContent(attributes.content);

    if (content !== attributes.content) {
      return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["cloneElement"])(element, {
        key: 'new',
        value: content
      });
    }
  } else if (_constants__WEBPACK_IMPORTED_MODULE_7__["TEXT_BLOCKS"].includes(blockType.name) && attributes.ampFitText) {
    if (attributes.minFont) {
      fitTextProps['min-font-size'] = attributes.minFont;
    }

    if (attributes.maxFont) {
      fitTextProps['max-font-size'] = attributes.maxFont;
    }

    if (attributes.height) {
      fitTextProps.height = attributes.height;
    }

    fitTextProps.children = element;
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("amp-fit-text", fitTextProps);
  }

  return element;
};
/**
 * Returns the inner content of an AMP Fit Text tag.
 *
 * @param {string} content Original content.
 *
 * @return {string} Modified content.
 */

var getAmpFitTextContent = function getAmpFitTextContent(content) {
  var contentRegex = /<amp-fit-text\b[^>]*>(.*?)<\/amp-fit-text>/;
  var match = contentRegex.exec(content);
  var newContent = content;

  if (match && match[1]) {
    newContent = match[1];
  }

  return newContent;
};
/**
 * Get layout options depending on the block.
 *
 * @param {string} block Block name.
 *
 * @return {Object[]} Options.
 */

var getLayoutOptions = function getLayoutOptions(block) {
  var layoutOptions = [{
    value: '',
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Default', 'amp')
  }];

  var _iterator = _createForOfIteratorHelper(ampLayoutOptions),
      _step;

  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var option = _step.value;
      var isLayoutAvailable = !option.notAvailable.includes(block);

      if (isLayoutAvailable) {
        layoutOptions.push({
          value: option.value,
          label: option.label
        });
      }
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }

  return layoutOptions;
};
/**
 * Filters blocks edit function of all blocks.
 *
 * @param {Function} BlockEdit function.
 *
 * @return {Function} Edit function.
 */

var filterBlocksEdit = function filterBlocksEdit(BlockEdit) {
  var EnhancedBlockEdit = function EnhancedBlockEdit(props) {
    var ampLayout = props.attributes.ampLayout,
        name = props.name;
    var inspectorControls;

    if ('core/gallery' === name) {
      inspectorControls = setUpGalleryInspectorControls(props);
    } else if ('core/image' === name) {
      inspectorControls = setUpImageInspectorControls(props);
    } else if (_constants__WEBPACK_IMPORTED_MODULE_7__["MEDIA_BLOCKS"].includes(name) || 0 === name.indexOf('core-embed/')) {
      inspectorControls = setUpInspectorControls(props);
    } else if (_constants__WEBPACK_IMPORTED_MODULE_7__["TEXT_BLOCKS"].includes(name)) {
      inspectorControls = setUpTextBlocksInspectorControls(props);
    } // Return just inspector controls in case of 'nodisplay'.


    if (ampLayout && 'nodisplay' === ampLayout) {
      return [inspectorControls];
    }

    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(BlockEdit, props), inspectorControls);
  };

  EnhancedBlockEdit.propTypes = {
    attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
      text: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
      ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
    }),
    setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired,
    name: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
  };
  return EnhancedBlockEdit;
};
/**
 * Set width and height in case of image block.
 *
 * @param {Object} props Props.
 * @param {Function} props.setAttributes Callback to set attributes.
 * @param {Object} props.attributes Attributes.
 * @param {string} layout Layout.
 */

var setImageBlockLayoutAttributes = function setImageBlockLayoutAttributes(props, layout) {
  var attributes = props.attributes,
      setAttributes = props.setAttributes;

  switch (layout) {
    case 'fixed-height':
      if (!attributes.height) {
        setAttributes({
          height: _constants__WEBPACK_IMPORTED_MODULE_7__["DEFAULT_HEIGHT"]
        });
      } // Lightbox doesn't work with fixed height, so unset it.


      if (attributes.ampLightbox) {
        setAttributes({
          ampLightbox: false
        });
      }

      break;

    case 'fixed':
      if (!attributes.height) {
        setAttributes({
          height: _constants__WEBPACK_IMPORTED_MODULE_7__["DEFAULT_HEIGHT"]
        });
      }

      if (!attributes.width) {
        setAttributes({
          width: _constants__WEBPACK_IMPORTED_MODULE_7__["DEFAULT_WIDTH"]
        });
      }

      break;

    default:
      break;
  }
};
/**
 * Default setup for inspector controls.
 *
 * @param {Object} props Props.
 *
 * @return {ReactElement} Inspector Controls.
 */

var setUpInspectorControls = function setUpInspectorControls(props) {
  var isSelected = props.isSelected;

  if (!isSelected) {
    return null;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpLayoutControl, props), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpNoloadingToggle, props)));
};
setUpInspectorControls.propTypes = {
  isSelected: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
};
/**
 * Get AMP Layout select control.
 *
 * @param {Object} props Props.
 *
 * @return {ReactElement} Element.
 */

var AmpLayoutControl = function AmpLayoutControl(props) {
  var name = props.name,
      ampLayout = props.attributes.ampLayout,
      setAttributes = props.setAttributes;

  var label = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Layout', 'amp');

  if ('core/image' === name) {
    label = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Layout (modifies width/height)', 'amp');
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["SelectControl"], {
    label: label,
    value: ampLayout,
    options: getLayoutOptions(name),
    onChange: function onChange(value) {
      setAttributes({
        ampLayout: value
      });

      if ('core/image' === props.name) {
        setImageBlockLayoutAttributes(props, value);
      }
    }
  });
};

AmpLayoutControl.propTypes = {
  name: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired
};
/**
 * Get AMP Noloading toggle control.
 *
 * @param {Object} props Props.
 *
 * @return {ReactElement} Element.
 */

var AmpNoloadingToggle = function AmpNoloadingToggle(props) {
  var ampNoLoading = props.attributes.ampNoLoading,
      setAttributes = props.setAttributes;

  var label = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Noloading', 'amp');

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["ToggleControl"], {
    label: label,
    checked: ampNoLoading,
    onChange: function onChange() {
      return setAttributes({
        ampNoLoading: !ampNoLoading
      });
    }
  });
};

AmpNoloadingToggle.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampNoLoading: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired
};
/**
 * Setup inspector controls for text blocks.
 *
 * @todo Consider wrapping the render function to delete the original font size in text settings when ampFitText.
 *
 * @param {Object} props Props.
 * @param {Function} props.setAttributes Callback to set attributes.
 * @param {Object} props.attributes Attributes.
 * @param {boolean} props.isSelected Is selected.
 *
 * @return {ReactElement} Inspector Controls.
 */

var setUpTextBlocksInspectorControls = function setUpTextBlocksInspectorControls(props) {
  var isSelected = props.isSelected,
      attributes = props.attributes,
      setAttributes = props.setAttributes;
  var ampFitText = attributes.ampFitText;
  var minFont = attributes.minFont,
      maxFont = attributes.maxFont,
      height = attributes.height;
  var FONT_SIZES = [{
    name: 'small',
    shortName: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["_x"])('S', 'font size', 'amp'),
    size: 14
  }, {
    name: 'regular',
    shortName: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["_x"])('M', 'font size', 'amp'),
    size: 16
  }, {
    name: 'large',
    shortName: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["_x"])('L', 'font size', 'amp'),
    size: 36
  }, {
    name: 'larger',
    shortName: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["_x"])('XL', 'font size', 'amp'),
    size: 48
  }];

  if (!isSelected) {
    return null;
  }

  var label = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Automatically fit text to container', 'amp');

  if (ampFitText) {
    maxFont = parseInt(maxFont);
    height = parseInt(height);
    minFont = parseInt(minFont);
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Settings', 'amp'),
    className: ampFitText ? 'is-amp-fit-text' : ''
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["ToggleControl"], {
    label: label,
    checked: ampFitText,
    onChange: function onChange() {
      return setAttributes({
        ampFitText: !ampFitText
      });
    }
  })), ampFitText && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["TextControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Height', 'amp'),
    value: height,
    min: 1,
    onChange: function onChange(nextHeight) {
      setAttributes({
        height: nextHeight
      });
    }
  }), maxFont > height && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["Notice"], {
    status: "error",
    isDismissible: false
  }, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('The height must be greater than the max font size.', 'amp')), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Minimum font size', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["FontSizePicker"], {
    fallbackFontSize: 14,
    value: minFont,
    fontSizes: FONT_SIZES,
    onChange: function onChange(nextMinFont) {
      if (!nextMinFont) {
        nextMinFont = _common_constants__WEBPACK_IMPORTED_MODULE_8__["MIN_FONT_SIZE"]; // @todo Supplying fallbackFontSize should be done automatically by the component?
      }

      if (parseInt(nextMinFont) <= maxFont) {
        setAttributes({
          minFont: nextMinFont
        });
      }
    }
  })), minFont > maxFont && Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["Notice"], {
    status: "error",
    isDismissible: false
  }, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('The min font size must less than the max font size.', 'amp')), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Maximum font size', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["FontSizePicker"], {
    fallbackFontSize: 48,
    value: maxFont,
    fontSizes: FONT_SIZES,
    onChange: function onChange(nextMaxFont) {
      if (!nextMaxFont) {
        nextMaxFont = _common_constants__WEBPACK_IMPORTED_MODULE_8__["MAX_FONT_SIZE"]; // @todo Supplying fallbackFontSize should be done automatically by the component?
      }

      setAttributes({
        maxFont: nextMaxFont,
        height: Math.max(nextMaxFont, height)
      });
    }
  }))));
};

setUpTextBlocksInspectorControls.propTypes = {
  isSelected: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampFitText: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
    minFont: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    maxFont: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number,
    height: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.number
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired
};
/**
 * Get AMP Lightbox toggle control.
 *
 * @param {Object} props Props.
 *
 * @return {ReactElement} Element.
 */

var AmpLightboxToggle = function AmpLightboxToggle(props) {
  var _props$attributes = props.attributes,
      ampLightbox = _props$attributes.ampLightbox,
      linkTo = _props$attributes.linkTo,
      ampLayout = _props$attributes.ampLayout,
      setAttributes = props.setAttributes;
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["ToggleControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Add lightbox effect', 'amp'),
    checked: ampLightbox,
    onChange: function onChange(nextValue) {
      setAttributes({
        ampLightbox: !ampLightbox
      });

      if (nextValue) {
        // Lightbox doesn't work with fixed height, so change.
        if ('fixed-height' === ampLayout) {
          setAttributes({
            ampLayout: 'fixed'
          });
        } // In case of lightbox set linking images to 'none'.


        if (linkTo && 'none' !== linkTo) {
          setAttributes({
            linkTo: 'none'
          });
        }
      }
    }
  });
};

AmpLightboxToggle.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampLightbox: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool,
    ampLayout: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
    linkTo: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired
};
/**
 * Get AMP Carousel toggle control.
 *
 * @param {Object}   props                        Props.
 * @param {Object}   props.attributes             Block attributes.
 * @param {Object}   props.attributes.ampCarousel AMP Carousel toggle value.
 * @param {Function} props.setAttributes          Callback to update attributes.
 *
 * @return {Object} Element.
 */

var AmpCarouselToggle = function AmpCarouselToggle(props) {
  var ampCarousel = props.attributes.ampCarousel,
      setAttributes = props.setAttributes;
  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["ToggleControl"], {
    label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Display as carousel', 'amp'),
    checked: ampCarousel,
    onChange: function onChange() {
      return setAttributes({
        ampCarousel: !ampCarousel
      });
    }
  });
};

AmpCarouselToggle.propTypes = {
  attributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.shape({
    ampCarousel: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
  }),
  setAttributes: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.func.isRequired
};
/**
 * Set up inspector controls for Image block.
 *
 * @param {Object}  props            Props.
 * @param {boolean} props.isSelected Whether the current block has been selected or not.
 *
 * @return {Object} Inspector Controls.
 */

var setUpImageInspectorControls = function setUpImageInspectorControls(props) {
  var isSelected = props.isSelected;

  if (!isSelected) {
    return null;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpLayoutControl, props), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpNoloadingToggle, props), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpLightboxToggle, props)));
};

setUpImageInspectorControls.propTypes = {
  isSelected: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
};
/**
 * Set up inspector controls for Gallery block.
 * Adds ampCarousel attribute for displaying the output as amp-carousel.
 *
 * @param {Object}  props            Props.
 * @param {boolean} props.isSelected Whether the current block has been selected or not.
 *
 * @return {Object} Inspector controls.
 */

var setUpGalleryInspectorControls = function setUpGalleryInspectorControls(props) {
  var isSelected = props.isSelected;

  if (!isSelected) {
    return null;
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_block_editor__WEBPACK_IMPORTED_MODULE_5__["InspectorControls"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_4__["PanelBody"], {
    title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('AMP Settings', 'amp')
  }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpCarouselToggle, props), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(AmpLightboxToggle, props)));
};

setUpGalleryInspectorControls.propTypes = {
  isSelected: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.bool
};
/**
 * Determines whether AMP is enabled for the current post or not.
 *
 * For regular posts, this is based on the AMP toggle control and also
 * the default status based on the template mode.
 *
 * @return {boolean} Whether AMP is enabled.
 */

var isAMPEnabled = function isAMPEnabled() {
  var _select = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_6__["select"])('core/editor'),
      getEditedPostAttribute = _select.getEditedPostAttribute;

  return getEditedPostAttribute('amp_enabled') || false;
};

/***/ }),

/***/ "./assets/src/block-editor/store/index.js":
/*!************************************************!*\
  !*** ./assets/src/block-editor/store/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _selectors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./selectors */ "./assets/src/block-editor/store/selectors.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */


/**
 * Module Constants
 */

var MODULE_KEY = 'amp/block-editor';
/* harmony default export */ __webpack_exports__["default"] = (Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__["registerStore"])(MODULE_KEY, {
  reducer: function reducer(state) {
    return state;
  },
  selectors: _selectors__WEBPACK_IMPORTED_MODULE_2__,
  initialState: _objectSpread({}, window.ampBlockEditor)
}));

/***/ }),

/***/ "./assets/src/block-editor/store/selectors.js":
/*!****************************************************!*\
  !*** ./assets/src/block-editor/store/selectors.js ***!
  \****************************************************/
/*! exports provided: hasThemeSupport, isStandardMode, getErrorMessages, getAmpSlug */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hasThemeSupport", function() { return hasThemeSupport; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isStandardMode", function() { return isStandardMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getErrorMessages", function() { return getErrorMessages; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAmpSlug", function() { return getAmpSlug; });
/**
 * Returns whether the current theme has AMP support.
 *
 * @param {Object} state Editor state.
 *
 * @return {boolean} Whether the current theme has AMP support.
 */
function hasThemeSupport(state) {
  return Boolean(state.hasThemeSupport);
}
/**
 * Returns whether the current site is in Standard mode (AMP-first) as opposed to Transitional (paired).
 *
 * @param {Object} state Editor state.
 *
 * @return {boolean} Whether the current site is AMP-first.
 */

function isStandardMode(state) {
  return Boolean(state.isStandardMode);
}
/**
 * Returns the AMP validation error messages.
 *
 * @param {Object} state The editor state.
 *
 * @return {string[]} The validation error messages.
 */

function getErrorMessages(state) {
  return state.errorMessages;
}
/**
 * Returns the AMP slug used in the query var, like 'amp'.
 *
 * @param {Object} state The editor state.
 *
 * @return {string} The slug for AMP, like 'amp'.
 */

function getAmpSlug(state) {
  return state.ampSlug;
}

/***/ }),

/***/ "./assets/src/block-validation/components/higher-order/with-validation-error-notice/edit.css":
/*!***************************************************************************************************!*\
  !*** ./assets/src/block-validation/components/higher-order/with-validation-error-notice/edit.css ***!
  \***************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./assets/src/block-validation/components/higher-order/with-validation-error-notice/index.js":
/*!***************************************************************************************************!*\
  !*** ./assets/src/block-validation/components/higher-order/with-validation-error-notice/index.js ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/components */ "@wordpress/components");
/* harmony import */ var _wordpress_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/compose */ "@wordpress/compose");
/* harmony import */ var _wordpress_compose__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_compose__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../ */ "./assets/src/block-validation/components/index.js");
/* harmony import */ var _edit_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit.css */ "./assets/src/block-validation/components/higher-order/with-validation-error-notice/edit.css");
/* harmony import */ var _edit_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_edit_css__WEBPACK_IMPORTED_MODULE_6__);


/**
 * WordPress dependencies
 */




/**
 * Internal dependencies
 */



var applyWithSelect = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_4__["withSelect"])(function (select, _ref) {
  var clientId = _ref.clientId;

  var _select = select('amp/block-validation'),
      getBlockValidationErrors = _select.getBlockValidationErrors;

  var blockValidationErrors = getBlockValidationErrors(clientId);
  return {
    blockValidationErrors: blockValidationErrors.length ? blockValidationErrors : undefined
  };
});
/**
 * Wraps the edit() method of a block, and conditionally adds a Notice.
 *
 * @param {Function} BlockEdit - The original edit() method of the block.
 * @return {Function} The edit() method, conditionally wrapped in a notice for AMP validation error(s).
 */

/* harmony default export */ __webpack_exports__["default"] = (Object(_wordpress_compose__WEBPACK_IMPORTED_MODULE_3__["createHigherOrderComponent"])(function (BlockEdit) {
  return applyWithSelect(function (props) {
    var blockValidationErrors = props.blockValidationErrors,
        onReplace = props.onReplace;

    if (!blockValidationErrors) {
      return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(BlockEdit, props);
    }

    var errorCount = blockValidationErrors.length;
    var actions = [{
      label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('Remove Block', 'amp'),
      onClick: function onClick() {
        return onReplace([]);
      }
    }];
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_components__WEBPACK_IMPORTED_MODULE_1__["Notice"], {
      status: "warning",
      isDismissible: false,
      actions: actions
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("details", {
      className: "amp-block-validation-errors"
    }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("summary", {
      className: "amp-block-validation-errors__summary"
    }, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["sprintf"])(
    /* translators: %s is the number of issues */
    Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["_n"])('There is %s issue from AMP validation.', 'There are %s issues from AMP validation.', errorCount, 'amp'), errorCount)), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("ul", {
      className: "amp-block-validation-errors__list"
    }, blockValidationErrors.map(function (error, key) {
      return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("li", {
        key: key
      }, Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(___WEBPACK_IMPORTED_MODULE_5__["ValidationErrorMessage"], error));
    })))), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(BlockEdit, props));
  });
}, 'withValidationErrorNotice'));

/***/ }),

/***/ "./assets/src/block-validation/components/index.js":
/*!*********************************************************!*\
  !*** ./assets/src/block-validation/components/index.js ***!
  \*********************************************************/
/*! exports provided: ValidationErrorMessage, withValidationErrorNotice */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _validation_error_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./validation-error-message */ "./assets/src/block-validation/components/validation-error-message/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ValidationErrorMessage", function() { return _validation_error_message__WEBPACK_IMPORTED_MODULE_0__["default"]; });

/* harmony import */ var _higher_order_with_validation_error_notice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./higher-order/with-validation-error-notice */ "./assets/src/block-validation/components/higher-order/with-validation-error-notice/index.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "withValidationErrorNotice", function() { return _higher_order_with_validation_error_notice__WEBPACK_IMPORTED_MODULE_1__["default"]; });




/***/ }),

/***/ "./assets/src/block-validation/components/validation-error-message/index.js":
/*!**********************************************************************************!*\
  !*** ./assets/src/block-validation/components/validation-error-message/index.js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/element */ "@wordpress/element");
/* harmony import */ var _wordpress_element__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);


/**
 * External dependencies
 */


/**
 * WordPress dependencies
 */


/**
 * Get message for validation error.
 *
 * @param {Object}  props Component props.
 * @param {?string} props.title Title for error (with HTML) as provided by \AMP_Validation_Error_Taxonomy::get_error_title_from_code().
 * @param {?string} props.code Error code.
 * @param {?string|ReactElement} props.message Error message.
 *
 * @return {ReactElement} Validation error message.
 */

var ValidationErrorMessage = function ValidationErrorMessage(_ref) {
  var title = _ref.title,
      message = _ref.message,
      code = _ref.code;

  if (message) {
    return message; // @todo It doesn't appear this is ever set?
  }

  if (title) {
    return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("span", {
      dangerouslySetInnerHTML: {
        __html: title
      }
    });
  }

  return Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Error code: ', 'amp'), Object(_wordpress_element__WEBPACK_IMPORTED_MODULE_0__["createElement"])("code", null, code || Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('unknown', 'amp')));
};

ValidationErrorMessage.propTypes = {
  message: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  title: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string,
  code: prop_types__WEBPACK_IMPORTED_MODULE_1___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (ValidationErrorMessage);

/***/ }),

/***/ "./assets/src/block-validation/constants.js":
/*!**************************************************!*\
  !*** ./assets/src/block-validation/constants.js ***!
  \**************************************************/
/*! exports provided: VALIDATION_ERROR_NEW_REJECTED_STATUS, VALIDATION_ERROR_NEW_ACCEPTED_STATUS, VALIDATION_ERROR_ACK_REJECTED_STATUS, VALIDATION_ERROR_ACK_ACCEPTED_STATUS, AMP_VALIDATION_ERROR_NOTICE_ID, AMP_VALIDITY_REST_FIELD_NAME */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VALIDATION_ERROR_NEW_REJECTED_STATUS", function() { return VALIDATION_ERROR_NEW_REJECTED_STATUS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VALIDATION_ERROR_NEW_ACCEPTED_STATUS", function() { return VALIDATION_ERROR_NEW_ACCEPTED_STATUS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VALIDATION_ERROR_ACK_REJECTED_STATUS", function() { return VALIDATION_ERROR_ACK_REJECTED_STATUS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VALIDATION_ERROR_ACK_ACCEPTED_STATUS", function() { return VALIDATION_ERROR_ACK_ACCEPTED_STATUS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AMP_VALIDATION_ERROR_NOTICE_ID", function() { return AMP_VALIDATION_ERROR_NOTICE_ID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AMP_VALIDITY_REST_FIELD_NAME", function() { return AMP_VALIDITY_REST_FIELD_NAME; });
// See \AMP_Validation_Error_Taxonomy class in PHP.
var VALIDATION_ERROR_NEW_REJECTED_STATUS = 0;
var VALIDATION_ERROR_NEW_ACCEPTED_STATUS = 1;
var VALIDATION_ERROR_ACK_REJECTED_STATUS = 2;
var VALIDATION_ERROR_ACK_ACCEPTED_STATUS = 3;
var AMP_VALIDATION_ERROR_NOTICE_ID = 'amp-errors-notice'; // See \AMP_Validation_Manager::VALIDITY_REST_FIELD_NAME in PHP.

var AMP_VALIDITY_REST_FIELD_NAME = 'amp_validity';

/***/ }),

/***/ "./assets/src/block-validation/helpers/index.js":
/*!******************************************************!*\
  !*** ./assets/src/block-validation/helpers/index.js ***!
  \******************************************************/
/*! exports provided: removeValidationErrorNotice, maybeResetValidationErrors, updateValidationErrors, maybeDisplayNotice */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeValidationErrorNotice", function() { return removeValidationErrorNotice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "maybeResetValidationErrors", function() { return maybeResetValidationErrors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateValidationErrors", function() { return updateValidationErrors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "maybeDisplayNotice", function() { return maybeDisplayNotice; });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../constants */ "./assets/src/block-validation/constants.js");


function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */



/**
 * Internal dependencies
 */


var removeValidationErrorNotice = function removeValidationErrorNotice() {
  var _select = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_2__["select"])('core/notices'),
      getNotices = _select.getNotices;

  var _dispatch = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_2__["dispatch"])('core/notices'),
      removeNotice = _dispatch.removeNotice;

  if (getNotices().filter(function (_ref) {
    var id = _ref.id;
    return id === _constants__WEBPACK_IMPORTED_MODULE_4__["AMP_VALIDATION_ERROR_NOTICE_ID"];
  })) {
    removeNotice(_constants__WEBPACK_IMPORTED_MODULE_4__["AMP_VALIDATION_ERROR_NOTICE_ID"]);
  }
};
var previousValidationErrors = [];
var maybeResetValidationErrors = function maybeResetValidationErrors() {
  var _select2 = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_2__["select"])('amp/block-validation'),
      getValidationErrors = _select2.getValidationErrors;

  var _dispatch2 = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_2__["dispatch"])('amp/block-validation'),
      resetValidationErrors = _dispatch2.resetValidationErrors;

  if (getValidationErrors().length > 0) {
    resetValidationErrors();
    removeValidationErrorNotice();
    previousValidationErrors = [];
  }
};
/**
 * Update blocks' validation errors in the store.
 */

var updateValidationErrors = function updateValidationErrors() {
  var _select3 = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_2__["select"])('core/block-editor'),
      getBlockCount = _select3.getBlockCount,
      getClientIdsWithDescendants = _select3.getClientIdsWithDescendants,
      getBlock = _select3.getBlock;

  var _dispatch3 = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_2__["dispatch"])('amp/block-validation'),
      resetValidationErrors = _dispatch3.resetValidationErrors,
      addValidationError = _dispatch3.addValidationError,
      updateReviewLink = _dispatch3.updateReviewLink;

  if (0 === getBlockCount()) {
    return;
  }

  var _select4 = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_2__["select"])('core/editor'),
      getCurrentPost = _select4.getCurrentPost;

  var currentPost = getCurrentPost();
  /**
   * @param {Object}   ampValidity             AMP validation result object.
   * @param {Object[]} ampValidity.results     AMP validation results.
   * @param {string}   ampValidity.review_link URL for reviewing validation error details.
   */

  var ampValidity = currentPost[_constants__WEBPACK_IMPORTED_MODULE_4__["AMP_VALIDITY_REST_FIELD_NAME"]] || {};

  if (!ampValidity.results || !ampValidity.review_link) {
    return;
  }
  /**
   * @param {Object}  result             Validation error result.
   * @param {Object}  result.error       Error object.
   * @param {string}  result.title       Error title.
   * @param {boolean} result.forced      Whether sanitization was forced.
   * @param {boolean} result.sanitized   Whether the error has been sanitized or not.
   * @param {number}  result.status      Validation error status.
   * @param {number}  result.term_status Error status.
   */


  var validationErrors = ampValidity.results.filter(function (result) {
    return result.term_status !== _constants__WEBPACK_IMPORTED_MODULE_4__["VALIDATION_ERROR_ACK_ACCEPTED_STATUS"]; // If not accepted by the user.
  }).map(function (_ref2) {
    var error = _ref2.error,
        status = _ref2.status,
        title = _ref2.title;
    return _objectSpread(_objectSpread({}, error), {}, {
      status: status,
      title: title
    });
  }); // Merge status into error since needed in maybeDisplayNotice.

  if (Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isEqual"])(validationErrors, previousValidationErrors)) {
    return;
  }

  previousValidationErrors = validationErrors;
  resetValidationErrors();

  if (0 === validationErrors.length) {
    removeValidationErrorNotice();
    return;
  }

  updateReviewLink(ampValidity.review_link);
  var blockOrder = getClientIdsWithDescendants();

  var _iterator = _createForOfIteratorHelper(validationErrors),
      _step;

  try {
    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      var validationError = _step.value;

      if (!validationError.sources) {
        addValidationError(validationError);
        break;
      }

      var clientId = void 0;
      /**
       * @param {Object} source                     Error source information.
       * @param {string} source.block_name          Name of the block associated with the error.
       * @param {number} source.block_content_index The block's index in the list of blocks.
       * @param {number} source.post_id             ID of the post associated with the error.
       */

      var _iterator2 = _createForOfIteratorHelper(validationError.sources),
          _step2;

      try {
        for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
          var source = _step2.value;

          // Skip sources that are not for blocks.
          if (!source.block_name || undefined === source.block_content_index || currentPost.id !== source.post_id) {
            continue;
          } // Look up the block ID by index, assuming the blocks of content in the editor are the same as blocks rendered on frontend.


          var newClientId = blockOrder[source.block_content_index];

          if (!newClientId) {
            continue;
          } // Sanity check that block exists for clientId.


          var block = getBlock(newClientId);

          if (!block) {
            continue;
          } // Check the block type in case a block is dynamically added/removed via the_content filter to cause alignment error.


          if (block.name !== source.block_name) {
            continue;
          }

          clientId = newClientId;
        }
      } catch (err) {
        _iterator2.e(err);
      } finally {
        _iterator2.f();
      }

      addValidationError(validationError, clientId);
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }

  maybeDisplayNotice();
};
/**
 * Handle state change regarding validation errors.
 *
 * This is essentially a JS implementation of \AMP_Validation_Manager::print_edit_form_validation_status() in PHP.
 *
 * @return {void}
 */

var maybeDisplayNotice = function maybeDisplayNotice() {
  var _select5 = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_2__["select"])('amp/block-validation'),
      getValidationErrors = _select5.getValidationErrors,
      getReviewLink = _select5.getReviewLink;

  var _dispatch4 = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_2__["dispatch"])('core/notices'),
      createWarningNotice = _dispatch4.createWarningNotice;

  var validationErrors = getValidationErrors();
  var validationErrorCount = validationErrors.length;
  var noticeMessage;
  noticeMessage = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["sprintf"])(
  /* translators: %s: number of issues */
  Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["_n"])('There is %s issue from AMP validation which needs review.', 'There are %s issues from AMP validation which need review.', validationErrorCount, 'amp'), validationErrorCount);
  var blockValidationErrors = validationErrors.filter(function (_ref3) {
    var clientId = _ref3.clientId;
    return clientId;
  });
  var blockValidationErrorCount = blockValidationErrors.length;

  if (blockValidationErrorCount > 0) {
    noticeMessage += ' ' + Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["sprintf"])(
    /* translators: %s: number of block errors. */
    Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["_n"])('%s issue is directly due to content here.', '%s issues are directly due to content here.', blockValidationErrorCount, 'amp'), blockValidationErrorCount);
  } else if (validationErrors.length === 1) {
    noticeMessage += ' ' + Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('The issue is not directly due to content here.', 'amp');
  } else {
    noticeMessage += ' ' + Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('The issues are not directly due to content here.', 'amp');
  }

  noticeMessage += ' ';
  var rejectedBlockValidationErrors = blockValidationErrors.filter(function (error) {
    return _constants__WEBPACK_IMPORTED_MODULE_4__["VALIDATION_ERROR_NEW_REJECTED_STATUS"] === error.status || _constants__WEBPACK_IMPORTED_MODULE_4__["VALIDATION_ERROR_ACK_REJECTED_STATUS"] === error.status;
  });
  var rejectedValidationErrors = validationErrors.filter(function (error) {
    return _constants__WEBPACK_IMPORTED_MODULE_4__["VALIDATION_ERROR_NEW_REJECTED_STATUS"] === error.status || _constants__WEBPACK_IMPORTED_MODULE_4__["VALIDATION_ERROR_ACK_REJECTED_STATUS"] === error.status;
  });
  var totalRejectedErrorsCount = rejectedBlockValidationErrors.length + rejectedValidationErrors.length;

  if (totalRejectedErrorsCount === 0) {
    noticeMessage += Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('The invalid markup has been automatically removed.', 'amp');
  } else {
    noticeMessage += Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["_n"])('You will have to remove the invalid markup (or allow the plugin to remove it) to serve AMP.', 'You will have to remove the invalid markup (or allow the plugin to remove it) to serve AMP.', validationErrors.length, 'amp');
  }

  var options = {
    id: _constants__WEBPACK_IMPORTED_MODULE_4__["AMP_VALIDATION_ERROR_NOTICE_ID"]
  };
  var reviewLink = getReviewLink();

  if (reviewLink) {
    options.actions = [{
      label: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_3__["__"])('Review issues', 'amp'),
      className: 'is-link',
      onClick: function onClick() {
        window.open(reviewLink, '_blank');
      }
    }];
  }

  createWarningNotice(noticeMessage, options);
};

/***/ }),

/***/ "./assets/src/block-validation/index.js":
/*!**********************************************!*\
  !*** ./assets/src/block-validation/index.js ***!
  \**********************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @wordpress/hooks */ "@wordpress/hooks");
/* harmony import */ var _wordpress_hooks__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _block_editor_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../block-editor/helpers */ "./assets/src/block-editor/helpers/index.js");
/* harmony import */ var _helpers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./helpers */ "./assets/src/block-validation/helpers/index.js");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components */ "./assets/src/block-validation/components/index.js");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./store */ "./assets/src/block-validation/store/index.js");
/* harmony import */ var _block_editor_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../block-editor/store */ "./assets/src/block-editor/store/index.js");
/**
 * Validates blocks for AMP compatibility.
 *
 * This uses the REST API response from saving a page to find validation errors.
 * If one exists for a block, it display it inline with a Notice component.
 */

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */







var _select = Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__["select"])('core/editor'),
    isEditedPostDirty = _select.isEditedPostDirty;

Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__["subscribe"])(function () {
  try {
    if (!isEditedPostDirty()) {
      if (!Object(_block_editor_helpers__WEBPACK_IMPORTED_MODULE_2__["isAMPEnabled"])()) {
        Object(_helpers__WEBPACK_IMPORTED_MODULE_3__["maybeResetValidationErrors"])();
      } else {
        Object(_helpers__WEBPACK_IMPORTED_MODULE_3__["updateValidationErrors"])();
      }
    }
  } catch (err) {}
});
Object(_wordpress_hooks__WEBPACK_IMPORTED_MODULE_0__["addFilter"])('editor.BlockEdit', 'amp/add-notice', _components__WEBPACK_IMPORTED_MODULE_4__["withValidationErrorNotice"], 99);

/***/ }),

/***/ "./assets/src/block-validation/store/actions.js":
/*!******************************************************!*\
  !*** ./assets/src/block-validation/store/actions.js ***!
  \******************************************************/
/*! exports provided: addValidationError, resetValidationErrors, updateReviewLink */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addValidationError", function() { return addValidationError; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetValidationErrors", function() { return resetValidationErrors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updateReviewLink", function() { return updateReviewLink; });
/**
 * Returns an action object in signalling that a validation error should be added.
 *
 * @param {Object}  error    Validation error.
 * @param {?string} clientId Optional. Block client ID. Used when the validation error is specific to a block.
 *
 * @return {Object} Action object.
 */
function addValidationError(error, clientId) {
  return {
    type: 'ADD_VALIDATION_ERROR',
    error: error,
    clientId: clientId
  };
}
/**
 * Returns an action object in signalling that validation errors should be reset.
 *
 * @return {Object} Action object.
 */

function resetValidationErrors() {
  return {
    type: 'RESET_VALIDATION_ERRORS'
  };
}
/**
 * Returns an action object in signalling that the review URL should be updated.
 *
 * @param {string} url Issue review URL.
 *
 * @return {Object} Action object.
 */

function updateReviewLink(url) {
  return {
    type: 'UPDATE_REVIEW_LINK',
    url: url
  };
}

/***/ }),

/***/ "./assets/src/block-validation/store/index.js":
/*!****************************************************!*\
  !*** ./assets/src/block-validation/store/index.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/data */ "@wordpress/data");
/* harmony import */ var _wordpress_data__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _reducer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reducer */ "./assets/src/block-validation/store/reducer.js");
/* harmony import */ var _actions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./actions */ "./assets/src/block-validation/store/actions.js");
/* harmony import */ var _selectors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./selectors */ "./assets/src/block-validation/store/selectors.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * WordPress dependencies
 */

/**
 * Internal dependencies
 */




/**
 * Module Constants
 */

var MODULE_KEY = 'amp/block-validation';
/* harmony default export */ __webpack_exports__["default"] = (Object(_wordpress_data__WEBPACK_IMPORTED_MODULE_1__["registerStore"])(MODULE_KEY, {
  reducer: _reducer__WEBPACK_IMPORTED_MODULE_2__["default"],
  selectors: _selectors__WEBPACK_IMPORTED_MODULE_4__,
  actions: _actions__WEBPACK_IMPORTED_MODULE_3__,
  initialState: _objectSpread(_objectSpread({}, window.ampBlockValidation), {}, {
    errors: [],
    reviewLink: undefined
  })
}));

/***/ }),

/***/ "./assets/src/block-validation/store/reducer.js":
/*!******************************************************!*\
  !*** ./assets/src/block-validation/store/reducer.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

/**
 * Reducer handling changes related to block validation.
 *
 * @param {Object} state  Current state.
 * @param {Object} action Dispatched action.
 *
 * @return {Object} Updated state.
 */
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : undefined;
  var action = arguments.length > 1 ? arguments[1] : undefined;
  var type = action.type,
      url = action.url,
      error = action.error,
      clientId = action.clientId;

  switch (type) {
    case 'ADD_VALIDATION_ERROR':
      var errors = state ? state.errors : [];

      var enhancedError = _objectSpread(_objectSpread({}, error), {}, {
        clientId: clientId
      });

      return _objectSpread(_objectSpread({}, state), {}, {
        errors: [].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(errors), [enhancedError])
      });

    case 'RESET_VALIDATION_ERRORS':
      return _objectSpread(_objectSpread({}, state), {}, {
        errors: []
      });

    case 'UPDATE_REVIEW_LINK':
      return _objectSpread(_objectSpread({}, state), {}, {
        reviewLink: url
      });

    default:
      return state;
  }
});

/***/ }),

/***/ "./assets/src/block-validation/store/selectors.js":
/*!********************************************************!*\
  !*** ./assets/src/block-validation/store/selectors.js ***!
  \********************************************************/
/*! exports provided: getValidationErrors, getBlockValidationErrors, getReviewLink, isSanitizationAutoAccepted */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getValidationErrors", function() { return getValidationErrors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBlockValidationErrors", function() { return getBlockValidationErrors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getReviewLink", function() { return getReviewLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSanitizationAutoAccepted", function() { return isSanitizationAutoAccepted; });
/**
 * Returns general validation errors.
 *
 * @param {Object} state Editor state.
 *
 * @return {Array} Validation errors.
 */
function getValidationErrors(state) {
  return state.errors;
}
/**
 * Returns the block validation errors for a given clientId.
 *
 * @param {Object} state    Editor state.
 * @param {string} clientId Block client ID.
 *
 * @return {Array} Block validation errors.
 */

function getBlockValidationErrors(state, clientId) {
  return state.errors.filter(function (error) {
    return error.clientId === clientId;
  });
}
/**
 * Returns the URL for reviewing validation issues.
 *
 * @param {Object} state Editor state.
 *
 * @return {string} Validation errors review link.
 */

function getReviewLink(state) {
  return state.reviewLink;
}
/**
 * Returns whether sanitization errors are auto-accepted.
 *
 * Auto-acceptance is from either checking 'Automatically accept sanitization...' or from being in Standard mode.
 *
 * @param {Object} state Editor state.
 *
 * @return {boolean} Whether sanitization errors are auto-accepted.
 */

function isSanitizationAutoAccepted(state) {
  return Boolean(state.isSanitizationAutoAccepted);
}

/***/ }),

/***/ "./assets/src/common/constants.js":
/*!****************************************!*\
  !*** ./assets/src/common/constants.js ***!
  \****************************************/
/*! exports provided: MIN_FONT_SIZE, MAX_FONT_SIZE, MINIMUM_FEATURED_IMAGE_WIDTH, FILE_TYPE_ERROR_VIEW, READER, STANDARD, TRANSITIONAL, DEFAULT_MOBILE_BREAKPOINT */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MIN_FONT_SIZE", function() { return MIN_FONT_SIZE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MAX_FONT_SIZE", function() { return MAX_FONT_SIZE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MINIMUM_FEATURED_IMAGE_WIDTH", function() { return MINIMUM_FEATURED_IMAGE_WIDTH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FILE_TYPE_ERROR_VIEW", function() { return FILE_TYPE_ERROR_VIEW; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "READER", function() { return READER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STANDARD", function() { return STANDARD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TRANSITIONAL", function() { return TRANSITIONAL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_MOBILE_BREAKPOINT", function() { return DEFAULT_MOBILE_BREAKPOINT; });
// See https://github.com/ampproject/amphtml/blob/e7a1b3ff97645ec0ec482192205134bd0735943c/extensions/amp-fit-text/0.1/amp-fit-text.js#L81-L85
var MIN_FONT_SIZE = 6;
var MAX_FONT_SIZE = 72;
var MINIMUM_FEATURED_IMAGE_WIDTH = 1200;
var FILE_TYPE_ERROR_VIEW = 'select-file-type-error';
var READER = 'reader';
var STANDARD = 'standard';
var TRANSITIONAL = 'transitional';
var DEFAULT_MOBILE_BREAKPOINT = 783;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayLikeToArray.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

module.exports = _arrayLikeToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return arrayLikeToArray(arr);
}

module.exports = _arrayWithoutHoles;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/defineProperty.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/defineProperty.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/iterableToArray.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/iterableToArray.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

module.exports = _iterableToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/nonIterableSpread.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

module.exports = _nonIterableSpread;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toConsumableArray.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toConsumableArray.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithoutHoles = __webpack_require__(/*! ./arrayWithoutHoles */ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js");

var iterableToArray = __webpack_require__(/*! ./iterableToArray */ "./node_modules/@babel/runtime/helpers/iterableToArray.js");

var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray */ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");

var nonIterableSpread = __webpack_require__(/*! ./nonIterableSpread */ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js");

function _toConsumableArray(arr) {
  return arrayWithoutHoles(arr) || iterableToArray(arr) || unsupportedIterableToArray(arr) || nonIterableSpread();
}

module.exports = _toConsumableArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return arrayLikeToArray(o, minLen);
}

module.exports = _unsupportedIterableToArray;

/***/ }),

/***/ "./node_modules/object-assign/index.js":
/*!*********************************************!*\
  !*** ./node_modules/object-assign/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),

/***/ "./node_modules/prop-types/checkPropTypes.js":
/*!***************************************************!*\
  !*** ./node_modules/prop-types/checkPropTypes.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var printWarning = function() {};

if (true) {
  var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "./node_modules/prop-types/lib/ReactPropTypesSecret.js");
  var loggedTypeFailures = {};
  var has = Function.call.bind(Object.prototype.hasOwnProperty);

  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  };
}

/**
 * Assert that the values match with the type specs.
 * Error messages are memorized and will only be shown once.
 *
 * @param {object} typeSpecs Map of name to a ReactPropType
 * @param {object} values Runtime values that need to be type-checked
 * @param {string} location e.g. "prop", "context", "child context"
 * @param {string} componentName Name of the component for error messages.
 * @param {?Function} getStack Returns the component stack.
 * @private
 */
function checkPropTypes(typeSpecs, values, location, componentName, getStack) {
  if (true) {
    for (var typeSpecName in typeSpecs) {
      if (has(typeSpecs, typeSpecName)) {
        var error;
        // Prop type validation may throw. In case they do, we don't want to
        // fail the render phase where it didn't fail before. So we log it.
        // After these have been cleaned up, we'll let them throw.
        try {
          // This is intentionally an invariant that gets caught. It's the same
          // behavior as without this statement except with a better message.
          if (typeof typeSpecs[typeSpecName] !== 'function') {
            var err = Error(
              (componentName || 'React class') + ': ' + location + ' type `' + typeSpecName + '` is invalid; ' +
              'it must be a function, usually from the `prop-types` package, but received `' + typeof typeSpecs[typeSpecName] + '`.'
            );
            err.name = 'Invariant Violation';
            throw err;
          }
          error = typeSpecs[typeSpecName](values, typeSpecName, componentName, location, null, ReactPropTypesSecret);
        } catch (ex) {
          error = ex;
        }
        if (error && !(error instanceof Error)) {
          printWarning(
            (componentName || 'React class') + ': type specification of ' +
            location + ' `' + typeSpecName + '` is invalid; the type checker ' +
            'function must return `null` or an `Error` but returned a ' + typeof error + '. ' +
            'You may have forgotten to pass an argument to the type checker ' +
            'creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and ' +
            'shape all require an argument).'
          );
        }
        if (error instanceof Error && !(error.message in loggedTypeFailures)) {
          // Only monitor this failure once because there tends to be a lot of the
          // same error.
          loggedTypeFailures[error.message] = true;

          var stack = getStack ? getStack() : '';

          printWarning(
            'Failed ' + location + ' type: ' + error.message + (stack != null ? stack : '')
          );
        }
      }
    }
  }
}

/**
 * Resets warning cache when testing.
 *
 * @private
 */
checkPropTypes.resetWarningCache = function() {
  if (true) {
    loggedTypeFailures = {};
  }
}

module.exports = checkPropTypes;


/***/ }),

/***/ "./node_modules/prop-types/factoryWithTypeCheckers.js":
/*!************************************************************!*\
  !*** ./node_modules/prop-types/factoryWithTypeCheckers.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactIs = __webpack_require__(/*! react-is */ "./node_modules/react-is/index.js");
var assign = __webpack_require__(/*! object-assign */ "./node_modules/object-assign/index.js");

var ReactPropTypesSecret = __webpack_require__(/*! ./lib/ReactPropTypesSecret */ "./node_modules/prop-types/lib/ReactPropTypesSecret.js");
var checkPropTypes = __webpack_require__(/*! ./checkPropTypes */ "./node_modules/prop-types/checkPropTypes.js");

var has = Function.call.bind(Object.prototype.hasOwnProperty);
var printWarning = function() {};

if (true) {
  printWarning = function(text) {
    var message = 'Warning: ' + text;
    if (typeof console !== 'undefined') {
      console.error(message);
    }
    try {
      // --- Welcome to debugging React ---
      // This error was thrown as a convenience so that you can use this stack
      // to find the callsite that caused this warning to fire.
      throw new Error(message);
    } catch (x) {}
  };
}

function emptyFunctionThatReturnsNull() {
  return null;
}

module.exports = function(isValidElement, throwOnDirectAccess) {
  /* global Symbol */
  var ITERATOR_SYMBOL = typeof Symbol === 'function' && Symbol.iterator;
  var FAUX_ITERATOR_SYMBOL = '@@iterator'; // Before Symbol spec.

  /**
   * Returns the iterator method function contained on the iterable object.
   *
   * Be sure to invoke the function with the iterable as context:
   *
   *     var iteratorFn = getIteratorFn(myIterable);
   *     if (iteratorFn) {
   *       var iterator = iteratorFn.call(myIterable);
   *       ...
   *     }
   *
   * @param {?object} maybeIterable
   * @return {?function}
   */
  function getIteratorFn(maybeIterable) {
    var iteratorFn = maybeIterable && (ITERATOR_SYMBOL && maybeIterable[ITERATOR_SYMBOL] || maybeIterable[FAUX_ITERATOR_SYMBOL]);
    if (typeof iteratorFn === 'function') {
      return iteratorFn;
    }
  }

  /**
   * Collection of methods that allow declaration and validation of props that are
   * supplied to React components. Example usage:
   *
   *   var Props = require('ReactPropTypes');
   *   var MyArticle = React.createClass({
   *     propTypes: {
   *       // An optional string prop named "description".
   *       description: Props.string,
   *
   *       // A required enum prop named "category".
   *       category: Props.oneOf(['News','Photos']).isRequired,
   *
   *       // A prop named "dialog" that requires an instance of Dialog.
   *       dialog: Props.instanceOf(Dialog).isRequired
   *     },
   *     render: function() { ... }
   *   });
   *
   * A more formal specification of how these methods are used:
   *
   *   type := array|bool|func|object|number|string|oneOf([...])|instanceOf(...)
   *   decl := ReactPropTypes.{type}(.isRequired)?
   *
   * Each and every declaration produces a function with the same signature. This
   * allows the creation of custom validation functions. For example:
   *
   *  var MyLink = React.createClass({
   *    propTypes: {
   *      // An optional string or URI prop named "href".
   *      href: function(props, propName, componentName) {
   *        var propValue = props[propName];
   *        if (propValue != null && typeof propValue !== 'string' &&
   *            !(propValue instanceof URI)) {
   *          return new Error(
   *            'Expected a string or an URI for ' + propName + ' in ' +
   *            componentName
   *          );
   *        }
   *      }
   *    },
   *    render: function() {...}
   *  });
   *
   * @internal
   */

  var ANONYMOUS = '<<anonymous>>';

  // Important!
  // Keep this list in sync with production version in `./factoryWithThrowingShims.js`.
  var ReactPropTypes = {
    array: createPrimitiveTypeChecker('array'),
    bool: createPrimitiveTypeChecker('boolean'),
    func: createPrimitiveTypeChecker('function'),
    number: createPrimitiveTypeChecker('number'),
    object: createPrimitiveTypeChecker('object'),
    string: createPrimitiveTypeChecker('string'),
    symbol: createPrimitiveTypeChecker('symbol'),

    any: createAnyTypeChecker(),
    arrayOf: createArrayOfTypeChecker,
    element: createElementTypeChecker(),
    elementType: createElementTypeTypeChecker(),
    instanceOf: createInstanceTypeChecker,
    node: createNodeChecker(),
    objectOf: createObjectOfTypeChecker,
    oneOf: createEnumTypeChecker,
    oneOfType: createUnionTypeChecker,
    shape: createShapeTypeChecker,
    exact: createStrictShapeTypeChecker,
  };

  /**
   * inlined Object.is polyfill to avoid requiring consumers ship their own
   * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
   */
  /*eslint-disable no-self-compare*/
  function is(x, y) {
    // SameValue algorithm
    if (x === y) {
      // Steps 1-5, 7-10
      // Steps 6.b-6.e: +0 != -0
      return x !== 0 || 1 / x === 1 / y;
    } else {
      // Step 6.a: NaN == NaN
      return x !== x && y !== y;
    }
  }
  /*eslint-enable no-self-compare*/

  /**
   * We use an Error-like object for backward compatibility as people may call
   * PropTypes directly and inspect their output. However, we don't use real
   * Errors anymore. We don't inspect their stack anyway, and creating them
   * is prohibitively expensive if they are created too often, such as what
   * happens in oneOfType() for any type before the one that matched.
   */
  function PropTypeError(message) {
    this.message = message;
    this.stack = '';
  }
  // Make `instanceof Error` still work for returned errors.
  PropTypeError.prototype = Error.prototype;

  function createChainableTypeChecker(validate) {
    if (true) {
      var manualPropTypeCallCache = {};
      var manualPropTypeWarningCount = 0;
    }
    function checkType(isRequired, props, propName, componentName, location, propFullName, secret) {
      componentName = componentName || ANONYMOUS;
      propFullName = propFullName || propName;

      if (secret !== ReactPropTypesSecret) {
        if (throwOnDirectAccess) {
          // New behavior only for users of `prop-types` package
          var err = new Error(
            'Calling PropTypes validators directly is not supported by the `prop-types` package. ' +
            'Use `PropTypes.checkPropTypes()` to call them. ' +
            'Read more at http://fb.me/use-check-prop-types'
          );
          err.name = 'Invariant Violation';
          throw err;
        } else if ( true && typeof console !== 'undefined') {
          // Old behavior for people using React.PropTypes
          var cacheKey = componentName + ':' + propName;
          if (
            !manualPropTypeCallCache[cacheKey] &&
            // Avoid spamming the console because they are often not actionable except for lib authors
            manualPropTypeWarningCount < 3
          ) {
            printWarning(
              'You are manually calling a React.PropTypes validation ' +
              'function for the `' + propFullName + '` prop on `' + componentName  + '`. This is deprecated ' +
              'and will throw in the standalone `prop-types` package. ' +
              'You may be seeing this warning due to a third-party PropTypes ' +
              'library. See https://fb.me/react-warning-dont-call-proptypes ' + 'for details.'
            );
            manualPropTypeCallCache[cacheKey] = true;
            manualPropTypeWarningCount++;
          }
        }
      }
      if (props[propName] == null) {
        if (isRequired) {
          if (props[propName] === null) {
            return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required ' + ('in `' + componentName + '`, but its value is `null`.'));
          }
          return new PropTypeError('The ' + location + ' `' + propFullName + '` is marked as required in ' + ('`' + componentName + '`, but its value is `undefined`.'));
        }
        return null;
      } else {
        return validate(props, propName, componentName, location, propFullName);
      }
    }

    var chainedCheckType = checkType.bind(null, false);
    chainedCheckType.isRequired = checkType.bind(null, true);

    return chainedCheckType;
  }

  function createPrimitiveTypeChecker(expectedType) {
    function validate(props, propName, componentName, location, propFullName, secret) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== expectedType) {
        // `propValue` being instance of, say, date/regexp, pass the 'object'
        // check, but we can offer a more precise error message here rather than
        // 'of type `object`'.
        var preciseType = getPreciseType(propValue);

        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + preciseType + '` supplied to `' + componentName + '`, expected ') + ('`' + expectedType + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createAnyTypeChecker() {
    return createChainableTypeChecker(emptyFunctionThatReturnsNull);
  }

  function createArrayOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside arrayOf.');
      }
      var propValue = props[propName];
      if (!Array.isArray(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an array.'));
      }
      for (var i = 0; i < propValue.length; i++) {
        var error = typeChecker(propValue, i, componentName, location, propFullName + '[' + i + ']', ReactPropTypesSecret);
        if (error instanceof Error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!isValidElement(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createElementTypeTypeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      if (!ReactIs.isValidElementType(propValue)) {
        var propType = getPropType(propValue);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected a single ReactElement type.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createInstanceTypeChecker(expectedClass) {
    function validate(props, propName, componentName, location, propFullName) {
      if (!(props[propName] instanceof expectedClass)) {
        var expectedClassName = expectedClass.name || ANONYMOUS;
        var actualClassName = getClassName(props[propName]);
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + actualClassName + '` supplied to `' + componentName + '`, expected ') + ('instance of `' + expectedClassName + '`.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createEnumTypeChecker(expectedValues) {
    if (!Array.isArray(expectedValues)) {
      if (true) {
        if (arguments.length > 1) {
          printWarning(
            'Invalid arguments supplied to oneOf, expected an array, got ' + arguments.length + ' arguments. ' +
            'A common mistake is to write oneOf(x, y, z) instead of oneOf([x, y, z]).'
          );
        } else {
          printWarning('Invalid argument supplied to oneOf, expected an array.');
        }
      }
      return emptyFunctionThatReturnsNull;
    }

    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      for (var i = 0; i < expectedValues.length; i++) {
        if (is(propValue, expectedValues[i])) {
          return null;
        }
      }

      var valuesString = JSON.stringify(expectedValues, function replacer(key, value) {
        var type = getPreciseType(value);
        if (type === 'symbol') {
          return String(value);
        }
        return value;
      });
      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of value `' + String(propValue) + '` ' + ('supplied to `' + componentName + '`, expected one of ' + valuesString + '.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createObjectOfTypeChecker(typeChecker) {
    function validate(props, propName, componentName, location, propFullName) {
      if (typeof typeChecker !== 'function') {
        return new PropTypeError('Property `' + propFullName + '` of component `' + componentName + '` has invalid PropType notation inside objectOf.');
      }
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type ' + ('`' + propType + '` supplied to `' + componentName + '`, expected an object.'));
      }
      for (var key in propValue) {
        if (has(propValue, key)) {
          var error = typeChecker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
          if (error instanceof Error) {
            return error;
          }
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createUnionTypeChecker(arrayOfTypeCheckers) {
    if (!Array.isArray(arrayOfTypeCheckers)) {
       true ? printWarning('Invalid argument supplied to oneOfType, expected an instance of array.') : undefined;
      return emptyFunctionThatReturnsNull;
    }

    for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
      var checker = arrayOfTypeCheckers[i];
      if (typeof checker !== 'function') {
        printWarning(
          'Invalid argument supplied to oneOfType. Expected an array of check functions, but ' +
          'received ' + getPostfixForTypeWarning(checker) + ' at index ' + i + '.'
        );
        return emptyFunctionThatReturnsNull;
      }
    }

    function validate(props, propName, componentName, location, propFullName) {
      for (var i = 0; i < arrayOfTypeCheckers.length; i++) {
        var checker = arrayOfTypeCheckers[i];
        if (checker(props, propName, componentName, location, propFullName, ReactPropTypesSecret) == null) {
          return null;
        }
      }

      return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`.'));
    }
    return createChainableTypeChecker(validate);
  }

  function createNodeChecker() {
    function validate(props, propName, componentName, location, propFullName) {
      if (!isNode(props[propName])) {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` supplied to ' + ('`' + componentName + '`, expected a ReactNode.'));
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      for (var key in shapeTypes) {
        var checker = shapeTypes[key];
        if (!checker) {
          continue;
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }
    return createChainableTypeChecker(validate);
  }

  function createStrictShapeTypeChecker(shapeTypes) {
    function validate(props, propName, componentName, location, propFullName) {
      var propValue = props[propName];
      var propType = getPropType(propValue);
      if (propType !== 'object') {
        return new PropTypeError('Invalid ' + location + ' `' + propFullName + '` of type `' + propType + '` ' + ('supplied to `' + componentName + '`, expected `object`.'));
      }
      // We need to check all keys in case some are required but missing from
      // props.
      var allKeys = assign({}, props[propName], shapeTypes);
      for (var key in allKeys) {
        var checker = shapeTypes[key];
        if (!checker) {
          return new PropTypeError(
            'Invalid ' + location + ' `' + propFullName + '` key `' + key + '` supplied to `' + componentName + '`.' +
            '\nBad object: ' + JSON.stringify(props[propName], null, '  ') +
            '\nValid keys: ' +  JSON.stringify(Object.keys(shapeTypes), null, '  ')
          );
        }
        var error = checker(propValue, key, componentName, location, propFullName + '.' + key, ReactPropTypesSecret);
        if (error) {
          return error;
        }
      }
      return null;
    }

    return createChainableTypeChecker(validate);
  }

  function isNode(propValue) {
    switch (typeof propValue) {
      case 'number':
      case 'string':
      case 'undefined':
        return true;
      case 'boolean':
        return !propValue;
      case 'object':
        if (Array.isArray(propValue)) {
          return propValue.every(isNode);
        }
        if (propValue === null || isValidElement(propValue)) {
          return true;
        }

        var iteratorFn = getIteratorFn(propValue);
        if (iteratorFn) {
          var iterator = iteratorFn.call(propValue);
          var step;
          if (iteratorFn !== propValue.entries) {
            while (!(step = iterator.next()).done) {
              if (!isNode(step.value)) {
                return false;
              }
            }
          } else {
            // Iterator will provide entry [k,v] tuples rather than values.
            while (!(step = iterator.next()).done) {
              var entry = step.value;
              if (entry) {
                if (!isNode(entry[1])) {
                  return false;
                }
              }
            }
          }
        } else {
          return false;
        }

        return true;
      default:
        return false;
    }
  }

  function isSymbol(propType, propValue) {
    // Native Symbol.
    if (propType === 'symbol') {
      return true;
    }

    // falsy value can't be a Symbol
    if (!propValue) {
      return false;
    }

    // 19.4.3.5 Symbol.prototype[@@toStringTag] === 'Symbol'
    if (propValue['@@toStringTag'] === 'Symbol') {
      return true;
    }

    // Fallback for non-spec compliant Symbols which are polyfilled.
    if (typeof Symbol === 'function' && propValue instanceof Symbol) {
      return true;
    }

    return false;
  }

  // Equivalent of `typeof` but with special handling for array and regexp.
  function getPropType(propValue) {
    var propType = typeof propValue;
    if (Array.isArray(propValue)) {
      return 'array';
    }
    if (propValue instanceof RegExp) {
      // Old webkits (at least until Android 4.0) return 'function' rather than
      // 'object' for typeof a RegExp. We'll normalize this here so that /bla/
      // passes PropTypes.object.
      return 'object';
    }
    if (isSymbol(propType, propValue)) {
      return 'symbol';
    }
    return propType;
  }

  // This handles more types than `getPropType`. Only used for error messages.
  // See `createPrimitiveTypeChecker`.
  function getPreciseType(propValue) {
    if (typeof propValue === 'undefined' || propValue === null) {
      return '' + propValue;
    }
    var propType = getPropType(propValue);
    if (propType === 'object') {
      if (propValue instanceof Date) {
        return 'date';
      } else if (propValue instanceof RegExp) {
        return 'regexp';
      }
    }
    return propType;
  }

  // Returns a string that is postfixed to a warning about an invalid type.
  // For example, "undefined" or "of type array"
  function getPostfixForTypeWarning(value) {
    var type = getPreciseType(value);
    switch (type) {
      case 'array':
      case 'object':
        return 'an ' + type;
      case 'boolean':
      case 'date':
      case 'regexp':
        return 'a ' + type;
      default:
        return type;
    }
  }

  // Returns class name of the object, if any.
  function getClassName(propValue) {
    if (!propValue.constructor || !propValue.constructor.name) {
      return ANONYMOUS;
    }
    return propValue.constructor.name;
  }

  ReactPropTypes.checkPropTypes = checkPropTypes;
  ReactPropTypes.resetWarningCache = checkPropTypes.resetWarningCache;
  ReactPropTypes.PropTypes = ReactPropTypes;

  return ReactPropTypes;
};


/***/ }),

/***/ "./node_modules/prop-types/index.js":
/*!******************************************!*\
  !*** ./node_modules/prop-types/index.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

if (true) {
  var ReactIs = __webpack_require__(/*! react-is */ "./node_modules/react-is/index.js");

  // By explicitly using `prop-types` you are opting into new development behavior.
  // http://fb.me/prop-types-in-prod
  var throwOnDirectAccess = true;
  module.exports = __webpack_require__(/*! ./factoryWithTypeCheckers */ "./node_modules/prop-types/factoryWithTypeCheckers.js")(ReactIs.isElement, throwOnDirectAccess);
} else {}


/***/ }),

/***/ "./node_modules/prop-types/lib/ReactPropTypesSecret.js":
/*!*************************************************************!*\
  !*** ./node_modules/prop-types/lib/ReactPropTypesSecret.js ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/**
 * Copyright (c) 2013-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */



var ReactPropTypesSecret = 'SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED';

module.exports = ReactPropTypesSecret;


/***/ }),

/***/ "./node_modules/react-is/cjs/react-is.development.js":
/*!***********************************************************!*\
  !*** ./node_modules/react-is/cjs/react-is.development.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/** @license React v16.13.1
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */





if (true) {
  (function() {
'use strict';

// The Symbol used to tag the ReactElement-like types. If there is no native Symbol
// nor polyfill, then a plain number is used for performance.
var hasSymbol = typeof Symbol === 'function' && Symbol.for;
var REACT_ELEMENT_TYPE = hasSymbol ? Symbol.for('react.element') : 0xeac7;
var REACT_PORTAL_TYPE = hasSymbol ? Symbol.for('react.portal') : 0xeaca;
var REACT_FRAGMENT_TYPE = hasSymbol ? Symbol.for('react.fragment') : 0xeacb;
var REACT_STRICT_MODE_TYPE = hasSymbol ? Symbol.for('react.strict_mode') : 0xeacc;
var REACT_PROFILER_TYPE = hasSymbol ? Symbol.for('react.profiler') : 0xead2;
var REACT_PROVIDER_TYPE = hasSymbol ? Symbol.for('react.provider') : 0xeacd;
var REACT_CONTEXT_TYPE = hasSymbol ? Symbol.for('react.context') : 0xeace; // TODO: We don't use AsyncMode or ConcurrentMode anymore. They were temporary
// (unstable) APIs that have been removed. Can we remove the symbols?

var REACT_ASYNC_MODE_TYPE = hasSymbol ? Symbol.for('react.async_mode') : 0xeacf;
var REACT_CONCURRENT_MODE_TYPE = hasSymbol ? Symbol.for('react.concurrent_mode') : 0xeacf;
var REACT_FORWARD_REF_TYPE = hasSymbol ? Symbol.for('react.forward_ref') : 0xead0;
var REACT_SUSPENSE_TYPE = hasSymbol ? Symbol.for('react.suspense') : 0xead1;
var REACT_SUSPENSE_LIST_TYPE = hasSymbol ? Symbol.for('react.suspense_list') : 0xead8;
var REACT_MEMO_TYPE = hasSymbol ? Symbol.for('react.memo') : 0xead3;
var REACT_LAZY_TYPE = hasSymbol ? Symbol.for('react.lazy') : 0xead4;
var REACT_BLOCK_TYPE = hasSymbol ? Symbol.for('react.block') : 0xead9;
var REACT_FUNDAMENTAL_TYPE = hasSymbol ? Symbol.for('react.fundamental') : 0xead5;
var REACT_RESPONDER_TYPE = hasSymbol ? Symbol.for('react.responder') : 0xead6;
var REACT_SCOPE_TYPE = hasSymbol ? Symbol.for('react.scope') : 0xead7;

function isValidElementType(type) {
  return typeof type === 'string' || typeof type === 'function' || // Note: its typeof might be other than 'symbol' or 'number' if it's a polyfill.
  type === REACT_FRAGMENT_TYPE || type === REACT_CONCURRENT_MODE_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || typeof type === 'object' && type !== null && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_PROVIDER_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_FUNDAMENTAL_TYPE || type.$$typeof === REACT_RESPONDER_TYPE || type.$$typeof === REACT_SCOPE_TYPE || type.$$typeof === REACT_BLOCK_TYPE);
}

function typeOf(object) {
  if (typeof object === 'object' && object !== null) {
    var $$typeof = object.$$typeof;

    switch ($$typeof) {
      case REACT_ELEMENT_TYPE:
        var type = object.type;

        switch (type) {
          case REACT_ASYNC_MODE_TYPE:
          case REACT_CONCURRENT_MODE_TYPE:
          case REACT_FRAGMENT_TYPE:
          case REACT_PROFILER_TYPE:
          case REACT_STRICT_MODE_TYPE:
          case REACT_SUSPENSE_TYPE:
            return type;

          default:
            var $$typeofType = type && type.$$typeof;

            switch ($$typeofType) {
              case REACT_CONTEXT_TYPE:
              case REACT_FORWARD_REF_TYPE:
              case REACT_LAZY_TYPE:
              case REACT_MEMO_TYPE:
              case REACT_PROVIDER_TYPE:
                return $$typeofType;

              default:
                return $$typeof;
            }

        }

      case REACT_PORTAL_TYPE:
        return $$typeof;
    }
  }

  return undefined;
} // AsyncMode is deprecated along with isAsyncMode

var AsyncMode = REACT_ASYNC_MODE_TYPE;
var ConcurrentMode = REACT_CONCURRENT_MODE_TYPE;
var ContextConsumer = REACT_CONTEXT_TYPE;
var ContextProvider = REACT_PROVIDER_TYPE;
var Element = REACT_ELEMENT_TYPE;
var ForwardRef = REACT_FORWARD_REF_TYPE;
var Fragment = REACT_FRAGMENT_TYPE;
var Lazy = REACT_LAZY_TYPE;
var Memo = REACT_MEMO_TYPE;
var Portal = REACT_PORTAL_TYPE;
var Profiler = REACT_PROFILER_TYPE;
var StrictMode = REACT_STRICT_MODE_TYPE;
var Suspense = REACT_SUSPENSE_TYPE;
var hasWarnedAboutDeprecatedIsAsyncMode = false; // AsyncMode should be deprecated

function isAsyncMode(object) {
  {
    if (!hasWarnedAboutDeprecatedIsAsyncMode) {
      hasWarnedAboutDeprecatedIsAsyncMode = true; // Using console['warn'] to evade Babel and ESLint

      console['warn']('The ReactIs.isAsyncMode() alias has been deprecated, ' + 'and will be removed in React 17+. Update your code to use ' + 'ReactIs.isConcurrentMode() instead. It has the exact same API.');
    }
  }

  return isConcurrentMode(object) || typeOf(object) === REACT_ASYNC_MODE_TYPE;
}
function isConcurrentMode(object) {
  return typeOf(object) === REACT_CONCURRENT_MODE_TYPE;
}
function isContextConsumer(object) {
  return typeOf(object) === REACT_CONTEXT_TYPE;
}
function isContextProvider(object) {
  return typeOf(object) === REACT_PROVIDER_TYPE;
}
function isElement(object) {
  return typeof object === 'object' && object !== null && object.$$typeof === REACT_ELEMENT_TYPE;
}
function isForwardRef(object) {
  return typeOf(object) === REACT_FORWARD_REF_TYPE;
}
function isFragment(object) {
  return typeOf(object) === REACT_FRAGMENT_TYPE;
}
function isLazy(object) {
  return typeOf(object) === REACT_LAZY_TYPE;
}
function isMemo(object) {
  return typeOf(object) === REACT_MEMO_TYPE;
}
function isPortal(object) {
  return typeOf(object) === REACT_PORTAL_TYPE;
}
function isProfiler(object) {
  return typeOf(object) === REACT_PROFILER_TYPE;
}
function isStrictMode(object) {
  return typeOf(object) === REACT_STRICT_MODE_TYPE;
}
function isSuspense(object) {
  return typeOf(object) === REACT_SUSPENSE_TYPE;
}

exports.AsyncMode = AsyncMode;
exports.ConcurrentMode = ConcurrentMode;
exports.ContextConsumer = ContextConsumer;
exports.ContextProvider = ContextProvider;
exports.Element = Element;
exports.ForwardRef = ForwardRef;
exports.Fragment = Fragment;
exports.Lazy = Lazy;
exports.Memo = Memo;
exports.Portal = Portal;
exports.Profiler = Profiler;
exports.StrictMode = StrictMode;
exports.Suspense = Suspense;
exports.isAsyncMode = isAsyncMode;
exports.isConcurrentMode = isConcurrentMode;
exports.isContextConsumer = isContextConsumer;
exports.isContextProvider = isContextProvider;
exports.isElement = isElement;
exports.isForwardRef = isForwardRef;
exports.isFragment = isFragment;
exports.isLazy = isLazy;
exports.isMemo = isMemo;
exports.isPortal = isPortal;
exports.isProfiler = isProfiler;
exports.isStrictMode = isStrictMode;
exports.isSuspense = isSuspense;
exports.isValidElementType = isValidElementType;
exports.typeOf = typeOf;
  })();
}


/***/ }),

/***/ "./node_modules/react-is/index.js":
/*!****************************************!*\
  !*** ./node_modules/react-is/index.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


if (false) {} else {
  module.exports = __webpack_require__(/*! ./cjs/react-is.development.js */ "./node_modules/react-is/cjs/react-is.development.js");
}


/***/ }),

/***/ "@wordpress/block-editor":
/*!**********************************************!*\
  !*** external {"this":["wp","blockEditor"]} ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["blockEditor"]; }());

/***/ }),

/***/ "@wordpress/components":
/*!*********************************************!*\
  !*** external {"this":["wp","components"]} ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["components"]; }());

/***/ }),

/***/ "@wordpress/compose":
/*!******************************************!*\
  !*** external {"this":["wp","compose"]} ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["compose"]; }());

/***/ }),

/***/ "@wordpress/data":
/*!***************************************!*\
  !*** external {"this":["wp","data"]} ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["data"]; }());

/***/ }),

/***/ "@wordpress/element":
/*!******************************************!*\
  !*** external {"this":["wp","element"]} ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["element"]; }());

/***/ }),

/***/ "@wordpress/hooks":
/*!****************************************!*\
  !*** external {"this":["wp","hooks"]} ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["hooks"]; }());

/***/ }),

/***/ "@wordpress/i18n":
/*!***************************************!*\
  !*** external {"this":["wp","i18n"]} ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["i18n"]; }());

/***/ }),

/***/ "lodash":
/*!**********************************!*\
  !*** external {"this":"lodash"} ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["lodash"]; }());

/***/ }),

/***/ "react":
/*!*********************************!*\
  !*** external {"this":"React"} ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["React"]; }());

/***/ })

/******/ });
//# sourceMappingURL=amp-block-validation.js.map