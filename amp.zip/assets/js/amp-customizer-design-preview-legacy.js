/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./assets/src/customizer/amp-customizer-design-preview-legacy.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./assets/src/customizer/amp-customizer-design-preview-legacy.js":
/*!***********************************************************************!*\
  !*** ./assets/src/customizer/amp-customizer-design-preview-legacy.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* global amp_customizer_design, jQuery */
// Note: This is only used in Legacy Reader mode.
(function ($) {
  'use strict'; // Nav bar text color.

  wp.customize('amp_customizer[header_color]', function (value) {
    value.bind(function (to) {
      $('.amp-wp-header a').css('color', to);
      $('.amp-wp-header div').css('color', to);
      $('.amp-wp-header .amp-wp-site-icon').css('border-color', to).css('background-color', to);
    });
  }); // Nav bar background color.

  wp.customize('amp_customizer[header_background_color]', function (value) {
    value.bind(function (to) {
      $('html, .amp-wp-header').css('background-color', to);
      $('.amp-wp-article a, .amp-wp-article a:visited, .amp-wp-footer a, .amp-wp-footer a:visited').css('color', to);
      $('blockquote, .amp-wp-byline amp-img').css('border-color', to);
    });
  }); // AMP background color scheme.

  wp.customize('amp_customizer[color_scheme]', function (value) {
    value.bind(function (to) {
      var colors = amp_customizer_design.color_schemes[to]; // eslint-disable-line no-var

      if (!colors) {
        console.error('Selected color scheme "%s" not registered.', to); // eslint-disable-line no-console

        return;
      }

      $('body').css('background-color', colors.theme_color);
      $('body, a:hover, a:active, a:focus, blockquote, .amp-wp-article, .amp-wp-title').css('color', colors.text_color);
      $('.amp-wp-meta, .wp-caption .wp-caption-text, .amp-wp-tax-category, .amp-wp-tax-tag, .amp-wp-footer p').css('color', colors.muted_text_color);
      $('.wp-caption .wp-caption-text, .amp-wp-comments-link a, .amp-wp-footer').css('border-color', colors.border_color);
      $('.amp-wp-iframe-placeholder, amp-carousel, amp-iframe, amp-youtube, amp-instagram, amp-vine').css('background-color', colors.border_color);
    });
  }); // Site title.

  wp.customize('blogname', function (setting) {
    setting.bind(function (title) {
      $('.amp-wp-header .amp-site-title, .amp-wp-footer h2').text(title);
    });
  });
})(jQuery);

/***/ })

/******/ });
//# sourceMappingURL=amp-customizer-design-preview-legacy.js.map