/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./assets/src/customizer/amp-customize-controls.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./assets/src/customizer/amp-customize-controls.js":
/*!*********************************************************!*\
  !*** ./assets/src/customizer/amp-customize-controls.js ***!
  \*********************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "./node_modules/@babel/runtime/helpers/slicedToArray.js");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);


function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/* global jQuery */

/**
 * External dependencies
 */

/**
 * WordPress dependencies
 */



window.ampCustomizeControls = function (api, $) {
  'use strict';

  var component = {
    nonAmpCustomizerLink: null,
    data: {
      queryVar: '',
      l10n: {
        ampVersionNotice: '',
        rootPanelDescription: ''
      },
      optionSettings: [],
      activeThemeSettingImports: {},
      mimeTypeIcons: {
        image: '',
        document: ''
      }
    }
  };
  /**
   * Boot using data sent inline.
   *
   * @param {Object} data Object data.
   * @return {void}
   */

  component.boot = function boot(data) {
    component.data = data;
    component.updatePreviewNotice();
    component.extendRootDescription();
    $.ajaxPrefilter(component.injectAmpIntoAjaxRequests);
    api.bind('ready', component.updateNonAmpCustomizeLink);
    api.bind('ready', component.forceAmpPreviewUrl);
    api.bind('ready', component.addOptionSettingNotices);
    api.bind('ready', component.addNavMenuPanelNotice);
    api.bind('ready', component.addActiveThemeSettingsImporting);
  };
  /**
   * Update preview notice.
   */


  component.updatePreviewNotice = function updatePreviewNotice() {
    var previewNotice = $('#customize-info .preview-notice');
    previewNotice.html(component.data.l10n.ampVersionNotice); // Contents have been sanitized with wp_kses_post().

    component.nonAmpCustomizerLink = previewNotice.find('a[href]')[0];
  };
  /**
   * Make sure the non-AMP Customizer link keeps referencing to the currently-previewed URL.
   */


  component.updateNonAmpCustomizeLink = function updateNonAmpCustomizeLink() {
    if (!(component.nonAmpCustomizerLink instanceof HTMLAnchorElement)) {
      return;
    }

    var update = function update() {
      var previewUrl = new URL(api.previewer.previewUrl());
      previewUrl.searchParams.delete(component.data.queryVar);
      var customizeUrl = new URL(component.nonAmpCustomizerLink.href);
      customizeUrl.searchParams.set('url', previewUrl);
      component.nonAmpCustomizerLink.href = customizeUrl.href;
    };

    update();
    api.previewer.previewUrl.bind(update);
  };
  /**
   * Add AMP-specific info to the root panel description.
   */


  component.extendRootDescription = function extendRootDescription() {
    var panelDescription = $('#customize-info .customize-panel-description'); // Ensure the original description is in a paragraph (where normally it is not).

    if (panelDescription.find('p').length === 0) {
      var originalParagraph = $('<p></p>');
      originalParagraph.html(panelDescription.html());
      panelDescription.html('');
      panelDescription.append(originalParagraph);
    }

    var ampDescription = $('<p>' + component.data.l10n.rootPanelDescription + '</p>'); // Contents have been sanitized with wp_kses_post().

    panelDescription.append(ampDescription);
  };
  /**
   * i18n friendly version of basename()
   *
   * This is a port of wp_basename() in PHP.
   *
   * @param {string} path Path.
   * @return {string} Basename.
   */


  function wpBasename(path) {
    return decodeURIComponent(encodeURIComponent(path).replace(/%(2F|5C)/g, '/').replace(/^.*\//, ''));
  }
  /**
   * Ensure UploadControl is updated when underlying setting is programmatically updated (not using media library).
   *
   * The newer MediaControl does update programmatically when the setting changes, so the control for the newer
   * Custom Logo will update their UI to show the image. Older controls like the Background Image will not however.
   *
   * @param {wp.customize.UploadControl} control
   * @param {Function} control.extended
   */


  function populateUploadControl(control) {
    var value = control.setting();

    if (!value || control.params.attachment && control.params.attachment.url === value) {
      return;
    }

    var url = new URL(value); // The following replicates PHP logic in WP_Customize_Media_Control::to_json().

    var type = ['jpg', 'png', 'gif', 'bmp'].includes(url.pathname.substr(-3)) ? 'image' : 'document';
    var attachment = {
      id: 1,
      url: url.href,
      type: type,
      icon: component.data.mimeTypeIcons[type],
      title: wpBasename(url.pathname)
    };

    if ('image' === type) {
      attachment.sizes = {
        full: {
          url: url.href
        }
      };
    } // Make sure that the media frame is populated with the attachment.


    if (!control.frame) {
      control.initFrame();
    }

    if (!control.frame.state()) {
      control.frame.setState('library');
    }

    control.frame.state().get('selection').set([attachment]); // Call the select method so that the attachment param is updated.

    if (control.extended(api.BackgroundControl)) {
      // Explicitly do not call BackgroundControl#select() because it sends an unnecessary custom-background-add ajax request.
      api.UploadControl.prototype.select.call(control);
    } else {
      control.select();
    } // Finally, render the control.


    control.renderContent();
  }
  /**
   * Ensure HeaderControl is updated when underlying setting is programmatically updated (not using media library).
   *
   * The newer MediaControl does update programmatically when the setting changes, so the control for the newer
   * Custom Logo will update their UI to show the image. Older controls like the Header Image will not however.
   *
   * @param {wp.customize.HeaderControl} control
   */


  function populateHeaderControl(control) {
    var headerImagedData = api('header_image_data').get();

    if (headerImagedData) {
      control.setImageFromURL(headerImagedData.url, headerImagedData.attachment_id, headerImagedData.width, headerImagedData.height);
    }
  }
  /**
   * Controls which are dependent on the background_image being set.
   *
   * @type {string[]}
   */


  var backgroundImageDependentControls = ['background_position', 'background_size', 'background_repeat', 'background_attachment'];
  /**
   * Mapping of control ID to the setting value which indicates the checkbox should be unchecked.
   *
   * @type {Object}
   */

  var checkboxControlElementValueMapping = {
    display_header_text: 'blank',
    background_attachment: 'fixed',
    background_repeat: 'no-repeat'
  };
  /**
   * Handle special case of updating certain checkbox controls.
   *
   * Because of some "juggling" in WordPress core, programmatically updating the value (probably related to double
   * data binding of Element and Setting values) is not feasible. It is instead updated by directly manipulating the Element instance
   * as opposed to the underlying Setting that it syncs with.
   *
   * @param {wp.customize.Control} control Control.
   * @see https://github.com/WordPress/wordpress-develop/blob/5.4.2/src/js/_enqueues/wp/customize/controls.js#L8943-L9050
   */

  function populateCheckboxControlWithSyncedElement(control) {
    if (control.id in checkboxControlElementValueMapping && 'element' in control && control.setting.id in component.data.activeThemeSettingImports) {
      control.element.set(checkboxControlElementValueMapping[control.id] !== component.data.activeThemeSettingImports[control.setting.id]);
    }
  }
  /**
   * Mapping of control ID to additional related settings.
   *
   * @type {Object}
   */


  var controlRelatedSettings = {
    accent_hue_active: ['accent_hue']
  };
  /**
   * Populate settings which are related to controls but not directly link.
   *
   * A good example of such a control is the accent_hue setting which is linked to a hue control. The hue control
   * lacks a label so it is not listed among the importable settings. However, when the Primary Color control is set
   * to "Custom" then the hue control is displayed.
   *
   * @param {wp.customize.Control} control
   */

  function populateRelatedSettings(control) {
    if (control.id in controlRelatedSettings) {
      var settings = [];

      var _iterator = _createForOfIteratorHelper(controlRelatedSettings[control.id]),
          _step;

      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var settingId = _step.value;
          var setting = api(settingId);

          if (setting) {
            settings.push(setting);
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }

      importSettings(settings);
    }
  }
  /**
   * Import settings if available.
   *
   * @param {wp.customize.Setting[]} settings Settings collection.
   */


  function importSettings(settings) {
    var _iterator2 = _createForOfIteratorHelper(settings),
        _step2;

    try {
      for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
        var setting = _step2.value;

        if (setting.id in component.data.activeThemeSettingImports) {
          setting.set(component.data.activeThemeSettingImports[setting.id]);
        }
      }
    } catch (err) {
      _iterator2.e(err);
    } finally {
      _iterator2.f();
    }
  }
  /**
   * Import settings for a control.
   *
   * @param {wp.customize.Control} control Control.
   * @param {Function} control.extended Control.
   */


  function importControlSettings(control) {
    // Ensure all background settings are shown by ensuring custom preset is selected.
    if (backgroundImageDependentControls.includes(control.id)) {
      var backgroundPreset = api('background_preset');

      if (backgroundPreset) {
        backgroundPreset.set('custom');
      }
    }

    if (control.id in checkboxControlElementValueMapping) {
      populateCheckboxControlWithSyncedElement(control);
    } else {
      importSettings(Object.values(control.settings));
    }

    populateRelatedSettings(control); // Manually update the UI for controls that don't react to programmatic setting updates.

    if (control.extended(api.UploadControl)) {
      populateUploadControl(
      /** @type {wp.customize.UploadControl} */
      control);
    } else if (control.extended(api.HeaderControl)) {
      populateHeaderControl(
      /** @type {wp.customize.HeaderControl} */
      control);
    }
  }
  /**
   * Section to contain the active theme settings import functionality.
   *
   * This section is somewhat of a hack in that it has contentContainer and it cannot expand. It has no controls.
   * It is implemented as a section so that it will be rendered in the root Customizer panel in the same way that
   * the Themes panel is.
   *
   * @class    AmpActiveThemeSettingsImportSection
   * @augments wp.customize.Section
   */


  var AmpActiveThemeSettingsImportSection = api.Section.extend({
    /**
     * Force section to be contextually active.
     *
     * This overrides the section's normal method to force the section to be active since normally the section
     * becomes deactivated if it has no controls or none of the controls are active.
     *
     * @return {boolean} Active.
     */
    isContextuallyActive: function isContextuallyActive() {
      return true;
    },

    /**
     * Override the expand method to prevent the section from being erroneously expanded.
     */
    expand: function expand() {},

    /**
     * Get all sections other than this one, sorted by priority.
     *
     * @return {wp.customize.Section[]} Other sections.
     */
    otherSections: function otherSections() {
      var _this = this;

      var sections = [];
      api.section.each(function (otherSection) {
        if (otherSection.id !== _this.id) {
          sections.push(otherSection);
        }
      });
      sections.sort(function (a, b) {
        return a.priority() - b.priority();
      });
      return sections;
    },

    /**
     * Render details.
     */
    renderDetails: function renderDetails() {
      var dl = this.headContainer.find('dl');

      var _iterator3 = _createForOfIteratorHelper(this.otherSections()),
          _step3;

      try {
        for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
          var otherSection = _step3.value;
          var sectionControls = [];

          var _iterator4 = _createForOfIteratorHelper(otherSection.controls()),
              _step4;

          try {
            for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
              var _control = _step4.value;

              if (this.params.controls.has(_control)) {
                sectionControls.push(_control);
              }
            }
          } catch (err) {
            _iterator4.e(err);
          } finally {
            _iterator4.f();
          }

          if (!sectionControls.length) {
            continue;
          }

          var title = void 0;

          switch (otherSection.id) {
            case 'menu_locations':
              title = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('Menu Locations', 'amp');
              break;

            default:
              title = otherSection.params.title;
          }

          var dt = $('<dt></dt>');
          dt.text(title);
          dl.append(dt);

          for (var _i = 0, _sectionControls = sectionControls; _i < _sectionControls.length; _i++) {
            var control = _sectionControls[_i];
            var dd = $('<dd></dd>');
            var id = "amp-import-".concat(control.id);
            var checkbox = $('<input type=checkbox checked>');
            checkbox.attr('id', id);
            checkbox.val(control.id);
            var label = $('<label></label>');
            label.attr('for', id);
            label.html(control.params.label);
            dd.append(checkbox);
            dd.append(label);
            dl.append(dd);
          }
        }
      } catch (err) {
        _iterator3.e(err);
      } finally {
        _iterator3.f();
      }
    },

    /**
     * Attach events.
     *
     * Override the parent class's normal events from being added to instead add the relevant event for the special section.
     */
    attachEvents: function attachEvents() {
      var _this2 = this;

      this.headContainer.find('button').on('click', function () {
        _this2.importSelectedSettings();
      });
    },

    /**
     * Import the selected settings.
     */
    importSelectedSettings: function importSelectedSettings() {
      var importSection = this;
      var remainingCheckboxes = 0;
      importSection.headContainer.find('input[type=checkbox]').each(function () {
        var checkbox = $(this);

        if (!checkbox.prop('checked')) {
          remainingCheckboxes++;
          return;
        }

        var control = api.control(checkbox.val());
        importControlSettings(control);
        checkbox.closest('dd').remove();
      }); // Remove any childless dt's.

      importSection.headContainer.find('dt').each(function () {
        var dt = $(this);

        if (!dt.next('dd').length) {
          dt.remove();
        }
      });

      if (0 === remainingCheckboxes) {
        importSection.active(false);
      }
    },

    /**
     * Set up the UI for the section.
     */
    ready: function ready() {
      api.Section.prototype.ready.call(this);
      this.renderDetails();
    }
  });
  api.sectionConstructor.amp_active_theme_settings_import = AmpActiveThemeSettingsImportSection;
  /**
   * Add ability to import settings from the active theme.
   */

  component.addActiveThemeSettingsImporting = function addActiveThemeSettingsImporting() {
    var differingSettings = new Set();

    for (var _i2 = 0, _Object$entries = Object.entries(component.data.activeThemeSettingImports); _i2 < _Object$entries.length; _i2++) {
      var _Object$entries$_i = _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default()(_Object$entries[_i2], 2),
          settingId = _Object$entries$_i[0],
          settingValue = _Object$entries$_i[1];

      var setting = api(settingId);

      if (setting && !Object(lodash__WEBPACK_IMPORTED_MODULE_1__["isEqual"])(setting(), settingValue)) {
        differingSettings.add(settingId);
      }
    } // Abort adding any UI if there are no settings to import.


    if (differingSettings.size === 0) {
      return;
    }

    var controlsWithSettings = new Set();
    api.control.each(function (control) {
      for (var _i3 = 0, _Object$values = Object.values(control.settings); _i3 < _Object$values.length; _i3++) {
        var _setting = _Object$values[_i3];

        if (!control.params.label) {
          continue;
        }

        if (differingSettings.has(_setting.id) || control.id in controlRelatedSettings && controlRelatedSettings[control.id].find(function (settingId) {
          return differingSettings.has(settingId);
        })) {
          controlsWithSettings.add(control);
        }
      }
    }); // In the very rare chance that there are settings without controls, abort.

    if (controlsWithSettings.size === 0) {
      return;
    }

    var section = new AmpActiveThemeSettingsImportSection('amp_settings_import', {
      title: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('Primary Theme Settings', 'amp'),
      priority: -1,
      controls: controlsWithSettings
    });
    api.section.add(section);
  };
  /**
   * Rewrite Ajax requests to inject AMP query var.
   *
   * @param {Object} options Options.
   * @param {string} options.type Type.
   * @param {string} options.url URL.
   * @return {void}
   */


  component.injectAmpIntoAjaxRequests = function injectAmpIntoAjaxRequests(options) {
    var url = new URL(options.url, window.location.href);

    if (!url.searchParams.has(component.data.queryVar)) {
      url.searchParams.append(component.data.queryVar, '1');
      options.url = url.href;
    }
  };
  /**
   * Persist the presence the amp=1 param when navigating in the preview, even if current page is not yet supported.
   */


  component.forceAmpPreviewUrl = function forceAmpPreviewUrl() {
    api.previewer.previewUrl.validate = function (prevValidate) {
      return function (value) {
        var val = prevValidate.call(this, value);

        if (val) {
          var url = new URL(val);

          if (!url.searchParams.has(component.data.queryVar)) {
            url.searchParams.append(component.data.queryVar, '1');
            val = url.href;
          }
        }

        return val;
      };
    }(api.previewer.previewUrl.validate);
  };
  /**
   * Add notice to all settings for options.
   */


  component.addOptionSettingNotices = function addOptionSettingNotices() {
    var _iterator5 = _createForOfIteratorHelper(component.data.optionSettings),
        _step5;

    try {
      for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
        var settingId = _step5.value;
        api(settingId, function (setting) {
          var notification = new api.Notification('amp_option_setting', {
            type: 'info',
            message: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('Also applies to non-AMP version of your site.', 'amp')
          });
          setting.notifications.add(notification.code, notification);
        });
      }
    } catch (err) {
      _iterator5.e(err);
    } finally {
      _iterator5.f();
    }
  };
  /**
   * Add notice to the nav menus panel.
   */


  component.addNavMenuPanelNotice = function addNavMenuPanelNotice() {
    api.panel('nav_menus', function (panel) {
      // Fix bug in WP where the Nav Menus panel lacks a notifications container.
      if (!panel.notifications.container.length) {
        panel.notifications.container = $('<div class="customize-control-notifications-container"></div>');
        panel.container.find('.panel-meta:first').append(panel.notifications.container);
      }

      var notification = new api.Notification('amp_version', {
        type: 'info',
        message: Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('The menus here are shared with the non-AMP version of your site. Assign existing menus to menu locations in the Reader theme or create new AMP-specific menus.', 'amp')
      });
      panel.notifications.add(notification.code, notification);
    });
  };

  return component;
}(wp.customize, jQuery);

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayLikeToArray.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

module.exports = _arrayLikeToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayWithHoles.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayWithHoles.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}

module.exports = _arrayWithHoles;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/iterableToArrayLimit.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/iterableToArrayLimit.js ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _iterableToArrayLimit(arr, i) {
  if (typeof Symbol === "undefined" || !(Symbol.iterator in Object(arr))) return;
  var _arr = [];
  var _n = true;
  var _d = false;
  var _e = undefined;

  try {
    for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) {
      _arr.push(_s.value);

      if (i && _arr.length === i) break;
    }
  } catch (err) {
    _d = true;
    _e = err;
  } finally {
    try {
      if (!_n && _i["return"] != null) _i["return"]();
    } finally {
      if (_d) throw _e;
    }
  }

  return _arr;
}

module.exports = _iterableToArrayLimit;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/nonIterableRest.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/nonIterableRest.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _nonIterableRest() {
  throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

module.exports = _nonIterableRest;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/slicedToArray.js":
/*!**************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/slicedToArray.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithHoles = __webpack_require__(/*! ./arrayWithHoles */ "./node_modules/@babel/runtime/helpers/arrayWithHoles.js");

var iterableToArrayLimit = __webpack_require__(/*! ./iterableToArrayLimit */ "./node_modules/@babel/runtime/helpers/iterableToArrayLimit.js");

var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray */ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");

var nonIterableRest = __webpack_require__(/*! ./nonIterableRest */ "./node_modules/@babel/runtime/helpers/nonIterableRest.js");

function _slicedToArray(arr, i) {
  return arrayWithHoles(arr) || iterableToArrayLimit(arr, i) || unsupportedIterableToArray(arr, i) || nonIterableRest();
}

module.exports = _slicedToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return arrayLikeToArray(o, minLen);
}

module.exports = _unsupportedIterableToArray;

/***/ }),

/***/ "@wordpress/i18n":
/*!***************************************!*\
  !*** external {"this":["wp","i18n"]} ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["i18n"]; }());

/***/ }),

/***/ "lodash":
/*!**********************************!*\
  !*** external {"this":"lodash"} ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["lodash"]; }());

/***/ })

/******/ });
//# sourceMappingURL=amp-customize-controls.js.map