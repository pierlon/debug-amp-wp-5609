/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./assets/src/amp-validation/amp-validated-url-post-edit-screen.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./assets/src/amp-validation/amp-validated-url-post-edit-screen.js":
/*!*************************************************************************!*\
  !*** ./assets/src/amp-validation/amp-validated-url-post-edit-screen.js ***!
  \*************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(global) {/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _wordpress_dom_ready__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @wordpress/dom-ready */ "@wordpress/dom-ready");
/* harmony import */ var _wordpress_dom_ready__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_wordpress_dom_ready__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @wordpress/i18n */ "@wordpress/i18n");
/* harmony import */ var _wordpress_i18n__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _set_validation_error_rows_seen_class__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./set-validation-error-rows-seen-class */ "./assets/src/amp-validation/set-validation-error-rows-seen-class.js");


function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

/**
 * WordPress dependencies
 */


/**
 * Internal dependencies
 */


/**
 * The id for the 'Showing x of y errors' notice.
 *
 * @member {string}
 */

var idNumberErrors = 'number-errors';
/**
 * The id for the 'Show all' button.
 *
 * @member {string}
 */

var showAllId = 'show-all-errors';
_wordpress_dom_ready__WEBPACK_IMPORTED_MODULE_1___default()(function () {
  handleShowAll();
  handleFiltering();
  handleSearching();
  Object(_set_validation_error_rows_seen_class__WEBPACK_IMPORTED_MODULE_3__["default"])();
  handleRowEvents();
  handleBulkActions();
  watchForUnsavedChanges();
  setupStylesheetsMetabox();
});
var beforeUnloadPromptAdded = false;
/**
 * Add prompt when leaving page due to unsaved changes.
 */

var addBeforeUnloadPrompt = function addBeforeUnloadPrompt() {
  if (beforeUnloadPromptAdded) {
    return;
  }

  window.addEventListener('beforeunload', onBeforeUnload); // Remove prompt when clicking trash or update.

  document.querySelector('#major-publishing-actions').addEventListener('click', function () {
    window.removeEventListener('beforeunload', onBeforeUnload);
  });
  beforeUnloadPromptAdded = true;
};
/**
 * Watch for unsaved changes.
 *
 * Add an beforeunload warning when there are unsaved changes for the markup or review status.
 */


var watchForUnsavedChanges = function watchForUnsavedChanges() {
  var onChange = function onChange(event) {
    if (event.target.matches('.amp-validation-error-status') || event.target.matches('.amp-validation-error-status-review')) {
      document.getElementById('post').removeEventListener('change', onChange);
      addBeforeUnloadPrompt();
    }
  };

  document.getElementById('post').addEventListener('change', onChange);
};
/**
 * Show message at beforeunload.
 *
 * @param {Event} event - The beforeunload event.
 * @return {string} Message.
 */


var onBeforeUnload = function onBeforeUnload(event) {
  event.preventDefault();
  event.returnValue = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('You have unsaved changes. Are you sure you want to leave?', 'amp');
  return Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('You have unsaved changes. Are you sure you want to leave?', 'amp');
};
/**
 * Updates the <tr> with 'Showing x of y validation errors' at the top of the list table with the current count.
 * If this does not exist yet, it creates the element.
 *
 * @param {number} numberErrorsDisplaying - The number of errors displaying.
 * @param {number} totalErrors - The total number of errors, displaying or not.
 */


var updateShowingErrorsRow = function updateShowingErrorsRow(numberErrorsDisplaying, totalErrors) {
  var showAllButton = document.getElementById(showAllId);
  var thead,
      th,
      tr = document.getElementById(idNumberErrors);
  var theadQuery = document.getElementsByTagName('thead'); // Only create the <tr> if it does not exist yet.

  if (theadQuery[0] && !tr) {
    thead = theadQuery[0];
    tr = document.createElement('tr');
    th = document.createElement('th');
    th.setAttribute('id', idNumberErrors);
    th.setAttribute('colspan', '6');
    tr.appendChild(th);
    thead.appendChild(tr);
  } // If all of the errors are displaying, hide the 'Show all' button and the count notice.


  if (numberErrorsDisplaying === totalErrors) {
    if (showAllButton) {
      showAllButton.classList.add('hidden');
    }

    tr.classList.add('hidden');
  } else if (null !== numberErrorsDisplaying) {
    // Update the number of errors displaying and create a 'Show all' button if it does not exist yet.
    document.getElementById(idNumberErrors).innerText = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["sprintf"])(
    /* translators: 1: number of errors being displayed. 2: total number of errors found. */
    Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["_n"])('Showing %1$s of %2$s validation error', 'Showing %1$s of %2$s validation errors', totalErrors, 'amp'), numberErrorsDisplaying, totalErrors);
    document.getElementById(idNumberErrors).classList.remove('hidden');
    conditionallyCreateShowAllButton();

    if (document.getElementById(showAllId)) {
      document.getElementById(showAllId).classList.remove('hidden');
    }
  }
};
/**
 * Conditionally creates and appends a 'Show all' button.
 */


var conditionallyCreateShowAllButton = function conditionallyCreateShowAllButton() {
  var buttonContainer = document.getElementById('url-post-filter');
  var showAllButton = document.getElementById(showAllId); // There is no 'Show all' <button> yet, but there is a container element for it, create the <button>

  if (!showAllButton && buttonContainer) {
    showAllButton = document.createElement('button');
    showAllButton.id = showAllId;
    showAllButton.classList.add('button');
    showAllButton.innerText = Object(_wordpress_i18n__WEBPACK_IMPORTED_MODULE_2__["__"])('Show all', 'amp');
    buttonContainer.appendChild(showAllButton);
  }
};
/**
 * On clicking the 'Show all' <button>, this displays all of the validation errors.
 * Then, it hides this 'Show all' <button> and the notice for the number of errors showing.
 */


var handleShowAll = function handleShowAll() {
  var onClick = function onClick(event) {
    if (!event.target.matches('#' + showAllId)) {
      return;
    }

    event.preventDefault();
    var validationErrors = document.querySelectorAll('[data-error-type]'); // Iterate through all of the errors, and remove the 'hidden' class.

    validationErrors.forEach(function (element) {
      element.parentElement.parentElement.classList.remove('hidden');
    });
    /*
     * Update the notice to indicate that all of the errors are displaying.
     * Like 'Showing 5 of 5 validation errors'.
     */

    updateShowingErrorsRow(validationErrors.length, validationErrors.length); // Hide this 'Show all' button.

    event.target.classList.add('hidden'); // Change the value of the error type <select> element to 'All Error Types'.

    document.getElementById('amp_validation_error_type').selectedIndex = 0;
  };

  document.getElementById('url-post-filter').addEventListener('click', onClick);
};
/**
 * Handles filtering by error type, triggered by clicking 'Apply Filter'.
 *
 * Gets the value of the error type <select> element.
 * And hides all <tr> elements that do not have the same type of this value.
 * If 'All Error Types' is selected, this displays all errors.
 */


var handleFiltering = function handleFiltering() {
  var onChange = function onChange(event) {
    if (!event.target.matches('select')) {
      return;
    }

    event.preventDefault();
    var showAllButton = document.getElementById(showAllId);
    var isAllErrorTypesSelected = '-1' === event.target.value;
    var errorTypeQuery = document.querySelectorAll('[data-error-type]'); // If the user has chosen 'All Error Types' from the <select>, hide the 'Show all' button.

    if (isAllErrorTypesSelected && showAllButton) {
      showAllButton.classList.add('hidden');
    }
    /*
     * Iterate through all of the <tr> elements in the list table.
     * If the error type does not match the value (selected error type), hide them.
     */


    var numberErrorsDisplaying = 0;
    errorTypeQuery.forEach(function (element) {
      var errorType = element.getAttribute('data-error-type'); // If 'All Error Types' was selected, this should display all errors.

      if (isAllErrorTypesSelected || !event.target.value || event.target.value === errorType) {
        element.parentElement.parentElement.classList.remove('hidden');
        numberErrorsDisplaying++;
      } else {
        element.parentElement.parentElement.classList.add('hidden');
      }
    });
    updateShowingErrorsRow(numberErrorsDisplaying, errorTypeQuery.length);
  };

  document.getElementById('amp_validation_error_type').addEventListener('change', onChange);
};
/**
 * Handles searching for errors via the <input> and the 'Search Errors' <button>.
 */


var handleSearching = function handleSearching() {
  var onClick = function onClick(event) {
    event.preventDefault();

    if (!event.target.matches('input')) {
      return;
    }

    var searchQuery = document.getElementById('invalid-url-search-search-input').value;
    var detailsQuery = document.querySelectorAll('tbody .column-details');
    /*
     * Iterate through the 'Context' (formerly 'Details') column of each row.
     * If the search query is not present, hide the row.
     */

    var numberErrorsDisplaying = 0;
    detailsQuery.forEach(function (element) {
      var isSearchQueryPresent = false;
      element.querySelectorAll('.detailed').forEach(function (detailed) {
        if (-1 !== detailed.innerText.indexOf(searchQuery)) {
          isSearchQueryPresent = true;
        }
      });

      if (isSearchQueryPresent) {
        element.parentElement.classList.remove('hidden');
        numberErrorsDisplaying++;
      } else {
        element.parentElement.classList.add('hidden');
      }
    });
    updateShowingErrorsRow(numberErrorsDisplaying, detailsQuery.length);
  };

  document.getElementById('search-submit').addEventListener('click', onClick);
};
/**
 * Update border color for select element.
 *
 * @param {HTMLSelectElement} select Select element.
 */


var updateSelectBorderColor = function updateSelectBorderColor(select) {
  var newOption = select.options[select.selectedIndex];

  if (newOption) {
    select.style.borderColor = newOption.getAttribute('data-color');
  }
};
/**
 * Handles events that may occur for a row.
 */


var handleRowEvents = function handleRowEvents() {
  document.querySelectorAll('tr[id^="tag-"]').forEach(function (row) {
    var statusSelect = row.querySelector('.amp-validation-error-status');
    var reviewCheckbox = row.querySelector('.amp-validation-error-status-review');

    if (statusSelect) {
      /*
       * Handle a change in the error status, like from 'Removed' to 'Kept'. It gets the data-color value
       * from the newly-selected <option> and sets this as the border color of the <select>.
       */
      statusSelect.addEventListener('change', function (event) {
        if (event.target.matches('select')) {
          updateSelectBorderColor(event.target);
        }
      });
    }

    if (reviewCheckbox) {
      // Toggle the 'new' state for the row depending on the state of approval for the validation error.
      reviewCheckbox.addEventListener('change', function () {
        return row.classList.toggle('new');
      });
    }
  });
};
/**
 * On checking a bulk action checkbox, this ensures that the 'Accept' and 'Reject' buttons are present. Handle clicking on buttons.
 *
 * They're hidden until one of these boxes is checked.
 * Also, on unchecking the last checked box, this hides these buttons.
 */


var handleBulkActions = function handleBulkActions() {
  var removeButton = document.querySelector('button.action.remove');
  var keepButton = document.querySelector('button.action.keep');
  var removeAndKeepContainer = document.getElementById('remove-keep-buttons');

  var onChange = function onChange(event) {
    var areThereCheckedBoxes;

    if (!event.target.matches('[type=checkbox]')) {
      return;
    }

    if (event.target.checked) {
      // This checkbox was checked, so ensure the buttons display.
      removeAndKeepContainer.classList.remove('hidden');
    } else {
      /*
       * This checkbox was unchecked.
       * So find if there are any other checkboxes that are checked.
       * If not, hide the 'Accept' and 'Reject' buttons.
       */
      areThereCheckedBoxes = false;
      document.querySelectorAll('.check-column [type=checkbox]').forEach(function (element) {
        if (element.checked) {
          areThereCheckedBoxes = true;
        }
      });

      if (!areThereCheckedBoxes) {
        removeAndKeepContainer.classList.add('hidden');
      }
    }
  };

  document.querySelectorAll('.check-column [type=checkbox]').forEach(function (element) {
    element.addEventListener('change', onChange);
  }); // Handle click on bulk "Remove" button.

  removeButton.addEventListener('click', function () {
    Array.prototype.forEach.call(document.querySelectorAll('select.amp-validation-error-status'), function (select) {
      if (select.closest('tr').querySelector('.check-column input[type=checkbox]').checked) {
        select.value = '3'; // See AMP_Validation_Error_Taxonomy::VALIDATION_ERROR_ACK_ACCEPTED_STATUS.

        updateSelectBorderColor(select);
        addBeforeUnloadPrompt();
      }
    });
  }); // Handle click on bulk "Keep" button.

  keepButton.addEventListener('click', function () {
    Array.prototype.forEach.call(document.querySelectorAll('select.amp-validation-error-status'), function (select) {
      if (select.closest('tr').querySelector('.check-column input[type=checkbox]').checked) {
        select.value = '2'; // See AMP_Validation_Error_Taxonomy::VALIDATION_ERROR_ACK_REJECTED_STATUS.

        updateSelectBorderColor(select);
        addBeforeUnloadPrompt();
      }
    });
  }); // Handle click on bulk "Mark reviewed" and "Mark unreviewed" buttons.

  global.addEventListener('click', function (_ref) {
    var target = _ref.target;

    if (!target.classList.contains('reviewed-toggle')) {
      return;
    }

    var markingAsReviewed = target.classList.contains('reviewed');

    _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(document.querySelectorAll('select.amp-validation-error-status')).forEach(function (select) {
      var row = select.closest('tr');

      if (row.querySelector('.check-column input[type=checkbox]').checked) {
        row.querySelector('input[type=checkbox].amp-validation-error-status-review').checked = markingAsReviewed;
        row.classList.toggle('new', !markingAsReviewed);
        addBeforeUnloadPrompt();
      }
    });
  });
};
/**
 * Set up stylesheet metabox.
 */


var setupStylesheetsMetabox = function setupStylesheetsMetabox() {
  var metabox = document.getElementById('amp_stylesheets');

  var _iterator = _createForOfIteratorHelper(metabox.querySelectorAll('.toggle-stylesheet-details')),
      _step;

  try {
    var _loop = function _loop() {
      var toggleStylesheetDetailsButton = _step.value;
      var row = toggleStylesheetDetailsButton.closest('tr');
      toggleStylesheetDetailsButton.addEventListener('click', function () {
        row.classList.toggle('expanded');
      });
    };

    for (_iterator.s(); !(_step = _iterator.n()).done;) {
      _loop();
    }
  } catch (err) {
    _iterator.e(err);
  } finally {
    _iterator.f();
  }

  var _iterator2 = _createForOfIteratorHelper(metabox.querySelectorAll('.stylesheet-details')),
      _step2;

  try {
    var _loop2 = function _loop2() {
      var stylesheetDetailsElements = _step2.value;
      var shakenStylesheetContainer = stylesheetDetailsElements.querySelector('.shaken-stylesheet');
      var showRemovedStylesCheckbox = stylesheetDetailsElements.querySelector('.show-removed-styles');

      if (showRemovedStylesCheckbox) {
        showRemovedStylesCheckbox.addEventListener('click', function () {
          shakenStylesheetContainer.classList.toggle('removed-styles-shown', showRemovedStylesCheckbox.checked);
        });
      }
    };

    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
      _loop2();
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }
};
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/global.js */ "./node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "./assets/src/amp-validation/set-validation-error-rows-seen-class.js":
/*!***************************************************************************!*\
  !*** ./assets/src/amp-validation/set-validation-error-rows-seen-class.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * Set the initial 'new' (aka 'unseen') class names on the rows based on the presence of a hidden input value.
 *
 * This is needed because \WP_Terms_List_Table::single_row() does not allow for additional
 * attributes to be added to the <tr> element.
 */
/* harmony default export */ __webpack_exports__["default"] = (function () {
  document.querySelectorAll('tr[id]').forEach(function (row) {
    var input = row.querySelector('.amp-validation-error-new');

    if (input) {
      row.classList.toggle('new', Boolean(parseInt(input.value)));
    }
  });
});

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayLikeToArray.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

module.exports = _arrayLikeToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return arrayLikeToArray(arr);
}

module.exports = _arrayWithoutHoles;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/iterableToArray.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/iterableToArray.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

module.exports = _iterableToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/nonIterableSpread.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

module.exports = _nonIterableSpread;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toConsumableArray.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toConsumableArray.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithoutHoles = __webpack_require__(/*! ./arrayWithoutHoles */ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js");

var iterableToArray = __webpack_require__(/*! ./iterableToArray */ "./node_modules/@babel/runtime/helpers/iterableToArray.js");

var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray */ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");

var nonIterableSpread = __webpack_require__(/*! ./nonIterableSpread */ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js");

function _toConsumableArray(arr) {
  return arrayWithoutHoles(arr) || iterableToArray(arr) || unsupportedIterableToArray(arr) || nonIterableSpread();
}

module.exports = _toConsumableArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return arrayLikeToArray(o, minLen);
}

module.exports = _unsupportedIterableToArray;

/***/ }),

/***/ "./node_modules/webpack/buildin/global.js":
/*!***********************************!*\
  !*** (webpack)/buildin/global.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || new Function("return this")();
} catch (e) {
	// This works if the window reference is available
	if (typeof window === "object") g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ "@wordpress/dom-ready":
/*!*******************************************!*\
  !*** external {"this":["wp","domReady"]} ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["domReady"]; }());

/***/ }),

/***/ "@wordpress/i18n":
/*!***************************************!*\
  !*** external {"this":["wp","i18n"]} ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

(function() { module.exports = this["wp"]["i18n"]; }());

/***/ })

/******/ });
//# sourceMappingURL=amp-validated-url-post-edit-screen.js.map